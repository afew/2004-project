// Implementation of the CMcCrdL class.
//
//////////////////////////////////////////////////////////////////////

#include "SeCommon.h"

CMcCrdL::CMcCrdL()
:	iN		(0)
,	pCrv	(0)
,	vPt		(0)
,	fT		(0.5F)
,	fS		(0.025F)
,	bC		(0)
,	iNx		(0)
,	iC		(0)
,	pVtx	(0)
,	pMsh	(0)
{
}

CMcCrdL::~CMcCrdL()
{
	Destroy();
}


INT	CMcCrdL::Init()
{
	iNx	= 10000;

	pCrv = (VEC3*) calloc( iNx, sizeof(VEC3));
	pVtx = (VtxD*) calloc( iNx, sizeof(VtxD));

	memset(pVtx, 0xAA, iNx * sizeof(VtxD));
	D3DXCreateSphere(GDEVICE, 1, 16, 16, &pMsh, NULL);

	return 1;
}

void CMcCrdL::Destroy()
{
	SAFE_FREE(	pCrv	);
	SAFE_FREE(	pVtx	);

	vPt.clear();

	SAFE_RELEASE(	pMsh	);
}


INT CMcCrdL::FrameMove()
{
	KEY_STATE(DIK_LCONTROL)
	{
		BUTTON_DOWN(0)
		{
			VEC3	N;			// Normal Vector
			VEC3	P = GCAMERA->GetPos();
			VEC3	L = GCAMERA->GetRayDir();

			N = VEC3(P.x, 0.f, P.z);
			
			D3DXVec3Normalize(&N, &N);
			
			FLOAT fNL = D3DXVec3Dot(&N, &L);
			FLOAT fNP = D3DXVec3Dot(&N, &P);
			FLOAT fA = fNP/ fNL;


			VEC3 X = P - fA * L;

			PointAdd( X );
		}
	}

	GET_KEY(DIK_SPACE)
	{
		vPt.clear();
		iN = vPt.size();
		iC = 0;
	}

	KEY_STATE(DIK_LCONTROL)
	{
		GET_KEY(DIK_Z)
		{
			if(iN)
			{
				vPt.pop_back();
				iN = vPt.size();
				iC = 0;
			}
		}
	}


	
	if(iN<=3 ||  iN>=iNx)
		return 1;

	KEY_STATE(DIK_UP)
	{
		fT +=0.1f;
	}

	KEY_STATE(DIK_DOWN)
	{
		fT -=0.1f;
	}

	KEY_STATE(DIK_LEFT)
	{
		fS +=0.01f;

		if(fS>0.5f)
			fS = 0.5f;
	}

	KEY_STATE(DIK_RIGHT)
	{
		fS -=0.01f;

		if(fS< 0.01f)
			fS =0.01f;
	}

	GET_KEY(DIK_F1)
	{
		bC	= !bC;
	}	

	CurveUp();
	VtxUp();
	
	return 1;
}


INT CMcCrdL::VtxUp()
{
	INT i;

	if(iC<2)
		return 1;

	for(i=0; i<iC; ++i)
	{
		pVtx[i].p = pCrv[i];
	}

	return 1;
}


void CMcCrdL::Render()
{
	MAT		mtW;
	INT		i;
	VEC3	pos;

	if(iN<1)
		return;

	D3DXMatrixIdentity(&mtW);

	GDEVICE->SetTexture(0 , 0);

	D3DMATERIAL9 mtrl;
	D3DLIGHT9 light;

	D3DUtil_InitMaterial( mtrl, 0.f, 1.f, 1.f );
	mtrl.Power = 25.0f;
	mtrl.Specular.a = 1.f;
	mtrl.Specular.r = .0f;
	mtrl.Specular.g = 1.0f;
	mtrl.Specular.b = 1.0f;

	D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
	light.Specular.a = 1.0f;
	light.Specular.r = 1.0f;
	light.Specular.g = 0.0f;
	light.Specular.b = 0.0f;
	
	light.Range = 1000;
	light.Falloff = 0;
	light.Attenuation0 = 1;
	light.Attenuation1 = 0;
	light.Attenuation2 = 0;

	GDEVICE->SetRenderState(D3DRS_LIGHTING, TRUE);
	GDEVICE->SetLight( 0, &light );
	GDEVICE->LightEnable( 0, TRUE );
	GDEVICE->SetRenderState( D3DRS_AMBIENT, 0x00333333);
	GDEVICE->SetMaterial( &mtrl );

	for(i=0; i<iN; ++i)
	{
		mtW._41 = vPt[i].x;
		mtW._42 = vPt[i].y;
		mtW._43 = vPt[i].z;

		GDEVICE->SetTransform(D3DTS_WORLD, &mtW);

		DWORD dwFVF = pMsh->GetFVF();

		GDEVICE->SetFVF(dwFVF);
		pMsh->DrawSubset(0);

		SeUtil_3Dto2D(pos, vPt[i]);

		RECT rt;

		rt.left = long(pos.x);
		rt.right = rt.left + 50;

		rt.top = long(pos.y)-16;
		rt.bottom = rt.top + 30;

		GMAIN->m_pDXFt->DrawText( SeUtil_Forming("%d", i), -1, &rt, 0, D3DXCOLOR(1,0,0,1));
	}

	D3DXMatrixIdentity(&mtW);
	GDEVICE->SetTransform(D3DTS_WORLD, &mtW	);

	if(iN<3 || iC<2)
		return;

	GDEVICE->LightEnable( 0, FALSE );
	
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	GDEVICE->SetTexture(0 , 0);
	GDEVICE->SetFVF(FVF_VTXD);
	GDEVICE->DrawPrimitiveUP(D3DPT_LINESTRIP, iC-1, pVtx, sizeof(VtxD)	);

//	SeUtil_SetWindowTitle("%d", iC);
}


void CMcCrdL::PointAdd(VEC3	_p)
{
	vPt.push_back( _p);
	iN = vPt.size();
}


INT CMcCrdL::CurveUp()
{
	INT		i;
	FLOAT	u;
	VEC3	p;
	INT		n0;
	INT		n1;
	INT		n2;
	INT		n3;
	VEC4	t;
	VEC3	pTmp;
		
	mtCd._11 =  -fT;	mtCd._12 =  2-fT;	mtCd._13 =   fT-2;	mtCd._14 =  fT;
	mtCd._21 = 2*fT;	mtCd._22 =  fT-3;	mtCd._23 = 3-2*fT;	mtCd._24 = -fT;
	mtCd._31 =  -fT;	mtCd._32 =     0;	mtCd._33 =     fT;	mtCd._34 =   0;
	mtCd._41 =    0;	mtCd._42 =     1;	mtCd._43 =      0;	mtCd._44 =   0;
	
	iC = 0;	

	if(bC)
	{
		for(i=-1; i<iN; ++i)
		{
			for(u=0; u<=1.f; u += fS)
			{
				t	= VEC4( u*u*u, u*u, u, 1);

				n0	= (iN + i + 0)%iN;
				n1	= (iN + i + 1)%iN;
				n2	= (iN + i + 2)%iN;
				n3	= (iN + i + 3)%iN;				
				
				p.x  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[n0].x
					+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[n1].x
					+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[n2].x
					+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[n3].x;

				p.y  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[n0].y
					+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[n1].y
					+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[n2].y
					+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[n3].y;

				p.z  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[n0].z
					+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[n1].z
					+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[n2].z
					+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[n3].z;
				
				pCrv[iC] = p;

				++iC;
			}
		}
	}

	else
	{
		for(i=-1; i<iN-2; ++i)
		{
			for(u=0; u<=1.f; u += fS)
			{
				t	= VEC4( u*u*u, u*u, u, 1);

				n0	= (i + 0)%iN;
				n1	= (i + 1)%iN;
				n2	= (i + 2)%iN;
				n3	= (i + 3)%iN;

				if(-1 == i)
				{
					pTmp	= vPt[0]  + ( vPt[0] - vPt[1]);

					p.x  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * pTmp.x
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[0].x
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[1].x
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[2].x;

					p.y  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * pTmp.y
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[0].y
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[1].y
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[2].y;

					p.z  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * pTmp.z
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[0].z
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[1].z
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[2].z;
				}

				else if(iN-3 == i)
				{
					pTmp	= vPt[iN-1]  + ( vPt[iN-1] - vPt[iN-2]);

					p.x  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[iN-3].x
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[iN-2].x
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[iN-1].x
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * pTmp.x;

					p.y  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[iN-3].y
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[iN-2].y
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[iN-1].y
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * pTmp.y;

					p.z  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[iN-3].z
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[iN-2].z
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[iN-1].z
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * pTmp.z;
				}

				else
				{
					p.x  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[n0].x
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[n1].x
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[n2].x
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[n3].x;

					p.y  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[n0].y
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[n1].y
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[n2].y
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[n3].y;

					p.z  =	(t.x * mtCd._11 + t.y * mtCd._21 + t.z * mtCd._31 + t.w * mtCd._41) * vPt[n0].z
						+	(t.x * mtCd._12 + t.y * mtCd._22 + t.z * mtCd._32 + t.w * mtCd._42) * vPt[n1].z
						+	(t.x * mtCd._13 + t.y * mtCd._23 + t.z * mtCd._33 + t.w * mtCd._43) * vPt[n2].z
						+	(t.x * mtCd._14 + t.y * mtCd._24 + t.z * mtCd._34 + t.w * mtCd._44) * vPt[n3].z;
				}
				
				pCrv[iC] = p;

				++iC;
			}
		}

	}

	strcat(GMAIN->m_sMsg, SeUtil_Forming(" Points N: %d  Tension: %f  Step: %f", iC, fT, fS));

	return 1;
}

