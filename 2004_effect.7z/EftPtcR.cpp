// Implementation of the CEftPtcR class.
//
//////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

CEftPtcR::CEftPtcR()
{
	pPrt		= NULL;
	pVtx		= NULL;

	m_bRn		= false;
	m_iN		= 500;
	m_pTx		= NULL;

	m_fSpd		= 100.f;
}

CEftPtcR::	~CEftPtcR()
{
	Destroy();
}

INT CEftPtcR::Init()
{
	pPrt = (EftPt*)  calloc(m_iN, sizeof(EftPt));
	pVtx = (VtxDUV*) calloc(m_iN*6, sizeof(VtxDUV));

	McUtil_TextureLoad("Texture/comet.bmp", m_pTx, 0x0);
	
	return 1;
}

void CEftPtcR::Reset()
{
	m_bRn = true;

	m_vcI = VEC3(0,10,-1000);
	m_vcT = VEC3( 0,0, 1);

	D3DXVec3Normalize(&m_vcT, &m_vcT);

	m_vcP = m_vcI;
	
	for (INT i=0;i<m_iN;++i)
		pPrt[i].bLive = false;
}


void CEftPtcR::Destroy()
{
	SAFE_FREE(pPrt);
	SAFE_FREE(pVtx);

	SAFE_RELEASE(	m_pTx	);
}


INT	CEftPtcR::FrameMove()
{
	if(!m_bRn)
		return 1;

	PtcUpdate();
	VtxUpdate();

	return 1;
}



INT	CEftPtcR::PtcUpdate()
{
	INT i=0;
	
	m_vcP += m_vcT*m_fSpd;
	
	for (i=0;i<m_iN;++i)
	{
		if(false == pPrt[i].bLive && m_vcP.y>0.f)
		{
			Set(i);
			break;
		}
	}

	for (i=0;i<m_iN;++i)
	{
		if(false == pPrt[i].bLive)
			continue;
	
		pPrt[i].vcV += pPrt[i].vcA;
		pPrt[i].vcP += pPrt[i].vcV;
		pPrt[i].vcR += pPrt[i].vcRv;
		pPrt[i].vcS += pPrt[i].vcSv;

		pPrt[i].fLife+= pPrt[i].fFade;
		pPrt[i].xcC.r+= pPrt[i].fFade;
		pPrt[i].xcC.g = pPrt[i].xcC.r*0.8f;
		pPrt[i].xcC.b = pPrt[i].xcC.r*0.4f;
		pPrt[i].xcC.a+= pPrt[i].fFade*1.6f;
		
		if(pPrt[i].xcC.r <0)	pPrt[i].xcC.r = 0;
		if(pPrt[i].xcC.g <0)	pPrt[i].xcC.g = 0;
		if(pPrt[i].xcC.b <0)	pPrt[i].xcC.b = 0;
		if(pPrt[i].xcC.a <0)	pPrt[i].xcC.a = 0;
		
		if(pPrt[i].fLife<=0 || pPrt[i].xcC.a<=0)
			pPrt[i].bLive = false;
		
		pPrt[i].fFlp += 1.f;

		if(1.f< pPrt[i].fFlp)
			pPrt[i].fFlp =10.f;
	}

	return 1;
}

INT CEftPtcR::VtxUpdate()
{
	INT	i;
	MAT	matBill = GCAMERA->GetBillMat();
	MAT RotZ;
	MAT mat;	
	m_iNQ	=-1;

	for (i=0;i<m_iN;++i)
	{
		if(false == pPrt[i].bLive)
			continue;

		++m_iNQ;
		
		if(pPrt[i].fFlp<1.f)
		{
			pVtx[m_iNQ*6+ 0].p= VEC3( -12, +9, 0);
			pVtx[m_iNQ*6+ 1].p= VEC3( +12, +9, 0);
			pVtx[m_iNQ*6+ 2].p= VEC3( -12, -9, 0);
			pVtx[m_iNQ*6+ 3].p= VEC3( +12, -9, 0);

			pVtx[m_iNQ*6+ 0].u = ((0 +0) * 64)/512.f; 
			pVtx[m_iNQ*6+ 1].u = ((0 +1) * 64)/512.f; 
			pVtx[m_iNQ*6+ 2].u = ((0 +0) * 64)/512.f; 
			pVtx[m_iNQ*6+ 3].u = ((0 +1) * 64)/512.f; 
		}

		else
		{
			pVtx[m_iNQ*6+ 0].p= VEC3(-pPrt[i].fW*pPrt[i].vcS.x,  pPrt[i].fH*pPrt[i].vcS.y, 0);
			pVtx[m_iNQ*6+ 1].p= VEC3( pPrt[i].fW*pPrt[i].vcS.x,  pPrt[i].fH*pPrt[i].vcS.y, 0);
			pVtx[m_iNQ*6+ 2].p= VEC3(-pPrt[i].fW*pPrt[i].vcS.x, -pPrt[i].fH*pPrt[i].vcS.y, 0);
			pVtx[m_iNQ*6+ 3].p= VEC3( pPrt[i].fW*pPrt[i].vcS.x, -pPrt[i].fH*pPrt[i].vcS.y, 0);

			if(1.f == pPrt[i].fDir)
			{
				pVtx[m_iNQ*6+ 0].u = ((pPrt[i].w +0) * 64)/512.f; 
				pVtx[m_iNQ*6+ 1].u = ((pPrt[i].w +1) * 64)/512.f; 
				pVtx[m_iNQ*6+ 2].u = ((pPrt[i].w +0) * 64)/512.f; 
				pVtx[m_iNQ*6+ 3].u = ((pPrt[i].w +1) * 64)/512.f; 
			}

			else
			{
				pPrt[i].bLive = false;
				
				pVtx[m_iNQ*6+ 0].u = ((1 +0) * 64)/512.f; 
				pVtx[m_iNQ*6+ 1].u = ((1 +1) * 64)/512.f; 
				pVtx[m_iNQ*6+ 2].u = ((1 +0) * 64)/512.f; 
				pVtx[m_iNQ*6+ 3].u = ((1 +1) * 64)/512.f; 
			}
		}
		

		D3DXMatrixRotationZ(&RotZ, DEGtoRAD(pPrt[i].vcR.z));
		mat = RotZ * matBill;
		
		D3DXVec3TransformCoord(&pVtx[m_iNQ*6+ 0].p, &pVtx[m_iNQ*6+ 0].p, &mat);
		D3DXVec3TransformCoord(&pVtx[m_iNQ*6+ 1].p, &pVtx[m_iNQ*6+ 1].p, &mat);
		D3DXVec3TransformCoord(&pVtx[m_iNQ*6+ 2].p, &pVtx[m_iNQ*6+ 2].p, &mat);
		D3DXVec3TransformCoord(&pVtx[m_iNQ*6+ 3].p, &pVtx[m_iNQ*6+ 3].p, &mat);
		
		pVtx[m_iNQ*6+ 0].p +=pPrt[i].vcP;
		pVtx[m_iNQ*6+ 1].p +=pPrt[i].vcP;
		pVtx[m_iNQ*6+ 2].p +=pPrt[i].vcP;
		pVtx[m_iNQ*6+ 3].p +=pPrt[i].vcP;

		pVtx[m_iNQ*6+ 0].d =
		pVtx[m_iNQ*6+ 1].d =
		pVtx[m_iNQ*6+ 2].d =
		pVtx[m_iNQ*6+ 3].d = pPrt[i].xcC;

		pVtx[m_iNQ*6+ 0].v = 0.f;						//00
		pVtx[m_iNQ*6+ 1].v = 0.f;						//10
		pVtx[m_iNQ*6+ 2].v = 1.f;						//01
		pVtx[m_iNQ*6+ 3].v = 1.f;						//11
		
		pVtx[m_iNQ*6+ 4] = pVtx[m_iNQ*6+ 2];
		pVtx[m_iNQ*6+ 5] = pVtx[m_iNQ*6+ 1];
	}
	
	return 1;
}


void CEftPtcR::Render()
{
	if(!m_bRn)
		return ;
	
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE , FALSE);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE );
	

//	PDTX pTx = TBLTX->Select(m_nTxM,m_nTxS);
	PDTX	pTx = m_pTx;
	
	GDEVICE->SetTexture(0, pTx);

	GDEVICE->SetFVF(FVF_VTXDUV);

	GDEVICE->SetRenderState(D3DRS_ZWRITEENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_DESTALPHA);

	if(m_iNQ>0)
		GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLELIST, m_iNQ*2, pVtx, sizeof(VtxDUV));
	
	GDEVICE->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
}



void	CEftPtcR::Set(INT i)
{
	pPrt[i].bLive= true;
	pPrt[i].w	= 2.f+ rand()%6;

	pPrt[i].vcP	= m_vcP;
	pPrt[i].vcV	= VEC3(( 5- rand()%10) *0.6f, rand()%10 *0.3f, ( 5- rand()%10) *0.6f) - m_vcT*0.0025f;
	pPrt[i].vcA	= VEC3(0, 0, 0);									// Set Accelation
	pPrt[i].vcR	= VEC3(0, 0, 0);
	pPrt[i].vcRv= VEC3(0, 0, (-10 + rand()%20) *1.f);
	pPrt[i].vcS	= VEC3(1, 1, 1);
	pPrt[i].vcSv= VEC3(.7f, .7f, 0);
	pPrt[i].xcC.r	= 1.f;
	pPrt[i].xcC.a	= 1.f;
	
	pPrt[i].fFade= -(50 + rand()%25)/4000.f;
	pPrt[i].fLife= 1.f;												// Life
	pPrt[i].fW	= ( 10 + rand()%40)/4.f;							// width to height
	pPrt[i].fH	= pPrt[i].fW;								// width to height
	pPrt[i].fFlp	= -1.f;												// First?
	pPrt[i].fDir	= ((rand()%100)/1 >0 )? 1.f: -1.f;					// Render Tail?
}



