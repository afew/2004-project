////////////////////////////////////////////////////////////////////////////////
//
// Explain:
// Date : 2003-04-18, Author:
// History:

#ifndef _SEUTIL_H_
#define _SEUTIL_H_

#define ONE_RADtoDEG	57.2957795130823208767981548f
#define ONE_DEGtoRAD	0.01745329251994329576923690f
#define PI				3.14159265358979323846264338f
#define DEG90toRAD		1.57079632679489661923132163f
#define RADtoDEG(p) ( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p) ( (p)*ONE_DEGtoRAD)

////////////////////////////////////////////////////////////////////////////////
// 

template<class T> D3DXINLINE
bool SeUtil_IsBadReadPtr(T* &t)
{
	return (IsBadReadPtr(t, sizeof(T)));
}


template<class T> D3DXINLINE
bool SeUtil_IsNotAllocated(T* &t)
{
	return (!&t || !t || IsBadReadPtr(t, sizeof(T)) );	
}

template<class T> D3DXINLINE
bool SeUtil_IsAllocated(T* &t)
{
	return !SeUtil_IsNotAllocated(t);
}

template<class T> D3DXINLINE
void SAFE_NEW(T* &p)
{
	//	if(!p)
	if(SeUtil_IsNotAllocated(p))
		p = new T;
}

template<class T> D3DXINLINE
void SAFE_NEW_ARRAY(T* &p, INT N)
{
	if(SeUtil_IsNotAllocated(p))
		p = new T[N];
}

template<class T> D3DXINLINE
INT  _SAFE_NEWINIT(T* &p)
{
	if(SeUtil_IsNotAllocated(p))
	{
		p = new T;
		if( p->Init()<0 )
			return -1;
	}
	
	return 1;
}


#define		SAFE_FREE(p)		{ if(p) { free(p);		(p)=NULL; } }

#define		SAFE_NEWINIT(p)		if(FAILED(_SAFE_NEWINIT(p)))	return -1;


template<class T> D3DXINLINE
void SAFE_NEWINIT_ARRAY(T* &p, INT N)
{
	if(SeUtil_IsNotAllocated(p))
	{
		p = new T[N];
		for(INT i = 0; i<N ; ++i)
			p[i].Init();
	}
}

#define		SAFE_DESTROY(p)		if(p)	(p)->Destroy();

template<class T> D3DXINLINE
void SAFE_DESTROY_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N ; ++i)
			p[i].Destroy();
}

#define		_SAFE_RESTORE(p)	if(p)	(p)->Restore();
#define		SAFE_RESTORE(p)		if((p) && FAILED( (p)->Restore())) return -1;

template<class T> D3DXINLINE
void SAFE_RESTORE_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N ; ++i)
			p[i].Restore();
}


#define		SAFE_INVALIDATE(p)	if(p)	(p)->Invalidate();


template<class T> D3DXINLINE
void SAFE_INVALIDATE_ARRAY	(T* &p,INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].Invalidate();
}

#define		SAFE_FRAMEMOVE(p)	if( (p) && FAILED( (p)->FrameMove())) return -1;
#define		SAFE_UPDATE(p)		if( (p) && FAILED( (p)->Update())) return -1;


template<class T> D3DXINLINE
void SAFE_FRAMEMOVE_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].FrameMove();
}


#define		SAFE_RENDER(p)	if(p)	(p)->Render();
#define		SAFE_RNDBCK(p)	if(p)	(p)->RndBck();


template<class T> D3DXINLINE
void SAFE_RENDER_ARRAY	(T* &p, INT N)
{
	if(SeUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].Render();
}


template<class T> D3DXINLINE
void SeUtil_Swap (T* &a, T* &b)
{
	T c; c = *a; *a = *b;*b = c;
}

template<class T> D3DXINLINE void SAFE_INIT_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<p.size; ++i)
		if(p[i])
			p[i]->Init();
}



template<class T> D3DXINLINE
void SAFE_DELETE_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_DELETE(p[i]);

	p.clear();
}


template<class T> D3DXINLINE
void SAFE_DESTROY_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_DESTROY(p[i]);
}


template<class T> D3DXINLINE
INT SAFE_RESTORE_LIST(T &p)
{
	if(p.empty())	return -1;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		if((p[i]) && FAILED( (p[i])->Restore()))
			return -1;
	
	return 1;
}


template<class T> D3DXINLINE
void SAFE_INVALIDATE_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_INVALIDATE(p[i]);
}




template<class T> D3DXINLINE
INT SAFE_FRAMEMOVE_LIST(T &p)
{
	if(p.empty())	return -1;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
	{
		if(! p[i])
			return -1;
		
		if( FAILED( (p[i])->FrameMove()))
			return -1;
	}
	
	return 1;
}



template<class T> D3DXINLINE
void SAFE_RENDER_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_RENDER(p[i]);
}

#define		SAFE_DESTROY_WINDOW(p)	{	if(p)	DestroyWindow(p);		}



/****************************************************************************

 RandomNumber: returns a random number between iMin and iMax.

 ****************************************************************************/
inline INT RandomNumber(INT iMin, INT iMax)
{
  if (iMin == iMax) return(iMin);
  return((rand() % (abs(iMax-iMin)+1))+iMin);
}

inline float RandomNumber(float fMin, float fMax)
{
  if (fMin == fMax) return(fMin);
  float fRandom = (float)rand() / (float)RAND_MAX;
  return((fRandom * (float)fabs(fMax-fMin))+fMin);
}

inline D3DXVECTOR3 RandomNumber(D3DXVECTOR3 vMin, D3DXVECTOR3 vMax)
{
  float x = RandomNumber(vMin.x, vMax.x);
  float y = RandomNumber(vMin.y, vMax.y);
  float z = RandomNumber(vMin.z, vMax.z);
  return(D3DXVECTOR3(x,y,z));
}

inline D3DXCOLOR RandomNumber(D3DXCOLOR Min, D3DXCOLOR Max)
{
  float r = RandomNumber(Min.r, Max.r);
  float g = RandomNumber(Min.g, Max.g);
  float b = RandomNumber(Min.b, Max.b);
  float a = RandomNumber(Min.a, Max.a);
  return(D3DXCOLOR(r,g,b,a));
}

////////////////////////////////////////////////////////////////////////////////
// class CMinMax 
//
template <class T> class CMinMax
{
public:
  CMinMax() { m_Min = T(); m_Max = T(); }
  CMinMax(T tMin, T tMax) { m_Min = tMin; m_Max = tMax; }
  ~CMinMax() { }

	T m_Min;
	T m_Max;

	T GetRandomNumInRange(void) { return(RandomNumber(m_Min, m_Max)); }
	T GetRange(void) { return(abs(m_Max-m_Min)); }
	
};



void	SeUtil_ErrMsgBox(TCHAR *format,...);
void	SeUtil_GetLastError(HWND hWnd);
void	SeUtil_FormatLog(TCHAR *format,...);
void	SeUtil_FormatLog2(TCHAR *format,...);
INT		SeUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color=0xffffffff, D3DXIMAGE_INFO *pSrcInfo=NULL, DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), D3DFORMAT d3dFormat = D3DFMT_A8R8G8B8);
void	SeUtil_ReadFileLine(FILE *fp, TCHAR *str, INT nStr);
void	SeUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC='\"');

void	SeUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx=NULL, D3DPOOL usage=D3DPOOL_MANAGED);
void	SeUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx);
void	SeUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx=NULL, D3DFORMAT fmt=D3DFMT_INDEX16, D3DPOOL usage= D3DPOOL_MANAGED);
void	SeUtil_IBLock(PDIB& pIB, INT nSize, void* pIdx);


bool	SeUtil_LineCross2D(VEC2 * p);
INT		SeUtil_3Dto2D(VEC3 & Out, const VEC3 & In);
bool	SeUtil_PositionMouse3D(VEC3 & vec3dOut);
INT		SeUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color= RGB(255,255,0));
void	SeUtil_SetWindowTitle(const char *format, ...);
void	SeUtil_TextOut(float x, float y, const char *format, ...);
void	SeUtil_TextOut(VEC2 p, const char *format, ...);
void	SeUtil_OutputDebug(const char *Format, ...);
TCHAR*	SeUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR *sTitle="Choose Folder");
TCHAR*	SeUtil_DWtoStr(DWORD dwA);
char*	SeUtil_Forming(const char *fmt, ...);
char*	getSmallTime(void);
INT		SeUtil_PluckFirstField(char *str, char *dest, INT maxlen, const char *delim);

void	SetDlgItemFloat(HWND hWnd, UINT id, FLOAT z, INT decimal=6);
FLOAT	GetDlgItemFloat(HWND hWnd, UINT id);
void	SetDlgItemHex(HWND hWnd, UINT id, INT val);

#define PFF(s, d, l, d1) SeUtil_PluckFirstField((s), (d), (l), (d1))

inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }
inline DWORD F2DW( FLOAT f )	{ return *((DWORD*)&f); }


#define chkbound(x1, y1, x2, y2, xw1, yw1) \
chkabound((x1), (y1), 1, 1, (x2), (y2), (xw1), (yw1))
#define chkbound2(x1, y1, x2, y2, x3, y3) \
chkabound2((x1), (y1), (x1), (y1), (x2), (y2), (x3), (y3))
#define chkabound(x1, y1, xw1, yw1, x2, y2, xw2, yw2) \
chkabound2((x1), (y1), (x1) + (xw1) - 1, (y1) + (yw1) - 1, (x2), (y2), (x2) + (xw2) - 1, (y2) + (yw2) - 1)

INT chkabound2(INT x1, INT y1, INT x2, INT y2, INT x3, INT y3, INT x4, INT y4);




////////////////////////////////////////////////////////////////////////////////
// scrollString
class CStrRoll
{
public:
	INT iCur;			// ���� Index
	INT iStartX;		// ���� X
	INT	iDY;			// ����
	INT nNumLine;		// ���μ�
	char (* m_szString)[2048];

public:
	CStrRoll();
	virtual INT Init();
	virtual void Destroy();
	virtual void PrintString(INT iY=500);
	virtual void SetString(const char *format, ...);
	virtual ~CStrRoll();
};



class _TICK
{
	/// Functions;
	/// Memories;
	DWORD m_next_tick, m_tick;
public:
	/// Functions;
	_TICK();
	virtual ~_TICK();
	void clear(void);
	void clear2cur(void);
	void init(INT tick);
	void user(void);
	/// Memories;
	INT tog;
	INT over;
}; // _TICK;



typedef struct tagSWin
{
	PDSW	pC;																	// Swap chain
	PDSF	pB;																	//Back buffer surface
	PDSF	pS;																	//Stencil buffer surface
	HWND	hW;																	// Window Handle

	tagSWin() :	pC(0), pB(0), pS(0), hW(0){}

	void	Release()
	{
		SAFE_RELEASE(pC);
		SAFE_RELEASE(pB);
		SAFE_RELEASE(pS);
	}

}SWin;



typedef struct tagSTItmInf
{
	INT			nM;
	INT			nS;
	HTREEITEM	hT;

	tagSTItmInf():	nM(-1),	nS(-1),	hT(0){}
	tagSTItmInf(INT M, INT S, HTREEITEM T):	nM(M),	nS(S),	hT(T){}

	bool HasParent()
	{
		if(nM<0)
			return false;
		
		return true;
	}

}STItmInf;

typedef vector<STItmInf>	lsHItem;
typedef lsHItem::iterator	itHItem;




#define TOKENV_TOTAL (512 + 4)

extern char *special_symbols;
extern INT special_symbol_is_token;
extern INT strtoken_case_sensitive;
extern INT accept_string_token;
extern INT white_space_is_token;
extern INT detect_special_symbol_only;

extern char tokenv_str[TOKENV_TOTAL];

extern void init_token(void);
extern INT tokenc(char *ss);
extern char *tokenv(INT num);
extern INT _isspace(INT ch);






#ifndef _BASE_H_
#define _BASE_H_

/* Switches */
#define changeResolution 0
#define movableWindow 0


#define AFTER 0
#define CUR_ACT !AFTER
#define REM(cmt) /##* (cmt) *##/


/* Functions */
// Defined //

#define MB(p) MessageBox(NULL, (p), "Message", MB_OK)

#define free0(x) while ((x) != NULL) free(x), (x) = NULL
#define RAMfree0(x) while ((x) != NULL) RAMfree(x), (x) = NULL
#define _0b(x) ((BYTE)( \
	((0##x) & 01L) | \
	(((0##x) & 010L) >> 2) | \
	(((0##x) & 0100L) >> 4) | \
	(((0##x) & 01000L) >> 6) | \
	(((0##x) & 010000L) >> 8) | \
	(((0##x) & 0100000L) >> 10) | \
	(((0##x) & 01000000L) >> 12) | \
	(((0##x) & 010000000L) >> 14) \
))

#define _0B(x) _0b(x)
#define NULLreturn(ptr, ret) while ((ptr) == NULL) return(ret)
#define isBIT(a, b) (((a) & (b)) == (b))
#define inBIT(a, b) ((a) & (b))


TCHAR *strptr(TCHAR *str, INT next);
void div_cmdline(TCHAR *fstr);
INT htoi(TCHAR *str);

INT folder(BYTE *dst, BYTE *src, INT len_src);
void unfolder(BYTE *dst, BYTE *src, INT len_src);
INT folder(FILE *dst, BYTE *src, INT len_src);
void unfolder(BYTE *dst, FILE *src, INT len_src);
INT strcmp2(TCHAR *s1, TCHAR *s2);
TCHAR *convCSS(INT val);
INT copyStrB2W(TCHAR *s1, USHORT *w1);
INT strstrW(TCHAR *s1, TCHAR *s2, INT dir); // strstr() for Wild TCHAR.;
// Interrupt Call //

// Memory Function //
void *RAMalloc(DWORD size);
void RAMfree(void *bptr);

// File Function //
INT fexist(TCHAR *fnm);
UINT getdrest(TCHAR ch);
HANDLE fopen4w(LPSTR fnm, INT mode);
UINT fread4w(HANDLE hFile, void *mptr, INT len);
UINT fwrite4w(HANDLE hFile, void *mptr, INT len);
#define fseek4w(hFile, pos, mode) SetFilePointer((hFile), (pos), NULL, (mode))
#define ftell4w(hFile) fseek4w((hFile), 0, FILE_CURRENT)
#define fclose4w(hFile) CloseHandle(hFile)
TCHAR *fgets2(TCHAR *str, INT n, FILE *fft);
TCHAR *fgetsl(TCHAR *str, INT n, FILE *fft);
INT filecmp(TCHAR *fnm, TCHAR *fnm2);
void filecpy(TCHAR *fnm2, TCHAR *fnm);
void filecpy(TCHAR *fnm2, TCHAR *fnm, UINT attr);

// Miscellaneous Function //
#define _srand(val) next_rnd = val
UINT _rand(void);
double round(double val);
void getClip(TCHAR *str);
void putClip(TCHAR *str);
UINT getCRC(void *bptr, INT size, UINT crc);
UINT getCRC(TCHAR *fnm, UINT crc);
void getNextLinePos(INT *x1, INT *y1, INT x2, INT y2, INT limit_pixel);
void init_fastcpy(void);
#define CENTER_POS(_total, _current) (((_total) - (_current)) >> 1)
#define RIGHT_POS(_total, _current) ((_total) - (_current))
//void DEBUG(TCHAR *str);
INT getDirection(INT x1, INT y1);
void getCirclePos(INT r1, INT a1, INT &x1, INT &y1);
INT getLength(INT x1, INT y1, INT x2, INT y2);
INT getClipping(INT x1, INT y1, INT xw1, INT yw1, INT &x2, INT &y2, INT &xw2, INT &yw2);
void initSinCosTbl(void);

extern void *(*fastcpy)(void *pDest, const void *pSrc, UINT size);
#endif


//for game programming...
typedef struct tagSBaseGameInfo
{
	TCHAR	sCrnPath	[512];
	TCHAR	Version		[ 32];
	INT		PcType		;
	INT		DebugString	;
	INT		CameraInfo	;
	INT		Box			;
	INT		StartFull	;
	INT		DisplayFPS	;
	INT		LimitCamera	;
	TCHAR	SvrIP		[32];
	TCHAR	SvrPt		[32];
	INT		WindowTitle		;
	TCHAR	FileClimate	[512];
	TCHAR	FileExpLvl	[512];
	TCHAR	FileFontList[512];
	TCHAR	FileHiMap	[512];
	TCHAR	FileLight	[512];
	TCHAR	FileLocal	[512];
	TCHAR	FileModel	[512];
	TCHAR	FileSound	[512];
	TCHAR	FileTexture	[512];
	TCHAR	FileMenu	[512];
	TCHAR	FileUI		[512];
	TCHAR	FileUISetup	[512];

	TCHAR	FilePiece	[512];
	TCHAR	FileCard	[512];
	TCHAR	FileMob		[512];
	TCHAR	FileEquip	[512];

	TCHAR	FileUiGrph	[512];
	TCHAR	FileUiWin	[512];
	TCHAR	FileRace	[512];

	INT		File_Log	;

	tagSBaseGameInfo()
		: PcType		(0)
		, DebugString	(0)
		, CameraInfo	(0)
		, Box			(0)
		, StartFull		(0)
		, WindowTitle	(0)
		, DisplayFPS	(0)
		, LimitCamera	(0)
		, File_Log		(0)
	{
		memset(sCrnPath,	0,	sizeof(sCrnPath		));
		memset(Version,		0, sizeof(Version		));
		memset(FileClimate,	0, sizeof(FileClimate	));
		memset(FileExpLvl,	0, sizeof(FileExpLvl	));
		memset(FileFontList,0, sizeof(FileFontList	));
		memset(FileHiMap,	0, sizeof(FileHiMap		));
		memset(FileLight,	0, sizeof(FileLight		));
		memset(FileLocal,	0, sizeof(FileLocal		));
		memset(FileModel,	0, sizeof(FileModel		));
		memset(FileSound,	0, sizeof(FileSound		));
		memset(FileTexture,	0, sizeof(FileTexture	));
		memset(FileMenu,	0, sizeof(FileMenu		));
		memset(FileUI,		0, sizeof(FileUI		));
		memset(FileUISetup,	0, sizeof(FileUISetup	));

		memset(FilePiece,	0, sizeof(FilePiece		));
		memset(FileCard,	0, sizeof(FileCard		));
		memset(FileMob,		0, sizeof(FileMob		));
		memset(FileEquip,	0, sizeof(FileEquip		));
		memset(FileUiGrph,	0, sizeof(FileUiGrph	));
		memset(SvrPt,		0, sizeof(FileUiWin		));
		memset(FileRace,	0, sizeof(FileRace		));

		memset(SvrIP,		0, sizeof(SvrIP			));
		memset(SvrPt,		0, sizeof(SvrPt			));	
	}
	
}SBaseGameInfo;



#endif