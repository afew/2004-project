// McChase.h: interface for the CMcChase class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCCHASE_H_
#define _MCCHASE_H_

class CMcChase
{
public:
	VEC3	m_vcPs;	// source position
	VEC3	m_vcVs;	// source velocity
	VEC3	m_vcTs;	// source tranverse vector
	
	FLOAT	m_fSpd;	// source speed
	
	VEC3	m_vcPt;	// target position

	FLOAT	m_lR;
	FLOAT	m_dL;
	FLOAT	m_dV;

public:
	
	PXMS	m_qS;
	PXMS	m_qT;
	FLOAT	m_fAngle;
	PDTX	m_pTxS;
	PDTX	m_pTxT;

	
public:
	CMcChase();
	~CMcChase();
	
	INT		Init();
	void	Destroy();
	
	INT		FrameMove();
	void	Render();
};

#endif