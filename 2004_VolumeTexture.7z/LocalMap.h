///////////////////////////////////////////////////////////////////////////////
// File: LocalMap.h
// Desc: Map Rendering...
//
// Date: 2003-05-20, Author: SR OnLine
// History: 

#ifndef _LOCALMAP_H_
#define _LOCALMAP_H_


typedef struct tagSBlockH
{
	BYTE**	pH;

	tagSBlockH()
	{
		pH	= NULL;
	}

}SBlockH;


typedef struct tagVtxLocal
{
	VtxUV*	pVtx;
	PDVB	m_pVB;
	PDIB	m_pIB;

	tagVtxLocal()
	{
		pVtx = NULL;
		m_pVB = NULL;
		m_pIB = NULL;
	}

	~tagVtxLocal()
	{
		SAFE_DELETE_ARRAY(pVtx);
		SAFE_RELEASE(m_pVB);
		SAFE_RELEASE(m_pIB);
	}

}VtxLocal;



class CLocalMap  
{
public:
	PDTX	m_pTxBase[4];
	PDTX	m_pTxDetail;

	INT		m_nMapTileNum;
	INT		m_eOp;

public:
	FLOAT	m_fHScale;
	FLOAT	m_fDelta;
	VtxLocal	**	m_pBlock;

	INT		m_iNumBlockX;
	INT		m_iNumBlockZ;
	INT		m_iNumTileX;
	INT		m_iNumTileZ;
	INT		m_iWTileX;
	INT		m_iWTileZ;

	INT		m_iX;				// Map index
	INT		m_iZ;				// Map index

	INT		m_nIdxVertex;		// Position vertex Index start...

public:
	FLOAT GetHeight(VEC vecPos);
	CLocalMap();
	virtual ~CLocalMap();

	INT		Init();
	VOID	Destroy();

	INT		Restore();
	VOID	Invalidate();

	INT		FrameMove();
	
	VOID	Render();

	INT SetLocalMap();


private:
	INT InitWorld(TCHAR * sFile);
	void DestroyWorld();
	INT RestoreLocalVB();
	void InvalidateWorld();

};

#endif