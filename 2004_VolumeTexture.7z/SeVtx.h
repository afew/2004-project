#ifndef _SEVTX_H_
#define _SEVTX_H_

#define FVF_VTX				(D3DFVF_XYZ)
#define FVF_VTXN			(D3DFVF_XYZ|D3DFVF_NORMAL)
#define FVF_VTXND			(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE)
#define FVF_VTXD			(D3DFVF_XYZ|D3DFVF_DIFFUSE)
#define FVF_VTXUV			(D3DFVF_XYZ|D3DFVF_TEX1)
#define FVF_VTXDUV			(D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)
#define FVF_VTXRHW			(D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)
#define FVF_VTXNUV			(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX1)
#define FVF_VTXNDUV			(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1)
#define FVF_VTXNUV2			(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_TEX2)
#define FVF_VTXNDUV2		(D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX2)

#define FVF_VTXDUVW		(D3DFVF_XYZ | D3DFVF_DIFFUSE | D3DFVF_TEX1 | D3DFVF_TEXCOORDSIZE3(0) )

// Custom D3D vertex format used by the vertex buffer
typedef struct tagVtx
{
    VEC		p;// vertex position
	tagVtx()									{}
	tagVtx(VEC P)								{	p = P;							}
	tagVtx(FLOAT Px,FLOAT Py,FLOAT Pz)			{	p.x = Px; p.y = Py; p.z = Pz;	}
}Vtx;

typedef struct tagVtxN
{
    VEC		p;// vertex position
    VEC		n;// vertex normal

	tagVtxN(VEC P, VEC N)						{	p = P;	n = N;					}
	tagVtxN(FLOAT Px,FLOAT Py,FLOAT Pz
		,	FLOAT Nx,FLOAT Ny, FLOAT Nz)		{	p.x = Px; p.y = Py; p.z = Pz; n.x = Nx; n.y = Ny; n.z = Nz	;	}
}VtxN;


typedef struct tagVtxND
{
    VEC		p;
    VEC		n;
	DWORD	d;

	tagVtxND(VEC P, VEC N, DWORD D)				{	p = P;	n = N;	d = D;	}
	tagVtxND(FLOAT Px,FLOAT Py,FLOAT Pz
		,	FLOAT Nx,FLOAT Ny,FLOAT Nz,DWORD D)	{	p.x = Px; p.y = Py; p.z = Pz; n.x = Nx; n.y = Ny; n.z = Nz	;	d = D;	}
}VtxND;


typedef struct tagVtxD
{
	VEC		p;
	DWORD	d;
	
	tagVtxD()									{	p.x=p.y=p.z = 0.f;		d = 0xffffffff;		}
	tagVtxD(VEC P, DWORD D)						{	p = P;					d= D;				}
	tagVtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D)	{	p.x = X;	p.y = Y;	p.z = Z;	d = D;	}
}VtxD;



typedef struct tagVtxUV
{
	VEC		p;
	FLOAT	u,v;
	
	tagVtxUV()									{	p.x=p.y=p.z=0.0f;	u=v=0.0f;				}
	tagVtxUV(VEC P)								{	p=P;				u=v=0.0f;				}
	tagVtxUV(VEC P, FLOAT U, FLOAT V)			{	p=P;				u=U;	v=V;			}
	tagVtxUV(FLOAT X, FLOAT Y, FLOAT Z
			,FLOAT U, FLOAT V)					{	p.x=X; p.y=Y;p.z=Z;u=U;v=V;					}
	
}VtxUV;


typedef struct tagVtxwDUV
{
	VEC4	p;
	DWORD	d;
	FLOAT	u,v;

	tagVtxwDUV()	{}
	tagVtxwDUV(FLOAT X,FLOAT Y,FLOAT Z
			,FLOAT U,FLOAT V
			,DWORD D=0xFFFFFFFF)				{	p = VEC4(X, Y, Z, 1.f);	u=U; v=V; d = D;				}

}VtxwDUV, *PVtxwDUV;



typedef struct tagVtxDUV
{
	VEC		p;
	DWORD	d;
	FLOAT	u,v;
	
	tagVtxDUV()									{	p.x=p.y=p.z=0.0f;	u=v=0.0f;		d=0xffffffff;	}
	tagVtxDUV(VEC P)							{	p=P;				u=v=0.0f;		d=0xffffffff;	}
	tagVtxDUV(VEC P, DWORD D)					{	p=P;								d= D;			}
	tagVtxDUV(VEC P, FLOAT U, FLOAT V)			{	p=P;				u=U;v=V;		d=0xffffffff;	}
	tagVtxDUV(VEC P,FLOAT U,FLOAT V,DWORD D)	{	p=P;				u=U;v=V;		d=D;			}
	tagVtxDUV(FLOAT X, FLOAT Y, FLOAT Z
			, FLOAT U, FLOAT V)					{	p.x=X; p.y=Y;p.z=Z;u=U;v=V;	d=0xffffffff;			}
	tagVtxDUV(FLOAT X, FLOAT Y, FLOAT Z
			, FLOAT U, FLOAT V, DWORD D)		{	p.x=X; p.y=Y;p.z=Z;u=U;v=V;	d=D;					}
	
}VtxDUV;



typedef struct tagVtxNUV
{
	VEC		p;
	VEC		n;
	FLOAT	u,v;
	
	tagVtxNUV()									{	p.x=p.y=p.z=0.f;	n.x = n.y = n.z = 0.f;	u=v=0.0f;	}
	tagVtxNUV(VEC P,VEC N,FLOAT U,FLOAT V)		{	p = P;	n = N;	u = U;	v = V;							}
	tagVtxNUV(FLOAT X, FLOAT Y, FLOAT Z
			, FLOAT Nx, FLOAT Ny, FLOAT Nz
			, FLOAT U, FLOAT V)					{	p.x = X; p.y = Y; p.z = Z; n.x = Nx; n.y = Ny; n.z = Nz; u = U;	v = V;	}
}VtxNUV;



typedef struct tagVtxNUV2
{
	VEC		p;
	VEC		n;
	FLOAT	u1, v1;
	FLOAT	u2, v2;
	
	tagVtxNUV2()								{	p.x = p.y = p.z = 0.f;	n.x = n.y = n.z = 0.f;	u1  = v1  = 0.f;	u2  = v2  = 0.f;	}
	tagVtxNUV2(FLOAT X, FLOAT Y, FLOAT Z
			,  FLOAT Nx, FLOAT Ny, FLOAT Nz
			,  FLOAT U1, FLOAT V1
			,  FLOAT U2, FLOAT V2)				{	p.x = X; p.y = Y; p.z = Z; n.x = Nx; n.y = Ny;	n.z = Nz;	u1  = U1;	v1  = V1;	u2  = U2;	v2  = V2;	}
}VtxNUV2;



typedef struct tagVtxNDUV
{
	VEC		p;
	VEC		n;
	DWORD	d;
	FLOAT	u,v;
	
	tagVtxNDUV()								{	p.x = p.y = p.z = 0.f;	n.x = n.z = 0.f;	n.y = 1;	d	=0xffffffff;	u	= v = 0.0f;	}
	tagVtxNDUV(FLOAT X, FLOAT Y, FLOAT Z
			,  FLOAT Nx, FLOAT Ny, FLOAT Nz
			,  FLOAT U, FLOAT V, DWORD D)		{	p.x=X; p.y=Y; p.z=Z;	n.x=Nx;	n.y=Ny;	n.z = Nz;	u = U;	v  = V;	d = D;		}
	
}VtxNDUV;


typedef struct tagVtxNDUV2
{
	VEC		p;
	VEC		n;
	DWORD	d;
	FLOAT	u1, v1;																// �ٴ� Ÿ��
	FLOAT	u2, v2;																// Tile Set

	tagVtxNDUV2()								{	p.x = p.y = p.z = 0.f;	n.x = n.z = 0.f;	n.y = 1;	d	=0xffffffff;	u1	= v1 = u2 = v2 = 0.f;	}
	tagVtxNDUV2(FLOAT X, FLOAT Y, FLOAT Z
			,  FLOAT Nx, FLOAT Ny, FLOAT Nz
			,  FLOAT U1, FLOAT V1
			,  FLOAT U2, FLOAT V2, DWORD D)		{	p.x = X; p.y = Y;	p.z = Z; n.x = Nx;	n.y = Ny;	n.z = Nz;	u1 = U1; v1  = V1;	u2 = U2;	v2  = V2;	d = D;	}
}VtxNDUV2;


typedef struct tagVtxDUVW
{
	VEC		p;
	DWORD	d;
	FLOAT	u, v, w;
	tagVtxDUVW()	{}
	tagVtxDUVW(VEC P, FLOAT U, FLOAT V, FLOAT W, DWORD D = 0xFFFFFFFF)			{	p = P; u = U; v = V; w = w; d = D;				}
	
}VtxDUVW;

typedef struct tagVtxIdx
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	tagVtxIdx()									{	a = 0;		 b = 1;		 c = 2;			}
	tagVtxIdx(WORD A, WORD B, WORD C)			{	a = A;		 b = B;		 c = C;			}
	tagVtxIdx(WORD* R)							{	a = R[0];	 b = R[1];	 c = R[2];		}
}VtxIdx;

#endif