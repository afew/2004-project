// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFTTOOL_H_
#define _EFTTOOL_H_

INT_PTR CALLBACK WndAbout(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam);

class CMain : public CD3DApplication
{
public:
	CSeInput*	m_pInput;
	CSeCamera*	m_pCamera;
    ID3DXFont*	m_pDXFt;														// D3DX font
	VtxD*		m_pLine;
	CMcGrid*	m_pGrid;
	TCHAR		m_sMsg[512];
	CMcCrdL*	m_pCrd;															// Cardinal

	DWORD		m_dwFl;															// Fill mode
	bool		m_bFld;

	CMain();
    virtual ~CMain();
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice(D3DCAPS9*,DWORD,D3DFORMAT);
	LRESULT			MsgProc(HWND,UINT,WPARAM,LPARAM);

public:
	INT			m_nTxm;															//	Texture Mater... for Texture Managing
	INT			m_nTxs;															//	Texture Sub... for Texture Managing

public:
	void		XYZInit();
	void		XYZDestroy();
	void		XYZRender();
	
	void		TreeExpand(lsHItem& ls, HWND& hTree, INT iM, INT iS);	
};

#endif _EFTTOOL_H_