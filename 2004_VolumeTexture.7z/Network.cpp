///////////////////////////////////////////////////////////////////////////////
//
// Explain:  Network...
// Date : 2003-04-18, Author: SR OnLine
// History:


#include "Common.h"


CNetwork::CNetwork()
{
	m_bIsConnect= false;
	m_bIsReceive= false;
	m_iNumPc	= -1;								// number of monster
	m_iNumMon	= -1;								// number of player
	
	memset(m_szUsrId,	0, sizeof(m_szUsrId));		// User id
	memset(m_szUsrPwd,	0, sizeof(m_szUsrPwd));		// user Pwd
	memset(m_szServerIP,0, sizeof(m_szServerIP));	// server ip
	memset(m_szPort,	0, sizeof(m_szPort));		// port
	
	//	g_hExit = CreateEvent(NULL, TRUE, FALSE, NULL);
}



CNetwork::~CNetwork()
{
}


INT CNetwork::Destroy()
{
	for(int i=0; i<m_vPc.size(); ++i)
		delete m_vPc[i];

	m_vPc.clear();

	return 1;
}



INT CNetwork::Init()
{
	m_iNumPc	= 1;								// number of monster
	m_iNumMon	= 2;								// number of player
	m_iNumNpc	= 2;								// number of NPC
	
	PSPcInfo	p = NULL;
	
	for(int i=0; i<m_iNumPc ; ++i)
	{
		p = new SPcInfo;
		m_vPc.push_back(p);
	}
	
	strcpy(m_vPc[0]->UsrID, g_BaseInfo.UsrID);
	
	return 1;
}

INT CNetwork::Restore()
{
	return 1;
}



INT CNetwork::FrameMove()
{

	return 1;
}

INT CNetwork::ConnectServer()
{
	return 1;
}

INT CNetwork::IsConnect()
{
	return 1;
}






void CNetwork::NetworkConnection()
{	
}




void CNetwork::SendLogin()
{
	//	TCHAR buf[128];
	//	DWORD size = 0;
	//
	//	buf[0] = strlen(m_szUsrId);
	//	strcpy(&buf[1], m_szUsrId);
	//	buf[strlen(m_szUsrId) + 1] = strlen(m_szUsrPwd);
	//	strcpy(&buf[strlen(m_szUsrId) + 2], m_szUsrPwd);
	//
	//	size = strlen(buf); //len(1)+Userid(18)+len(1)+Passwd(18)
	//
	//	g_pClientSocket->Send(CS_REQ_LOGIN, buf, size);
	
	
	TCHAR buf[128];
	DWORD size = 0;
	
	memset(buf, 0, sizeof(buf));
	
	
	buf[0] = strlen(m_szUsrId);
	memcpy(buf+1, m_szUsrId, buf[0]);
	
	buf[buf[0] + 1] = strlen(m_szUsrPwd);
	memcpy(buf + buf[0] + 2, m_szUsrPwd, buf[buf[0] + 1]);
	
	size = buf[0]  + buf[buf[0] + 1] + 2;
	
}



//#define CS_REQ_INITIALIZE		(CS_BASE_OFFSET + 0x0001)
// MSG+x(4)+z(4)+len(1)+Userid(18)

void CNetwork::SendInit()
{
	TCHAR buf[128];
	memset(buf, 0, sizeof(buf));
	
	((INT *)buf)[0] = INT(GCAMERA->m_vecMaster.x);
	((INT *)buf)[1] = INT(GCAMERA->m_vecMaster.z);
	
	buf[8] = strlen(m_szUsrId) + 1;
	
	memcpy(buf+9,  m_szUsrId, buf[8]);
}

//#define CS_MOVE_CHAR			(CS_BASE_OFFSET + 0x0004)
// MSG+x(4)+z(4)+len(1)+Userid(18)

void CNetwork::SendMove()
{
	TCHAR buf[128];
	memset(buf, 0, sizeof(buf));
	
	((INT *)buf)[0] = INT(GCAMERA->m_vecMaster.x);
	((INT *)buf)[1] = INT(GCAMERA->m_vecMaster.z);
	
	buf[8] = strlen(m_szUsrId) + 1;
	
	memcpy(buf+9,  m_szUsrId, size_t(buf[8]));
}