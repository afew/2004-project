
#include "_StdAfx.h"

void McUtil_TextOut(HDC hDC, float x, float y, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	TextOut(hDC, INT(x), INT(y), s, strlen(s));
}


int SeUtil_GetTextXW(HDC hDC, HFONT hFont, char *str)
{
	SIZE		sz;
	TEXTMETRIC	tm;
	int			xw = 0;

	if (hDC == NULL || hFont == NULL)
		return 0;
	
	SelectObject(hDC, hFont);
	
	GetTextExtentPoint32(hDC, str, strlen(str), &sz);
	xw += sz.cx; 
	
	GetTextMetrics(hDC, &tm);
	xw -= tm.tmOverhang;
	
	return(xw);
}


void McUtil_SetWindowTitle(const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(GHWND, s);
}