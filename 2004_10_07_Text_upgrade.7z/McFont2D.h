// Interface for the CMcFont2D class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCFONT2D_H_
#define _MCFONT2D_H_

typedef LPDIRECT3DTEXTURE9	PDTX;
typedef LPDIRECT3DSURFACE9	PDSF;


typedef enum tagEFntAlgn														// Font Align
{
	FNT_ALIGN_H_L	= 0x00000000,												// Horizontal Left align
	FNT_ALIGN_H_R	= 0x00000001,												// Horizontal Right align
	FNT_ALIGN_H_C	= 0x00000002,												// Horizontal center

	FNT_ALIGN_V_T	= 0x00000000,												// vertical Top
	FNT_ALIGN_V_B	= 0x00000004,												// vertical bottom
	FNT_ALIGN_V_C	= 0x00000008,												// vertical center
}EFntAlgn;

class CMcFont2D
{
protected:
	PDTX	m_pTxD;
	INT		m_iH;
	INT		m_iW;
	INT		m_iLen;
	TCHAR	m_sStr[512];
	RECT	m_rt;

	HFONT	m_hFnt;
	HFONT	m_hFntI;
	HFONT	m_hFntO;

	DWORD	m_dwFrnt;															// front color
	DWORD	m_dwBack;															// back color

	INT		m_iThickX;
	INT		m_iThickY;

	VEC2	m_vcP;
	VEC2	m_vcA;																// Align pos

public:
	CMcFont2D();
	~CMcFont2D();

	INT		SetString(	TCHAR* sStr,VEC2 vcPos=VEC2(0, 100), HFONT hFont=NULL, DWORD dwFrnt=0x00FFFF00,	DWORD dwBack=0x00323200, INT iThickX=1, INT iThickY=1);

	void	SetPos(VEC2	vcPos, DWORD dwAlign = (FNT_ALIGN_H_L| FNT_ALIGN_V_T));

	INT		SetColor(DWORD	dwFrnt = RGB(255, 255,  0),  DWORD	dwBack = RGB( 0,  0,    0));
	INT		SetColorFrnt(	DWORD	dwFrnt = RGB(255, 255,  0));
	INT		SetColorBack(	DWORD	dwBack = RGB( 0,  0,    0));
	
	void	DrawTxt();

protected:
	INT		SetTexture();
};

typedef class CMcFont2D *LPSE2DFONT;

#endif
