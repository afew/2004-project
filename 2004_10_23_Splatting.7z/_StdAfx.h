// The Header Files.
//
////////////////////////////////////////////////////////////////////////////////

#pragma once

#ifndef _MCCOMMON_H_
#define _MCCOMMON_H_

#define STRICT

#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)
#pragma warning( disable : 4996)

#include <vector>
#include <set>
#include <map>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;

#include <shlobj.h>
#include <shellapi.h>
#include <windows.h>
#include <windowsx.h>
#include <mmsystem.h>
#include <stdio.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr.h>
#include <tchar.h>
#include <malloc.h>

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>

#include "DXUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DUtil.h"
#include "resource.h"


#include "McBaseType.h"
#include "McVtxFormat.h"

#define GAME_SPF 0.033f	//30 frame/sec

#define GHINST					g_pApp->m_hInst
#define GHWND					g_pApp->m_hWnd
#define GHDC					g_pApp->m_hDC
#define GMAIN					g_pApp
#define GDEVICE					g_pApp->m_pd3dDevice
#define GSPRITE					g_pApp->m_pd3dSprite

#define GELAPSEDFPS				g_pApp->m_fElapsedFPS

#define GINPUT					g_pApp->m_pInput
#define GCAMERA					g_pApp->m_pCamera


// for Mouse and keyboard
#define GET_KEY(key)			if(GINPUT && GINPUT->GetKey(key))
#define KEY_STATE(key)			if(GINPUT && GINPUT->KeyState(key))
#define BUTTON_STATE(button)	if(GINPUT && GINPUT->ButtonState(button))
#define BUTTON_DOWN(button)		if(GINPUT && GINPUT->ButtonDown(button))
#define BUTTON_UP(button)		if(GINPUT && GINPUT->ButtonUp(button))
#define MOUSE_WHEEL				GINPUT->GetMouseState( 2 )


#include "McMath.h"
#include "McUtil.h"
#include "McXYZ.h"
#include "McInput.h"
#include "McCamera.h"

#include "McGrid.h"
#include "McSplat.h"
#include "McSplt.h"
#include "EftTool.h"

extern CMain* g_pApp;

#endif