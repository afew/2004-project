// Interface for the CSeCamera class.
// Date: 2003-04-12, Author: SR OnLine
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _SECAMERA_H_
#define _SECAMERA_H_


class CSeCamera
{
public:
	MAT		m_matView;															// view matrix
	MAT		m_matViewInv;														// inverse view matrix
	MAT		m_matProj;															// projection matrix

	MAT		m_matBill;															// Billboard for All
	MAT		m_matBillY;															// Billboard for Y

	VEC3	m_vecXAxis;
	VEC3	m_vecYAxis;
	VEC3	m_vecZAxis;

	VEC3	m_vecEyePt;															// Camera position
	VEC3	m_vecLookAt;														// Camera look at vector
	VEC3	m_vecUp;															// Camera up vector

	VEC3	m_vecPickRayOrig;													// Ray Position
	VEC3	m_vecMaster;														// ���ΰ� ĳ��������ġ

	FLOAT	m_fFov;
	FLOAT	m_fAspect;
	FLOAT	m_fNear;
	FLOAT	m_fFar;

	FLOAT	m_fYaw;
	FLOAT	m_fPitch;

	FLOAT	m_fZoom;

	TCHAR	m_szName[64];

	FLOAT	m_fAngleView;														// View Angle (Radian)

public:
	FLOAT	m_fR;																// ī�޶� �浹 �ݰ�. 

	//(E) AFEW for vibration..
	DWORD	m_dwStart;
	FLOAT	m_fD;

	VEC3	m_vcAxisX;
	VEC3	m_vcAxisY;
	VEC3	m_vcAxisZ;

public:
	CSeCamera();
	~CSeCamera();

	INT		Init();

	INT		Restore();

	INT		FrameMove();
	INT		FrameMoveInPortal();
	void	Update();

public:
	void	SetMasterCamera(const FLOAT	_fYvalue);
	TCHAR *	GetName()									{	return m_szName;			}
	MAT		GetViewMatrix()								{	return m_matView;			}
	MAT		GetViewMatrixInv()							{	return m_matViewInv;		}
	MAT		GetProjMatrix()								{	return m_matProj;			}
	
	MAT		GetBillboard()								{	return m_matBill;			}
	MAT		GetBillboardY()								{	return m_matBillY;			}

	VEC3	GetAxisX()									{	return m_vcAxisX;			}
	VEC3	GetAxisY()									{	return m_vcAxisY;			}
	VEC3	GetAxisZ()									{	return m_vcAxisZ;			}
	VEC3	GetPos()									{	return m_vecPickRayOrig;	}
	VEC3	GetRayDir();
	VEC3	GetRayOrg()									{	return m_vecPickRayOrig;	}

	void	RotationXAxis(FLOAT	fAngle);
	void	RotationYAxis(FLOAT	fAngle);
	void	RotationZAxis(FLOAT	fAngle);
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveUpward(FLOAT	fSpeed);
	void	MoveForward(FLOAT	fSpeed);
	void	SetPosition(VEC3	vPos);
	void	SetProjParam();
	void	SetName(TCHAR* szName);
	void	SetDelta(FLOAT len=0);
};

#endif