// Implementation of the Utility Functions.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"



void McUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);
}



void McUtil_GetLastError(HWND hWnd)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
				  NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
				  (LPTSTR) &lpMsgBuf, 0, NULL);
	MessageBox(hWnd, (LPTSTR)lpMsgBuf, "GetLastError", MB_OK|MB_ICONERROR);
	LocalFree(lpMsgBuf);
}



char *getSmallTime(void)
{
	static char tm_str[128 + 1];
	SYSTEMTIME st;

	GetLocalTime(&st);
	strcpy(tm_str,
		McUtil_Forming("'%04d-%02d-%02d\t'%02d:%02d:%02d.%03d",
		//McUtil_Forming("%04dy\t%02dm %02dd\t%02dh %02dm\t%02d.%03ds",
		(INT)st.wYear, (INT)st.wMonth, (INT)st.wDay,
		(INT)st.wHour, (INT)st.wMinute, (INT)st.wSecond, (INT)st.wMilliseconds));

	return(tm_str);
} /* getSmallTime */


void McUtil_FormatLog(TCHAR *format,...)
{
	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log.txt", "a+");
	
	fprintf(fp, "%s\t%s\n", getSmallTime(), szDbgBuf);

	fclose(fp);
	// ���� ���   
}


void McUtil_FormatLog2(TCHAR *format,...)
{
//	if (!g_BaseInfo.File_Log) return;
	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log_2.txt", "a+");
	
	fprintf(fp, "%s\t%s\n", getSmallTime(), szDbgBuf);

	fclose(fp);
	// ���� ���   
}


// Texture Load
INT McUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color, D3DXIMAGE_INFO *pSrcInfo, DWORD Filter, DWORD MipFilter, D3DFORMAT d3dFormat)
{
//	HRESULT D3DXCreateTextureFromFileEx(
//	LPDIRECT3DDEVICE9 pDevice,
//    LPCTSTR pSrcFile,
//    UINT Width,
//    UINT Height,
//    UINT MipLevels,
//    DWORD Usage,
//    D3DFORMAT Format,
//    D3DPOOL Pool,
//    DWORD Filter,
//    DWORD MipFilter,
//    D3DCOLOR ColorKey,
//    D3DXIMAGE_INFO *pSrcInfo,
//    PALETTEENTRY *pPalette,
//    LPDIRECT3DTEXTURE9 *ppTexture
//);
	
	if ( FAILED(D3DXCreateTextureFromFileEx(
		GDEVICE
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat	//, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)) )
	{
		texture = NULL;
		return -1;
	}
	
	return 1;
}





void McUtil_ReadFileLine(FILE *fp, TCHAR *str, INT nStr)
{
	static TCHAR sTmp1[1024];
	static TCHAR sTmp2[1024];
	
	INT nSize;
	INT nStart, nEnd;
	UINT i, j, k;

	memset(sTmp1,0, sizeof(sTmp1));
	memset(sTmp2,0, sizeof(sTmp2));

	fgets(str, nStr, fp);

	nSize = strlen(str);
	
	for(i=0; i<strlen(str); ++i)
	{
		if(str[i] == '\t')	str[i] =' ';
//		if(str[i] == '"')	str[i] =' ';
		
		if(str[i] == '\n' || str[i] == '\r')
		{
			for(j=i; j<strlen(str); ++j)
				str[j] ='\0';
		}
	}
	
	nStart=0;
	nEnd= strlen(str);
	
	for(i=0; i<strlen(str); ++i){	if(str[i] != ' ')	{	nStart =i;	break;	}	}
	for(i=0; i<strlen(str); ++i){	if(str[i] == '\0')	{	nEnd =i;	break;	}	}
	
	strncpy(sTmp1, str + nStart, nEnd-nStart);
	
	j=0;
	for(k=0; k<nEnd-nStart+1; ++k)
	{
		if( !(' ' ==sTmp1[k] &&' ' ==sTmp1[k+1]))
		{
			if( ' ' ==sTmp1[k] && '\0'==sTmp1[k+1])
				sTmp2[j]= '\0';
			
			else
				sTmp2[j]= sTmp1[k];
			
			++j;
		}
	}
	
	strcpy(str, sTmp2);
}


void McUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC)
{
	TCHAR*	p;
	INT iS;
	INT iE;
	INT iD;

	// Search forward
	p = strchr(strIn, iC);
	iS = p - strIn + 1;

	if(!p)
	{
		strOut[0]=0;
		return;
	}

	// Search backward
	p = strrchr( strIn, iC);

	iE = p - strIn + 1;

	if(iS != iE)
		iD = iE - iS -1;

	else
		iD = strlen(strIn) - iS;

	strncpy(strOut, strIn+iS, iD);
	strOut[iD]=0;
}


void McUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateVertexBuffer(nSize,
		0,
		fvf,
		usage,
		&pVB, NULL );
	
	if( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Vertex create failed");
		return ;
	}
	
	if(!pVtx)
		return;

	McUtil_VBLock(pVB, nSize, pVtx);
}


void McUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx)
{
	void* p;
	
	if( FAILED( pVB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy( p, pVtx, nSize);
	pVB->Unlock();
}


void McUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx, D3DFORMAT fmt, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateIndexBuffer( nSize, 0, fmt, usage, &pIB, NULL);
	
	if( FAILED(hr) )
	{
		McUtil_ErrMsgBox("Index buffer create failed");
		return ;
	}
	
	if(!pIdx)
		return;

	McUtil_IBLock(pIB, nSize, pIdx);
}


void McUtil_IBLock(PDIB & pIB, INT nSize, void* pIdx)
{
	void* p;
	
	if( FAILED( pIB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy(p, pIdx, nSize);
	pIB->Unlock();
}



bool McUtil_LineCross2D(D3DXVECTOR2 * p)
{
	D3DXVECTOR2 L1 = p[1] - p[0];
	D3DXVECTOR2 L2 = p[3] - p[2];
	D3DXVECTOR2 L3 = p[2] - p[0];
	
	
	FLOAT fAlpha = L2.x * L1.y - L2.y * L1.x;
	
	if(0.f == fAlpha)
		return false;
	
	FLOAT fBeta = fAlpha;
	
	fAlpha = (L2.x * L3.y - L2.y * L3.x)/fAlpha;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	fBeta = (L2.x * L3.y - L1.y * L3.x)/fBeta;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	return true;
}

INT McUtil_3Dto2D(D3DXVECTOR3& Out, const D3DXVECTOR3& In)
{
	D3DXMATRIX		mtV;																// View matrix
	D3DXMATRIX		mtP;																// Projection matrix
	D3DXMATRIX		mtVP;																// view matrix * projection matrix
	D3DXVECTOR3	vcPc;																// Camera pos
	D3DXVECTOR3	vcZ;																// Normal vector
	FLOAT	fNear=1.f;
	FLOAT	beta;
	D3DXVECTOR3	vcB;
	FLOAT	fW;
	FLOAT	fH;

	mtV		= GCAMERA->GetViewMatrix();
	mtP		= GCAMERA->GetProjMatrix();
	vcPc	= GCAMERA->GetRayOrg();
	vcZ		= GCAMERA->GetAxisZ();
	
	beta	= D3DXVec3Dot(&vcZ, &(In - vcPc));
	
	if(beta<=fNear)
		return 0;			// �������� ��� �ڿ� ����.

	beta = fNear/beta;
	vcB = beta * (In - vcPc) -fNear * vcZ;

	D3DXMatrixMultiply(&mtVP, &mtV, &mtP);
	
	Out.x	= vcB.x * mtVP._11 + vcB.y * mtVP._21 + vcB.z * mtVP._31;			// ���� Model view Matrix�� �����Ѵ�.
	Out.y	= vcB.x * mtVP._12 + vcB.y * mtVP._22 + vcB.z * mtVP._32;
	Out.z	= vcB.x * mtVP._13 + vcB.y * mtVP._23 + vcB.z * mtVP._33;
	
	fW		= FLOAT(GMAIN->m_dwCreationWidth);									//�������� ȭ�� scale�� Projection�Ѵ�.
	fH		= FLOAT(GMAIN->m_dwCreationHeight);
	
	Out.x	=  fW * (Out.x +1.f) * 0.5f;
	Out.y	= -fH * (Out.y -1.f) * 0.5f;

	return 1;
}





bool McUtil_PositionMouse3D(D3DXVECTOR3& vec3dOut)
{
	D3DXMATRIX matView;
	D3DXMATRIX matProj;
	D3DXMATRIX matViewProj;
	D3DXMATRIX matViewInv;
	
	D3DXMATRIX matViewProjInv;
	
	GDEVICE->GetTransform(D3DTS_VIEW, &matView);
	GDEVICE->GetTransform(D3DTS_PROJECTION,&matProj);
	
	D3DXMatrixIdentity(&matViewProj);
	
	matViewProj = matView * matProj;
	D3DXMatrixInverse(&matViewProjInv, NULL, &matViewProj);
	
	POINT	pt;
	RECT	rt;
	
	::GetCursorPos(&pt);
	::GetWindowRect(GHWND, &rt);
	
	D3DXVECTOR3 vecBefore( 2.f * pt.x /FLOAT(rt.right-rt.left) -1,
		-2.f * pt.y /FLOAT(rt.bottom - rt.top) +1,
		0);
	
	D3DXVECTOR3 vecP(0,0,0);
	
	
	// ���� Model view Matrix�� �����Ѵ�.
	
	vecP.x = vecBefore.x * matViewProjInv._11 + vecBefore.y * matViewProjInv._21 + vecBefore.z * matViewProjInv._31;
	vecP.y = vecBefore.x * matViewProjInv._12 + vecBefore.y * matViewProjInv._22 + vecBefore.z * matViewProjInv._32;
	vecP.z = vecBefore.x * matViewProjInv._13 + vecBefore.y * matViewProjInv._23 + vecBefore.z * matViewProjInv._33;
	
	//camera position
	D3DXMatrixInverse(&matViewInv, NULL, &matView);
	D3DXVECTOR3 vecCamPos(matViewInv._41, matViewInv._42, matViewInv._43);
	
	//Normalvector
	D3DXVECTOR3 vecZ( matView._13, matView._23, matView._33);
	
	FLOAT beta =(vecZ.y + vecP.y);
	
	if (0.f == beta)
		return false;
	
	beta =  -vecCamPos.y/beta;
	
	vec3dOut = beta * (vecZ + vecP) + vecCamPos;
	
	return true;
}


INT McUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color)
{	
	HDC hDC;
	LPDIRECT3DSURFACE9 Surface;
	
	if(FAILED(GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &Surface)))
		return -1;
	
	Surface->GetDC(&hDC);
	
	if(NULL != hDC)
	{
		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, _color);
		TextOut(hDC, X, Y, Text, strlen(Text));

		Surface->ReleaseDC(hDC);
	}
	
	Surface->Release(); //�����Ѵ�.
	
	
	return 1;
}


void McUtil_SetWindowTitle(const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(GHWND, s);
}



void McUtil_TextOut(float x, float y, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	TextOut(GHDC, INT(x), INT(y), s, strlen(s));
}


void McUtil_TextOut(D3DXVECTOR2 p, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	TextOut(GHDC, INT(p.x), INT(p.y), s, strlen(s));
}




void McUtil_OutputDebug(const char * format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	::OutputDebugString(s);
}



TCHAR*	McUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR* sTitle)
{
	BROWSEINFO		bi;
	static TCHAR	sPathName[1024];
	static TCHAR	sPathFull[1024];
	LPITEMIDLIST	pidl = NULL;
	LPITEMIDLIST	pidlFolder= NULL;
	LPMALLOC		pMalloc = NULL;

	memset(sPathName, 0, sizeof(sPathName));
	memset(sPathFull, 0, sizeof(sPathFull));
	memset(&bi, 0, sizeof(BROWSEINFO));

	bi.hwndOwner = hWnd;
	bi.lpszTitle = sTitle;
	bi.ulFlags = BIF_STATUSTEXT |BIF_EDITBOX   ;
	bi.ulFlags = BIF_EDITBOX   ;

	GetCurrentDirectory(1024, sPathFull);

	LPSHELLFOLDER pShellFolder = NULL;
	OLECHAR wszPath[MAX_PATH] = {0};
	ULONG nCharsParsed = 0;
	
	// Get an IShellFolder interface pointer
	::SHGetDesktopFolder(&pShellFolder);
	
	// Convert the path name to Unicode
	::MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, sPathFull, -1, wszPath, MAX_PATH);
	
	// Call ParseDisplayName() to do the job
	pShellFolder->ParseDisplayName(NULL, NULL, wszPath, &nCharsParsed, &pidl, NULL);

	bi.pidlRoot = pidl;


	pidlFolder = SHBrowseForFolder(&bi);

	if(pidlFolder == NULL)
	{
		sPath[0] =0;
		sPathFull[0];
		return sPathFull;														//����� ���
	}

	SHGetPathFromIDList(pidlFolder, sPathName);

	strcpy(sPath, sPathName);
	strcpy(sPathFull, sPathName);

	SHGetMalloc(&pMalloc);
	pMalloc->Free(pidl);
	pMalloc->Free(pidlFolder);
	pMalloc->Release();

	return sPathFull;
}


TCHAR*	McUtil_DWtoStr(DWORD dwA)
{
	static char		s[64];
	static char*	pDst;

	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", dwA);
	pDst = s + strlen(s) - 8;

	return pDst;
}


void SetDlgItemFlt(HWND hWnd, UINT id, float z, INT decimal)
{
	char s[128];
	char f[64];
	
	sprintf(f,"%%.%df", decimal);
	memset(s, 0, sizeof(s));
	sprintf(s, f, z);
	SetDlgItemText(hWnd,id,s);
}

FLOAT GetDlgItemFlt(HWND hWnd, UINT id)
{
	char s[256];
	memset(s, 0, sizeof(s));

	GetDlgItemText(hWnd, id, s, sizeof(s));
	return atof(s);
}

void SetDlgItemHex(HWND hWnd, UINT id, INT val)
{
	char	buf[64] = "0x";
	char	s[32];
	char*	pDst;
	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", val);
	pDst = s + strlen(s) - 8;

	strcat(buf, pDst);
	SetDlgItemText(hWnd,id,buf);
}


char*	McUtil_Forming(const char *fmt, ...)
{
#define FORMING_1CALL_STR_TOTAL 512
#define FORMING_RECALL_TOTAL 100
#define FORMING_BUF_TOTAL (FORMING_1CALL_STR_TOTAL * FORMING_RECALL_TOTAL)
	static char formingbuf[FORMING_BUF_TOTAL], formingfmt[FORMING_1CALL_STR_TOTAL + 1];
	static INT index_formingbuf;
	va_list arglist;
	char *strp;
	
	va_start(arglist, fmt);
	vsprintf(formingfmt, fmt, arglist);
	va_end(arglist);
	if (index_formingbuf + strlen(formingfmt) + 1 >= FORMING_BUF_TOTAL) index_formingbuf = 0;
	strp = formingbuf + index_formingbuf;
	strcpy(strp, formingfmt);
	index_formingbuf += strlen(formingfmt) + 1;
	return(strp);
}

