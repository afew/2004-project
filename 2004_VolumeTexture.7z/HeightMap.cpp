// HeightMap.cpp: implementation of the CTblHeightMap class.
//
//////////////////////////////////////////////////////////////////////

#include "Common.h"


// Construction/Destruction

CHeight::CHeight()
{
	// for line....
	m_pVBGrid	= NULL;
	m_pVBAxis	= NULL;
	m_pVBPick	= NULL;
	m_pLineGrid	= NULL;
	m_nCntLine	= -1;
	
	memset(&m_vecPickPos, 0, sizeof(VEC));
}

CHeight::~CHeight()
{
	Destroy();
	Invalidate();
}


VOID CHeight::Destroy()
{
	SAFE_DELETE_ARRAY(m_pLineGrid);
}


INT CHeight::Init()
{
	m_LineAxis[0] = VtxD(   -50.f,      0.f,	  0.f, 0xffff0000);
	m_LineAxis[1] = VtxD( 10000.f,      0.f,	  0.f, 0xffff0000);
	m_LineAxis[2] = VtxD(     0.f,    -50.f,     0.f, 0xff00ff00);
	m_LineAxis[3] = VtxD(     0.f,  10000.f,     0.f, 0xff00ff00);
	m_LineAxis[4] = VtxD(     0.f,      0.f, 10000.f, 0xff0000ff);
	m_LineAxis[5] = VtxD(     0.f,      0.f,   -50.f, 0xff0000ff);
	
	m_vecDelta[0] = VEC( -3.f,  0.f, -3.f);
	m_vecDelta[1] = VEC( -3.f,  0.f,  3.f);
	m_vecDelta[2] = VEC(  3.f,  0.f,  3.f);
	m_vecDelta[3] = VEC(  3.f,  0.f, -3.f);
	m_vecDelta[4] = m_vecDelta[0];

	

	// for grid...
	INT iNumGridX = TBLMAP->m_iNumGridX;
	INT iNumGridZ = TBLMAP->m_iNumGridZ;
	
	INT	iWidthX = TBLMAP->m_iWidthGridX;
	INT	iWidthZ = TBLMAP->m_iWidthGridZ;
	
	m_nCntLine = (iNumGridX +1 + iNumGridZ + 1 ) * 2;
	m_pLineGrid = new VtxD[m_nCntLine];
	
	INT nIdx=0;
	
	for(int i=0; i<(iNumGridZ+1); ++i)
	{
		m_pLineGrid[nIdx+0] = VtxD( 0.f,                       -10.f, FLOAT(i * iWidthZ), 0x55555555);
		m_pLineGrid[nIdx+1] = VtxD( FLOAT(iNumGridX * iWidthX),-10.f, FLOAT(i * iWidthZ), 0x55555555);
		
		nIdx +=2;
	}
	
	for(int j=0; j<(iNumGridX+1); ++j)
	{
		m_pLineGrid[nIdx+0] = VtxD( FLOAT(j * iWidthX),-10.f,                        0.f, 0x55555555);
		m_pLineGrid[nIdx+1] = VtxD( FLOAT(j * iWidthX),-10.f, FLOAT(iNumGridZ * iWidthZ), 0x55555555);
		
		nIdx +=2;
	}
	

	m_vecPickRegion[0] = VEC(                       0, 0,                        0);
	m_vecPickRegion[1] = VEC(                       0, 0, FLOAT(iNumGridZ*iWidthZ));
	m_vecPickRegion[2] = VEC(FLOAT(iNumGridX*iWidthX), 0,                        0);
	m_vecPickRegion[3] = VEC(FLOAT(iNumGridX*iWidthX), 0, FLOAT(iNumGridZ*iWidthZ));
	
	return 1;
}




INT CHeight::Restore()
{
	SeUtil_VBCreate(m_pVBAxis, 6 * sizeof(VtxD), FVF_VTXD,	m_LineAxis);
	SeUtil_VBCreate(m_pVBPick, 5 * sizeof(VtxD), FVF_VTXD,	m_LinePick);
	SeUtil_VBCreate(m_pVBGrid, m_nCntLine * sizeof(VtxD),	FVF_VTXD, m_pLineGrid);

	return 1;
}


VOID CHeight::Invalidate()
{
	SAFE_RELEASE(m_pVBGrid);
	SAFE_RELEASE(m_pVBAxis);
	SAFE_RELEASE(m_pVBPick);
}



INT CHeight::FrameMove()
{
	return 1;
}

VEC CHeight::GetPickPos()
{
	// �Ӽ� Ÿ���� �ε����� �����Ѵ�.
	TCHAR sTmp[256] = "\0";
	
	INT		iNumGridX = TBLMAP->m_iNumGridX;
	INT		iNumGridZ = TBLMAP->m_iNumGridZ;
	
	INT		iWidthX = TBLMAP->m_iWidthGridX;
	INT		iWidthZ = TBLMAP->m_iWidthGridZ;
	
	INT		i;
	INT		iScnW, iScnH;
	POINT	pt = GINPUT->MousePos;
	RECT	rt;
	
	FLOAT	fU, fV, fDist;
	MAT		matView, matViewInv, matProj;
	VEC		vecScnPos;
	VEC		vecPickRayDir;
	VEC		vecPickRayOrig;

	VEC		vecPickPos(0,-1000,0);
	
	matProj = GCAMERA->GetProjMatrix();
	
	//		::GetCursorPos( &pt );
	::GetClientRect(GHWND, &rt);
	
	iScnW = rt.right - rt.left;
	iScnH = rt.bottom- rt.top;
	
	
	// Get the pick ray from the mouse position
	
	vecScnPos.x =  ( ( ( 2.0f * pt.x ) / iScnW ) - 1 ) / matProj._11;
	vecScnPos.y = -( ( ( 2.0f * pt.y ) / iScnH ) - 1 ) / matProj._22;
	vecScnPos.z =  1.0f;
	
	// Get the inverse view matrix
	matView = GCAMERA->GetViewMatrix();
	D3DXMatrixInverse( &matViewInv, NULL, &matView );
	
	// Transform the screen space pick ray into 3D space
	
	vecPickRayDir.x  = vecScnPos.x * matViewInv._11 + vecScnPos.y * matViewInv._21 + vecScnPos.z * matViewInv._31;
	vecPickRayDir.y  = vecScnPos.x * matViewInv._12 + vecScnPos.y * matViewInv._22 + vecScnPos.z * matViewInv._32;
	vecPickRayDir.z  = vecScnPos.x * matViewInv._13 + vecScnPos.y * matViewInv._23 + vecScnPos.z * matViewInv._33;
	vecPickRayOrig.x = matViewInv._41;
	vecPickRayOrig.y = matViewInv._42;
	vecPickRayOrig.z = matViewInv._43;
	
	// 1->2->0
	// 1->3->2
	//
	//	1-------3
	//	| .     |
	//  |   .   |
	//	|     . |
	//	0-------2
	
	if ( D3DXIntersectTri(
		&m_vecPickRegion[0],
		&m_vecPickRegion[1],
		&m_vecPickRegion[2],
		&vecPickRayOrig,
		&vecPickRayDir,
		&fU,
		&fV,
		&fDist
		) )
	{
		vecPickPos = m_vecPickRegion[0]
			+ VEC(fV * iNumGridX * iWidthX, 0.0f, fU * iNumGridZ * iWidthZ);
	}
	
	else if ( D3DXIntersectTri(
		&m_vecPickRegion[3],
		&m_vecPickRegion[2],
		&m_vecPickRegion[1],
		&vecPickRayOrig,
		&vecPickRayDir,
		&fU,
		&fV,
		&fDist
		) )
	{
		vecPickPos = m_vecPickRegion[3]
			- VEC(fV * iNumGridX * iWidthX, 0.0f, fU * iNumGridZ * iWidthZ);
	}
	
	else
	{// ��ŷ ������ �ƴ�.
		return VEC(0,-1000,0);
	}
	
	
	// �簢���� �׸���.
	for(i=0; i<5; ++i)
		m_LinePick[i].p = vecPickPos + m_vecDelta[i];
	
	
	SeUtil_BufferCopy(m_pVBPick, 5 * sizeof(VtxD), m_LinePick);
	
	sprintf(sTmp, "%5.f %5.f %5.f"
		, vecPickPos.x
		, vecPickPos.y
		, vecPickPos.z);
	
	SetWindowText(GHWND, sTmp);

	m_nIdxGridX = INT(vecPickPos.x/iWidthX);
	m_nIdxGridZ = INT(vecPickPos.z/iWidthZ);
	
	CTblHeightMap::UMapAttrib MapAttrib = TBLMAP->GetMapAttrib(vecPickPos);

	sprintf(sTmp, "HeightMap Attrib: %u", MapAttrib.m_dwAttrib);
	
//		SetWindowText(GHWND, sTmp);

	return vecPickPos;
}



VOID CHeight::Render()
{
	MAT matWorld;
	INT iNumGridX = TBLMAP->m_iNumGridX;
	INT iNumGridZ = TBLMAP->m_iNumGridZ;
	
	D3DXMatrixIdentity(&matWorld);
	GDEVICE->SetTransform(D3DTS_WORLD, &matWorld);
	
	GDEVICE->SetRenderState(D3DRS_FOGENABLE, FALSE);
	
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetFVF(FVF_VTXD);
	
	GDEVICE->SetStreamSource( 0, m_pVBAxis, 0, sizeof(VtxD));
	GDEVICE->DrawPrimitive(D3DPT_LINELIST,0, 3);
	
	GDEVICE->SetStreamSource( 0, m_pVBGrid, 0, sizeof(VtxD));
	GDEVICE->DrawPrimitive(D3DPT_LINELIST,0, (iNumGridX+1 + iNumGridZ+1));
	
	if(m_pVBPick)
	{
		GDEVICE->SetStreamSource( 0, m_pVBPick, 0, sizeof(VtxD));
		GDEVICE->DrawPrimitive(D3DPT_LINESTRIP,0, 4);
	}
}
