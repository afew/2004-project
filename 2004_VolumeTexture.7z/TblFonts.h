///////////////////////////////////////////////////////////////////////////////
// File: TblFonts.h
// Date : 2003-04-11, Author:


#ifndef _TBLFONTS_H_
#define _TBLFONTS_H_

class CTblFont
{
public:
	TCHAR		m_sV[32];														// version
	INT			m_iN;
	LOGFONT	*	m_pLF;
	HFONT	*	m_pHF;


	LPD3DXFONT* m_pDXF;

public:
	
public:
	void Invalidate();
	INT Restore();
	CTblFont();
	~CTblFont();
	
	INT  Init();
	void Destroy();
	
	
	
private:
	INT	 Load(TCHAR * pcFileName);
	void Confirm();
	
};

#endif