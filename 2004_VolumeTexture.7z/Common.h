
#ifndef _COMMON_H_
#define _COMMON_H_

#pragma once

#define STRICT

#pragma warning( disable : 4018)
#pragma warning( disable : 4100)
#pragma warning( disable : 4245)
#pragma warning( disable : 4503)
#pragma warning( disable : 4663)
#pragma warning( disable : 4786)
 

///////////////////////////////////////////////////////////////////////////////
// Library                                                                   //
// Hangul ime
#pragma comment(lib, "imm32")
// For net work...
#pragma comment (lib, "ws2_32")
#pragma comment (lib, "mswsock")
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//	stl...			                                                         //
#include <map>
#include <vector>
#include <algorithm>
#include <functional>
#include <string>

using namespace std;
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
//	 For net work...                                                         //
#include <winsock2.h>

//	For Render...
#include <windows.h>
#include <windowsx.h>
#include <commctrl.h>

#include <process.h>

#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>

#include <time.h>
#include <mmsystem.h>
#include <stdio.h>
#include <tchar.h>
#include <D3D9.h>

#define DIRECTINPUT_VERSION 0x0800
#include <dinput.h>
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// Rendering & sound, etc.                                                   //
#include "DSUtil.h"
#include "DXUtil.h"
#include "D3DUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFont.h"

#include "resource.h"

// Nef base type.. Some types are redifine...
#include "_NefBaseType.h"
#include "SeVtx.h"
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// global pointer...                                                         //
#define GMAIN		g_pApp
#define GHWND		g_pApp->m_hWnd
#define GHDC		g_pApp->m_hDC
#define GDEVICE		g_pApp->m_pd3dDevice
#define SPRITE		g_pApp->m_pd3dSprite

#define GINPUT		g_pApp->m_pInput
#define GSCENE		g_pApp->m_pScene
#define GCAMERA		g_pApp->m_pScene->m_pCamera
#define GNETWORK	g_pApp->m_pNetwork

//data table access
#define TBLMODEL	g_pApp->m_pTblMdl
#define TBLTEX		g_pApp->m_pTblTx
#define TBLMAP		g_pApp->m_pTblMap
#define TBLLOCAL	g_pApp->m_pTblLcl
#define TBLFNT		g_pApp->m_pTblFnt

#define GET_KEY(key)		if(GINPUT->GetKey(key))
#define KEY_STATE(key)		if(GINPUT->KeyState(key))
#define BUTTON_DOWN(button)	if(GINPUT->ButtonDown(button))
#define BUTTON_CLICK(button) if(GINPUT->ButtonClick(button))
#define MOUSE_WHEEL			GINPUT->MouseState.lZ

//                                                                           //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// Application                                                               //

#include "NefUtil.h"		// user define utility

#include "CommonData.h"		// common data...

// base...
#include "Input.h"			// User input.. for keyboard and mouse
#include "Network.h"		// Network

// Model
#include "GameObject.h"		// game object
#include "GameModel.h"		// game model

// table. They are game data...
#include "TblLocal.h"		// local
#include "TblModel.h"		// model
#include "TblTexture.h"		// texture
#include "TblHeightMap.h"	// Height map table
#include "TblFonts.h"		// font Table


//for render...
#include "Camera.h"			// camera
#include "HeightMap.h"		// height map
#include "Light.h"			// lighting
#include "LocalMap.h"		// Local map..for show up
#include "Local.h"			// blocks

// for game play
#include "Player.h"			// player...
#include "Scene.h"			// scene


// main...
#include "GameMain.h"		// main application
//                                                                           //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// extern                                                                    //
extern CMain	*	g_pApp;
extern	SBaseGameInfo	g_BaseInfo;

//                                                                           //
///////////////////////////////////////////////////////////////////////////////

#endif