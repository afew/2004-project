// Interface for the Vertex format structure.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCVTXFORMAT_H_
#define _MCVTXFORMAT_H_


#define FVF_VTXD			(D3DFVF_XYZ|D3DFVF_DIFFUSE)
#define FVF_VTXDUV			(D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1		|D3DFVF_TEXCOORDSIZE2(0))

typedef struct tagVtxD
{
	VEC3	p;
	DWORD	d;
	
	tagVtxD()								{	p.x=p.y=p.z = 0.f;		d = 0xFFFFFFFF;			}
	tagVtxD(VEC3 P, DWORD D)				{	p = P;					d= D;					}
	tagVtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D){	p.x = X;	p.y = Y;	p.z = Z;	d = D;		}
}VtxD;


typedef struct tagVtxDUV
{
	VEC3	p;
	DWORD	d;
	FLOAT	u, v;
	
	tagVtxDUV()								{	p.x=p.y=p.z=u=v=0.0f;	d=0xFFFFFFFF;	}
	tagVtxDUV(VEC3 P)						{	p=P;		u=v=0.0f;	d=0xFFFFFFFF;	}
	tagVtxDUV(VEC3 P, DWORD D)				{	p=P;					d= D;			}
	tagVtxDUV(VEC3 P, FLOAT U, FLOAT V)		{	p=P;		u=U;v=V;	d=0xFFFFFFFF;	}
	tagVtxDUV(VEC3 P,FLOAT U,FLOAT V,DWORD D){	p=P;		u=U;v=V;	d=D;			}
	tagVtxDUV(FLOAT X, FLOAT Y, FLOAT Z
			, FLOAT U, FLOAT V
			, DWORD D=0xFFFFFFFF)			{	p.x=X; p.y=Y;p.z=Z;u=U;v=V;	d=D;		}
	
}VtxDUV;



typedef struct tagVtxIdx
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	tagVtxIdx()								{	a = 0;		 b = 1;		 c = 2;			}
	tagVtxIdx(WORD A, WORD B, WORD C)		{	a = A;		 b = B;		 c = C;			}
	tagVtxIdx(WORD* R)						{	a = R[0];	 b = R[1];	 c = R[2];		}

	operator WORD* ()						{		return (WORD*) &a;					}
	operator CONST WORD* () const			{		return (CONST WORD*) &a;			}
}VtxIdx;

#endif _MCVTXFORMAT_H_