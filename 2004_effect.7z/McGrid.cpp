// Implementation of the CMcGrid class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


typedef struct tagUV2
{
	FLOAT	u0,v0;

	tagUV2(){}
	tagUV2(FLOAT U0,FLOAT V0)		{	u0=U0;v0=V0;}
}UV2;



CMcGrid::CMcGrid()
{
	m_pVB0	= NULL;
	m_pVB1	= NULL;
	
	m_pTB0	= NULL;
	m_pIB	= NULL;
	

	m_pTx	= NULL;

	m_pDcl	= NULL;
}

CMcGrid::~CMcGrid()
{
	Destroy();	
}



INT CMcGrid::Init()
{
	HRESULT hr;
	
	D3DVERTEXELEMENT9 decl[] =
	{
		{ 0, 0,  D3DDECLTYPE_FLOAT3,	D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_POSITION,	0 },
		{ 1, 0, D3DDECLTYPE_D3DCOLOR,	D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_COLOR,		0 },
		
		{ 2, 0, D3DDECLTYPE_FLOAT2,		D3DDECLMETHOD_DEFAULT, D3DDECLUSAGE_TEXCOORD,	0 },
		
		D3DDECL_END()
	};
	
	
	if( FAILED( hr = GDEVICE->CreateVertexDeclaration( decl, &m_pDcl ) ) )
	{
		SAFE_RELEASE(m_pDcl);
		return hr;
	}
	
	INT i, j;
	m_iNX = 33;
	m_iNZ = 33;
	
	m_iWX = 32;
	m_iWZ = 32;
	
	INT end = m_iNX * m_iNZ;
	
	VEC3*	pVtx0 = (VEC3*)	 calloc(end, sizeof(VEC3));
	DWORD*	pVtx1 = (DWORD*) calloc(end, sizeof(DWORD));
	UV2*	pVtx2 = (UV2*)	 calloc(end, sizeof(UV2));
	
	for(j=0; j<m_iNZ; ++j)
	{
		for(i=0; i<m_iNX; ++i)
		{
			FLOAT fH = -100.f;
			pVtx0[j * m_iNX +i ] = VEC3(FLOAT(i * m_iWX), fH, FLOAT(j * m_iWZ)) - VEC3( (m_iNX-1) * m_iWX/2, 0, (m_iNZ-1) * m_iWZ/2);
			pVtx1[j * m_iNX +i ] = 0xFFFFFFFF;
			
			VEC2 uv = VEC2(FLOAT(i*8)/(m_iNX-1), 1.f-FLOAT(j*8)/(m_iNZ-1) );
			
			pVtx2[j * m_iNX +i ].u0 = uv[0];
			pVtx2[j * m_iNX +i ].v0 = uv[1];
		}
	}
	
	McUtil_VBCreate(m_pVB0, end * sizeof(VEC3),		D3DFVF_XYZ,		pVtx0);
	McUtil_VBCreate(m_pVB1, end * sizeof(DWORD),	D3DFVF_DIFFUSE,	pVtx1);
	
	McUtil_VBCreate(m_pTB0, end * sizeof(UV2),		D3DFVF_TEX1,	pVtx2);
	
	
	SAFE_FREE(pVtx0);
	SAFE_FREE(pVtx1);
	SAFE_FREE(pVtx2);
	
	INT m, n;
	INT iNX = m_iNX-1;
	INT iNZ = m_iNZ-1;
	
	VtxIdx *pIb = (VtxIdx*)calloc( 8 * iNX/2 * iNZ/2, sizeof(VtxIdx));
	
	i=0;
	
	for(m=0; m< iNZ/2;++m)
	{
		for(n=0;n<iNX/2;++n)
		{
			WORD s;
			WORD d;
			WORD a;
			
			WORD f[9];
			
			s = iNX + 2;
			
			d=  (iNZ+ 1)*2;
			
			a = m * d + n * 2 + s;
			
			f[1] = a +iNX+0;	f[2] = a + iNX+1;	f[3] = a +iNX+2;
			f[8] = a - 1;		f[0] = a;			f[4] = a + 1;
			f[7] = a -iNZ-2;	f[6] = a - iNZ-1;	f[5] = a -iNZ-0;
			
			pIb[i+0] = VtxIdx( f[0], f[1], f[2]);
			pIb[i+1] = VtxIdx( f[0], f[2], f[3]);
			pIb[i+2] = VtxIdx( f[0], f[3], f[4]);
			pIb[i+3] = VtxIdx( f[0], f[4], f[5]);
			pIb[i+4] = VtxIdx( f[0], f[5], f[6]);
			pIb[i+5] = VtxIdx( f[0], f[6], f[7]);
			pIb[i+6] = VtxIdx( f[0], f[7], f[8]);
			pIb[i+7] = VtxIdx( f[0], f[8], f[1]);
			
			i +=8;
		}
	}
	
	McUtil_IBCreate(m_pIB, sizeof(VtxIdx) * 8 * iNX/2 * iNZ/2, pIb);
	
	SAFE_FREE(pIb);
	
	
	McUtil_TextureLoad("Texture/002_�ܵ�2.dds", m_pTx, 0x00000000);
	
	D3DXMatrixIdentity(&m_mtW);

	return 1;
}

void CMcGrid::Destroy()
{
	SAFE_RELEASE(	m_pVB0	);
	SAFE_RELEASE(	m_pVB1	);
	SAFE_RELEASE(	m_pTB0	);
	SAFE_RELEASE(	m_pIB	);
	
	SAFE_RELEASE(	m_pTx	);
	
	SAFE_RELEASE(	m_pDcl	);
}

INT CMcGrid::FrameMove()
{
	return 1;
}

void CMcGrid::Render()
{
//	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
//	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
//	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);

	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	
	GDEVICE->SetTexture(0, m_pTx);
	
	GDEVICE->SetStreamSource(0, m_pVB0, 0, sizeof(VEC3));
	GDEVICE->SetStreamSource(1, m_pVB1, 0, sizeof(DWORD));
	GDEVICE->SetStreamSource(2, m_pTB0, 0, sizeof(UV2));
	GDEVICE->SetVertexShader(NULL);
	GDEVICE->SetVertexDeclaration( m_pDcl );
	GDEVICE->SetIndices(m_pIB);

	for(INT j =-1; j<2; ++j)
	{
		for(INT i =-1; i<2; ++i)
		{
			m_mtW._41 = i * m_iWX * m_iWX;
			m_mtW._43 = j * m_iWZ * m_iWZ;

			GDEVICE->SetTransform(D3DTS_WORLD, &m_mtW);

			GDEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0, 0, m_iNX * m_iNZ, 0, (m_iNX-1) * (m_iNZ-1)* 2);
		}
	}

	GDEVICE->SetVertexShader(NULL);
	GDEVICE->SetVertexDeclaration( NULL	);

	D3DXMatrixIdentity(&m_mtW);
	GDEVICE->SetTransform(D3DTS_WORLD, &m_mtW);

}