//////////////////////////////////////////////////////////////////////
// GameObject.cpp: implementation of the GameObject class.
//

#include "Common.h"


// Construction/Destruction
CGameObject::CGameObject()
{
	m_vecP = VEC(10,20,30);
	m_vecV = VEC(40,50,60);
}

CGameObject::~CGameObject()
{
	
}


INT CGameObject::Init()
{
	return 1;
}

VOID CGameObject::Destroy()
{
}


INT CGameObject::Restore()
{
	return 1;
}

VOID CGameObject::Invalidate()
{
}



INT CGameObject::FrameMove()
{
	return 1;
}


VOID CGameObject::Render()
{
}



CGameObject	* CGameObject::FindRoot()
{
	return NULL;
}


