//////////////////////////////////////////////////////////////////////
// Scene.cpp: implementation of the CScene class.
//

#include "Common.h"

// Construction/Destruction

CScene::CScene()
{
	m_pLight	= NULL;			// Lighting
	m_pCamera	= NULL;			// Camera
	
	m_pHiMap	= NULL;			// Height Map render
	m_pLocal	= NULL;			// local
	m_pPlayer	= NULL;			// player
}


CScene::~CScene()
{
	m_vObj.clear();
	
	Invalidate();
	Destroy();
	
	SAFE_DELETE_ARRAY(m_pPlayer);
	
	SAFE_DELETE(	m_pLight	);
	SAFE_DELETE(	m_pCamera	);
	SAFE_DELETE(	m_pHiMap	);
	SAFE_DELETE(	m_pLocal	);	
}


INT CScene::Init()
{	
	SAFE_NEWINIT(	m_pLight	);
	SAFE_NEWINIT(	m_pCamera	);
	SAFE_NEWINIT(	m_pHiMap	);
	SAFE_NEWINIT(	m_pLocal	);
	
	m_iNumPc = GNETWORK->m_iNumPc;
	
	m_iNumPc = 1;

	SAFE_NEWINIT_ARRAY(m_pPlayer, m_iNumPc);
	
	m_pPlayer[0].m_PcInfo.vecCur = m_pCamera->m_vecMaster;
	GNETWORK->m_vPc[0]->vecCur = m_pPlayer[0].m_PcInfo.vecCur;
	
	strcpy(m_pPlayer[0].m_PcInfo.UsrID, g_BaseInfo.UsrID);

	// 32 GRID������...
	m_fRenderDist = FLOAT( (TBLMAP->m_iWidthGridX *32) * (TBLMAP->m_iWidthGridZ*32) );

	return 1;
}


VOID CScene::Destroy()

{	
	SAFE_DESTROY(	m_pLight	);
	SAFE_DESTROY(	m_pCamera	);
	SAFE_DESTROY(	m_pHiMap	);
	SAFE_DESTROY(	m_pLocal	);
	
	SAFE_DESTROY_ARRAY(m_pPlayer, m_iNumPc);
	
	m_vObj.clear();
}


INT CScene::Restore()
{
	if(FAILED(OnRestore()))
		return -1;
	
	SAFE_RESTORE(	m_pLight	);
	SAFE_RESTORE(	m_pCamera	);
	SAFE_RESTORE(	m_pHiMap	);
	SAFE_RESTORE(	m_pLocal	);
	
	SAFE_RESTORE_ARRAY(m_pPlayer, m_iNumPc);
	
	return 1;
}



INT CScene::OnRestore()
{
	DWORD dwTex = GMAIN->m_d3dSettings.pWindowed_DeviceInfo->Caps.MaxSimultaneousTextures;
	
	if(dwTex<1)
	{
		MessageBox(GHWND, "This graphic card cannot support multi texture...", "Err", NULL);
		return -1;
	}
	
	for(DWORD i=0;i<dwTex; ++i)
	{
		GDEVICE->SetSamplerState( i, D3DSAMP_MINFILTER, D3DTEXF_LINEAR );
		GDEVICE->SetSamplerState( i, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR );
		GDEVICE->SetSamplerState( i, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR );
	}

	
	return 1;
}


VOID CScene::Invalidate()
{
	SAFE_INVALIDATE(	m_pLight	);
	SAFE_INVALIDATE(	m_pCamera	);
	SAFE_INVALIDATE(	m_pHiMap	);
	SAFE_INVALIDATE(	m_pLocal	);
	
	SAFE_INVALIDATE_ARRAY(m_pPlayer,m_iNumPc);
}



INT CScene::FrameMove()
{
	INT i;
	
	SAFE_FRAMEMOVE(	m_pLight	);
	SAFE_FRAMEMOVE(	m_pHiMap	);
	SAFE_FRAMEMOVE(	m_pLocal	);

	BUTTON_CLICK(0)
	{
		m_vecPickPos = m_pHiMap->GetPickPos();

		m_pPlayer[0].m_PcInfo.eState = C_WALK;
		m_pPlayer[0].m_pAni->m_iCurrentAnim =1;
		m_pPlayer[0].m_PcInfo.vecTar = m_vecPickPos;
	}
	
	m_pCamera->m_vecMaster = m_pPlayer[0].m_PcInfo.vecCur;
	
	SAFE_FRAMEMOVE(	m_pCamera	);

	for(i=0; i<m_iNumPc; ++i)
	{
		if(	! GNETWORK->m_vPc[i]->UsrID[0])
		{
			m_pPlayer[i].m_pObj->m_bRender = false;
			m_pPlayer[i].m_pObj->m_vecP.x = -100.f;
			m_pPlayer[i].m_pObj->m_vecP.z = -100.f;
		}

		else
		{
//				m_pPlayer[i].m_pObj->m_bRender	= true;
			m_pPlayer[i].m_pObj->m_vecP		= GNETWORK->m_vPc[i]->vecCur;
		}
	}


	SAFE_FRAMEMOVE_ARRAY(m_pPlayer, m_iNumPc);


	m_vObj.clear();
	CGameModel * pObj = NULL;

	for(i=0; i<m_iNumPc; ++i)
	{
		if(m_pPlayer[i].m_pAni->m_bRender)
		{

		pObj = (m_pPlayer[i].m_pObj);
		m_vObj.push_back(pObj);
		}
	}
	
	sort(m_vObj.begin(), m_vObj.end(), CSortingGreater());
	
	return 1;
}


VOID CScene::Render()
{
	SAFE_RENDER(m_pLocal);
	
	for(int i=0; i<m_vObj.size(); ++i)
	{
		m_vObj[i]->Render();
	}
}

