// Interface for the CMcGrid class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCGRID_H_
#define _MCGRID_H_

class CMcGrid
{
public:
	INT		m_iNX;																// Number of tile for X
	INT		m_iNZ;																// Number of tile for Z;

	INT		m_iWX;																// Width of tile for x;
	INT		m_iWZ;																// Width of tile for z;

public:
	PDVB	m_pVB0;
	PDVB	m_pVB1;

	PDVB	m_pTB0;

	PDIB	m_pIB;
	PDTX	m_pTx;

	PDVD	m_pDcl;

	MAT		m_mtW;
	
public:
	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();
	
public:
	CMcGrid();
	~CMcGrid();
};

#endif _MCGRID_H_
