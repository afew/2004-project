// Interface for the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _EFTTOOL_H_
#define _EFTTOOL_H_


class CMain : public CD3DApplication
{
public:
	CMcInput*	m_pInput;
	CMcCamera*	m_pCamera;
    ID3DXFont*	m_pDXFt;														// D3DX font
	VtxD*		m_pLine;
	CMcGrid*	m_pGrid;
	TCHAR		m_sMsg[512];
	DWORD		m_dwFl;															// Fill mode
	bool		m_bFld;
	VtxD		m_pVtx1[8+1];
	VtxD		m_pVtx2[8+1];
	VtxIdx		m_pIdx[8];


public:
	PDTX		m_pTxScn; 
	PDSF		m_pSF	;
	PDRS		m_pRS	;
	
	// Scene
	VtxDUV	m_pVx1[4];
	VtxDUV	m_pVx2[4];
	
	// Transforms
	MAT		m_mtPos;
	MAT		m_mtViw;
	MAT		m_mtPrj;
	
	// original and scratch textures
	PDTX	m_pTxOrg;
	PDTX	m_pTxSct;
	
	// width and height of texture image
	INT		m_iTxW, m_iTxH;
	FLOAT	m_fFeedbackRotation;
	FLOAT	m_fFeedbackRotationAccel;
	FLOAT	m_fImageRotation;
	FLOAT	m_fImageRotationAccel;
	FLOAT	m_fFeedbackScale;
	FLOAT	m_fFeedbackScaleAccel;
	
	void ProcessFeedback();



	CMain();
    virtual ~CMain();
    virtual HRESULT OneTimeSceneInit();
    virtual HRESULT InitDeviceObjects();
    virtual HRESULT RestoreDeviceObjects();
    virtual HRESULT InvalidateDeviceObjects();
    virtual HRESULT DeleteDeviceObjects();
    virtual HRESULT Render();
    virtual HRESULT FrameMove();
    virtual HRESULT FinalCleanup();
    virtual HRESULT ConfirmDevice(D3DCAPS9*,DWORD,D3DFORMAT);
	LRESULT			MsgProc(HWND,UINT,WPARAM,LPARAM);

public:
	void		XYZInit();
	void		XYZDestroy();
	void		XYZRender();
};


#endif _EFTTOOL_H_