// Implementation of the CMcXYZ class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


CMcXYZ::CMcXYZ()
:	m_pX	(0)
,	m_pY	(0)
,	m_pZ	(0)
{
}

CMcXYZ::~CMcXYZ()
{
	Destroy();
}



INT CMcXYZ::Init()
{
	D3DXMatrixIdentity(&m_mtW);
	D3DXMatrixIdentity(&m_mtI);

	D3DXMatrixRotationY(&m_mtX, DEG90toRAD);
	D3DXMatrixRotationX(&m_mtY, -DEG90toRAD);
	D3DXMatrixIdentity(&m_mtZ);

	m_pX	= (VtxD*) malloc( 5 * sizeof(VtxD));
	m_pY	= (VtxD*) malloc( 6 * sizeof(VtxD));
	m_pZ	= (VtxD*) malloc( 6 * sizeof(VtxD));

	m_pI	= (VtxIdx*) malloc( 8 * sizeof(VtxIdx));
	

	m_pX[0]	= VtxD( 22.F, 0.0F, 0.0F, 0xFFFF0000);
	m_pX[1]	= VtxD( 0.0F, 0.3F,-0.3F, 0xFFFF0000);
	m_pX[2]	= VtxD( 0.0F, 0.3F, 0.3F, 0xFFFF0000);
	m_pX[3]	= VtxD( 0.0F,-0.3F, 0.3F, 0xFFFF0000);
	m_pX[4]	= VtxD( 0.0F,-0.3F,-0.3F, 0xFFFF0000);

	m_pY[0]	= VtxD( 0.0F, 22.F, 0.0F, 0xFF00FF00);
	m_pY[1]	= VtxD( 0.3F, 0.0F,-0.3F, 0xFF00FF00);
	m_pY[2]	= VtxD(-0.3F, 0.0F,-0.3F, 0xFF00FF00);
	m_pY[3]	= VtxD(-0.3F, 0.0F, 0.3F, 0xFF00FF00);
	m_pY[4]	= VtxD( 0.3F, 0.0F, 0.3F, 0xFF00FF00);


	m_pZ[0]	= VtxD( 0.0F, 0.0F, 22.F, 0xFF0000FF);
	m_pZ[1]	= VtxD( 0.3F, 0.3F, 0.0F, 0xFF0000FF);
	m_pZ[2]	= VtxD(-0.3F, 0.3F, 0.0F, 0xFF0000FF);
	m_pZ[3]	= VtxD(-0.3F,-0.3F, 0.0F, 0xFF0000FF);
	m_pZ[4]	= VtxD( 0.3F,-0.3F, 0.0F, 0xFF0000FF);

	m_pI[0]= VtxIdx( 0, 1, 2);
	m_pI[1]= VtxIdx( 0, 2, 3);
	m_pI[2]= VtxIdx( 0, 3, 4);
	m_pI[3]= VtxIdx( 0, 4, 1);
	m_pI[4]= VtxIdx( 2, 1, 3);
	m_pI[5]= VtxIdx( 4, 3, 1);

	return 1;
}

void CMcXYZ::Destroy()
{
	SAFE_FREE(	m_pX	);
	SAFE_FREE(	m_pY	);
	SAFE_FREE(	m_pZ	);
	SAFE_FREE(	m_pI	);
}

INT CMcXYZ::FrameMove()
{
	return 1;
}

void CMcXYZ::Render()
{
	D3DMATERIAL9	mtrl;
	D3DLIGHT9		light;

	D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, -1.0f, -1.0f, 2.0f );
	light.Specular.r = 1.0f;
	light.Specular.g = 1.0f;
	light.Specular.b = 1.0f;
	light.Specular.a = 1.0f;

	light.Range = 1000;
	light.Falloff = 0;
	light.Attenuation0 = 1;
	light.Attenuation1 = 0;
	light.Attenuation2 = 0;

	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	GDEVICE->SetLight( 0, &light );
	GDEVICE->LightEnable( 0, TRUE );
	GDEVICE->SetRenderState( D3DRS_AMBIENT, 0x00FFFFFF);

	GDEVICE->SetTexture(0,0);
	GDEVICE->SetFVF(FVF_VTXD);
	GDEVICE->SetTransform(D3DTS_WORLD, &m_mtW);

	D3DUtil_InitMaterial( mtrl, 1.f, 1.f, 1.f );
	mtrl.Power = 25.0f;
	mtrl.Specular.a = 1.f;
	mtrl.Specular.r = 1.f;
	mtrl.Specular.g = 1.f;
	mtrl.Specular.b = 1.f;

	GDEVICE->SetMaterial( &mtrl );
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 5, 6, m_pI, D3DFMT_INDEX16, m_pX, sizeof(VtxD));
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 5, 6, m_pI, D3DFMT_INDEX16, m_pY, sizeof(VtxD));
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, 5, 6, m_pI, D3DFMT_INDEX16, m_pZ, sizeof(VtxD));


	GDEVICE->SetTransform(D3DTS_WORLD, &m_mtI);
}