//////////////////////////////////////////////////////////////////////
// Local.cpp: implementation of the CTblLocal class.
//
#include "Common.h"

// Construction/Destruction

CTblLocal::CTblLocal()
{
	m_pBlc	= NULL;
	m_nLcl	= -1;
	m_nM	= -1;
	m_iN	= -1;	
}

CTblLocal::~CTblLocal()
{
	Destroy();
}

INT CTblLocal::Init()
{
	//	g_pApp->HelloWorld();
	
	Save();
	if(FAILED(Load(g_BaseInfo.FileLocalData)))
		return -1;
	
//	Confirm();
	
	return 1;
}


VOID CTblLocal::Destroy()
{
	SAFE_DELETE_ARRAY(m_pBlc);
}



INT CTblLocal::Load(TCHAR *pcFileName)
{
	TCHAR * sTblBlockCmd[] =
	{
		"Nef_Local_Data_Version",	//  0
			"TblLocalData",			//  1
			"IdxLocal",				//  2
			"IdxMstBlockModel",		//  3
			"NumBlock",				//  4
			
			"TblBlockData",			//  5
			"IdxBlock",				//  6
			"IdxSubModel",			//  7
			"PosRot",				//  8
			"IdxLinkBlock",			//  9
			"NumTileXZ",			// 10
			"SizeTileXZ",			// 11
			"HeightScale",			// 12
			
			"TblObjects",			// 13
			"NumUnit",				// 14
			"Rec*",					// 15
	};
	
	
	FILE * fp = NULL;
	
	if(NULL == (fp = fopen(pcFileName, "rt")))
		return -1;
	
	TCHAR sLine[256]= "\0";
	INT nIdxBlock = -1;
	
#define	READ_TEXT_LINE(index)	\
	if(!strncmp(sLine, sTblBlockCmd[index], strlen(sTblBlockCmd[index])))
	
	
	
	while(!feof(fp))
	{
		SeUtil_ReadFileLine(fp, sLine, 256);
		
		READ_TEXT_LINE(0)
			sscanf(sLine, "%*s %s", m_sV);
		
		READ_TEXT_LINE(1)
		{
			while(!feof(fp))
			{
				SeUtil_ReadFileLine(fp, sLine, 256);
				
				if('}' == sLine[0])
					break;
				
				READ_TEXT_LINE(2)
					sscanf(sLine, "%*s %d", &m_nLcl);
				
				READ_TEXT_LINE(3)
					sscanf(sLine, "%*s %d", &m_nM);
				
				READ_TEXT_LINE(4)
				{
					sscanf(sLine,"%*s %d", &m_iN);
					
					if(m_iN<1)
					{
						fclose(fp);
						return -1;
					}
					
					m_pBlc = new SBlock[m_iN];
				}
				
				// block data�� ���� �б�
				READ_TEXT_LINE(5)
				{
					++nIdxBlock;
					
					while(!feof(fp))
					{
						SeUtil_ReadFileLine(fp, sLine, 256);
						
						if('}' == sLine[0])
							break;
						
						READ_TEXT_LINE(6)
							sscanf(sLine, "%*s %d", &(m_pBlc[nIdxBlock].m_nIdx)	);
						
						READ_TEXT_LINE(7)
							sscanf(sLine, "%*s %d", &(m_pBlc[nIdxBlock].m_iModelID)	);
						
						READ_TEXT_LINE(8)
						{
							MAT	matR;
							
							sscanf(sLine,"%*s %f %f %f %f",
								&(m_pBlc[nIdxBlock].m_vecPos.x),
								&(m_pBlc[nIdxBlock].m_vecPos.y),
								&(m_pBlc[nIdxBlock].m_vecPos.z),
								&(m_pBlc[nIdxBlock].m_fYaw) );
							
							D3DXMatrixRotationY(&matR, D3DXToRadian(m_pBlc[nIdxBlock].m_fYaw) );
							
							m_pBlc[nIdxBlock].m_matWorld = matR;
							m_pBlc[nIdxBlock].m_matWorld._41 = m_pBlc[nIdxBlock].m_vecPos.x;
							m_pBlc[nIdxBlock].m_matWorld._42 = m_pBlc[nIdxBlock].m_vecPos.y;
							m_pBlc[nIdxBlock].m_matWorld._43 = m_pBlc[nIdxBlock].m_vecPos.z;
						}
						
						
						READ_TEXT_LINE(9)
						{
							sscanf(sLine,"%*s %d %d %d %d %d %d %d %d"
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[0])
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[1])
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[2])
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[3])
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[4])
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[5])
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[6])
								, &(m_pBlc[nIdxBlock].m_nIdxBlc[7])
								);
						}
						
						READ_TEXT_LINE(10)
						{
							INT iNumTileX, iNumTileZ;
							
							sscanf(sLine,"%*s %d %d", &(iNumTileX), &(iNumTileZ)  );

							m_pBlc[nIdxBlock].m_iNumTileX = iNumTileX;
							m_pBlc[nIdxBlock].m_iNumTileZ = iNumTileZ;
							m_pBlc[nIdxBlock].m_iNumTile = iNumTileX * iNumTileZ;
						}
						
						READ_TEXT_LINE(11)
							sscanf(sLine,"%*s %d %d",
							&(m_pBlc[nIdxBlock].m_iWidthTileX),
							&(m_pBlc[nIdxBlock].m_iWidthTileZ) );
						
						READ_TEXT_LINE(12)
							sscanf(sLine,"%*s %f", &(m_pBlc[nIdxBlock].m_fHScale) );
						
						
						READ_TEXT_LINE(13)
						{
							int iNumObj =0;
							int nIdxObj=0;
							
							while(!feof(fp))
							{
								SeUtil_ReadFileLine(fp, sLine, 256);
								
								if('}' == sLine[0])
									break;
								
								READ_TEXT_LINE(14)
								{
									sscanf(sLine,"%*s %d", &iNumObj );
										m_pBlc[nIdxBlock].m_iNumObj = iNumObj;
									
									if(iNumObj>0)
									{
										m_pBlc[nIdxBlock].m_pSObj = new SObjStatic[iNumObj];
									}
									
									else
										m_pBlc[nIdxBlock].m_pSObj = NULL;
								}
								
								
								READ_TEXT_LINE(15)
								{
									MAT matR;
									
									PSObjStatic pObj = &(m_pBlc[nIdxBlock].m_pSObj[nIdxObj]);
									
									sscanf(sLine,"%*s %d %d %f %f %f %f %f %f",
										&(pObj->m_nIdxMst),
										&(pObj->m_nIdxSub),
										&(pObj->m_fScale),
										&(pObj->m_vecPos.x),
										&(pObj->m_vecPos.y),
										&(pObj->m_vecPos.z),
										&(pObj->m_fTheta),
										&(pObj->m_fPhi)
										);
									
									pObj->m_fScale *= 0.01f;		// %�� �������� ��ģ��.
									
									D3DXMatrixIdentity(	&(pObj->m_matWorld) );
									D3DXMatrixScaling(	&(pObj->m_matWorld),
										pObj->m_fScale,
										pObj->m_fScale,
										pObj->m_fScale);
									
									D3DXMatrixRotationY(&matR, D3DXToRadian(pObj->m_fPhi));
									
									pObj->m_matWorld *= matR;
									pObj->m_matWorld._41 = pObj->m_vecPos.x;
									pObj->m_matWorld._42 = pObj->m_vecPos.y;
									pObj->m_matWorld._43 = pObj->m_vecPos.z;
									
									++nIdxObj;
									
								} // if
							}// while

						}// if
					}// while

				}// if
			}// while
		}// if
	}// while
#undef	READ_TEXT_LINE

	fclose(fp);

	return 1;
}


VOID CTblLocal::Confirm()
{
	INT i, j;
	FILE * fp=NULL;
	
	fp = fopen("Log/TblLocalDataConfirm.dat", "wt");
	
	TCHAR	sLine[256]="\0";
	
	sprintf(sLine, "Nef_Local_Data_Version  %s", m_sV);	fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "\nTblLocalData");							fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	IdxLocal	%d", m_nLcl);			fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	IdxMstBlockModel	%d", m_nM);	fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	NumBlock	%d", m_iN);			fprintf(fp,"%s\n\n", sLine);
	
	for(i=0; i< m_iN; ++i)
	{
		sprintf(sLine,"	TblBlockData");							fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"\n		IdxBlock	%d"
			,m_pBlc[i].m_nIdx);								fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		IdxSubModel	%d"
			,m_pBlc[i].m_iModelID);							fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		PosRot %6.f %6.f %6.f %6.f"
			, m_pBlc[i].m_matWorld._41
			, m_pBlc[i].m_matWorld._42
			, m_pBlc[i].m_matWorld._43
			, m_pBlc[i].m_matWorld._44);						fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		IdxLinkBlock	%d	%d	%d	%d	%d	%d	%d	%d"
			, m_pBlc[i].m_nIdxBlc[0]
			, m_pBlc[i].m_nIdxBlc[1]
			, m_pBlc[i].m_nIdxBlc[2]
			, m_pBlc[i].m_nIdxBlc[3]
			, m_pBlc[i].m_nIdxBlc[4]
			, m_pBlc[i].m_nIdxBlc[5]
			, m_pBlc[i].m_nIdxBlc[6]
			, m_pBlc[i].m_nIdxBlc[7]
			);
		fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		NumTileXZ %d	%d",
			m_pBlc[i].m_iNumTileX, m_pBlc[i].m_iNumTileZ);	fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		SizeTileXZ	%d	%d"
			, m_pBlc[i].m_iWidthTileX
			, m_pBlc[i].m_iWidthTileZ);						fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		HeightScale	%6.f"
			, m_pBlc[i].m_fHScale);							fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"\n		TblObjects");					fprintf(fp,"%s\n", sLine);
		
		INT iNum = m_pBlc[i].m_iNumObj;
		sprintf(sLine,"			NumUnit	%d", iNum);				fprintf(fp,"%s\n", sLine);
		
		for(j=0; j< iNum; ++j)
		{
			sprintf(sLine,"			Rec*	%d	%d %6.f %6.f %6.f %6.f %6.f %6.f"
				, m_pBlc[i].m_pSObj[j].m_nIdxMst
				, m_pBlc[i].m_pSObj[j].m_nIdxSub
				, m_pBlc[i].m_pSObj[j].m_fScale*100.f
				, m_pBlc[i].m_pSObj[j].m_vecPos.x
				, m_pBlc[i].m_pSObj[j].m_vecPos.y
				, m_pBlc[i].m_pSObj[j].m_vecPos.z
				, m_pBlc[i].m_pSObj[j].m_fTheta
				, m_pBlc[i].m_pSObj[j].m_fPhi
				);
			
																fprintf(fp,"%s\n", sLine);
			
		}
		
		fprintf(fp,"\n", sLine);		
	}
	
	fclose(fp);
}




VOID CTblLocal::Save()
{
	INT i, j;
	FILE * fp=NULL;
	TCHAR	sLine[256]="\0";
	TCHAR	tmpbuf[128]="\0";
	PSBlock	pBlock	= NULL;
	
	INT iNumX = 20;
	INT iNumZ = 20;
	
	strcpy(m_sV,"0.0.1");
	m_nLcl = 0;
	m_nM	= 6;
	m_iN = iNumX * iNumZ;
	
	fp = fopen(g_BaseInfo.FileLocalData, "wt");
	
	if(NULL == fp)
		return;
	
	pBlock = new SBlock[m_iN];
	
	_strdate(tmpbuf);
	
	
	fprintf(fp, "//////////////////////////////////////////////////////////////////////\n");
	fprintf(fp, "// TblLocal data : It has block data\n");
	fprintf(fp, "// \n");
	fprintf(fp, "// Create: 2003-03-21 created by Heesung Oh in SROnLine\n");
	fprintf(fp, "// UpDate: %s\n", tmpbuf);
	fprintf(fp, "// \n");
	fprintf(fp, "// Block format is equal to Block (See Block data)\n");
	fprintf(fp, "// LocalIndex : is local map index\n");
	fprintf(fp, "// BlockNum	: Number of block\n");
	fprintf(fp, "//		NumUnit	91\n");
	fprintf(fp, "//		Mastertype	SubType	Scale	x pos	y pos	z pos	Theta	Phi\n");
	fprintf(fp, "//		0			1		100		170			145		0		115\n");
	fprintf(fp, "// \n");
	fprintf(fp, "// version\n");
	
	
	sprintf(sLine, "Nef_Local_Data_Version  %s", m_sV);	fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "\nTblLocalData");							fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	{");									fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	IdxLocal	%d", m_nLcl);			fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	IdxMstBlockModel	%d", m_nM);	fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	NumBlock	%d", m_iN);			fprintf(fp,"%s\n\n", sLine);
	
	
	for(i=0; i< m_iN; ++i)
	{
		pBlock[i].m_nIdx = i;
		pBlock[i].m_iModelID = i%15;
		
		pBlock[i].m_matWorld._41	= FLOAT( i%iNumX * 1024);
		pBlock[i].m_matWorld._42	= 0.f;
		pBlock[i].m_matWorld._43	= FLOAT( i/iNumX * 1024);
		pBlock[i].m_matWorld._44	= 0.f;
		
		
		pBlock[i].m_nIdxBlc[0] = i - iNumX - 1;
		pBlock[i].m_nIdxBlc[1] = i - iNumX + 0;
		pBlock[i].m_nIdxBlc[2] = i - iNumX + 1;
		pBlock[i].m_nIdxBlc[3] = i + 1;
		pBlock[i].m_nIdxBlc[4] = i + iNumX + 1;
		pBlock[i].m_nIdxBlc[5] = i + iNumX + 0;
		pBlock[i].m_nIdxBlc[6] = i + iNumX - 1;;
		pBlock[i].m_nIdxBlc[7] = i - 1;
		
		
		if( !(i%iNumX) )
		{
			pBlock[i].m_nIdxBlc[0] = -1;
			pBlock[i].m_nIdxBlc[6] = -1;
			pBlock[i].m_nIdxBlc[7] = -1;
		}
		
		if( !((i+1)%iNumX) )
		{
			pBlock[i].m_nIdxBlc[2] = -1;
			pBlock[i].m_nIdxBlc[3] = -1;
			pBlock[i].m_nIdxBlc[4] = -1;
		}
		
		
		if( i >=(m_iN-iNumX-1) )
		{
			pBlock[i].m_nIdxBlc[4] = -1;
			pBlock[i].m_nIdxBlc[5] = -1;
			pBlock[i].m_nIdxBlc[6] = -1;
		}
		
		if( i <=(iNumX-1) )
		{
			pBlock[i].m_nIdxBlc[0] = -1;
			pBlock[i].m_nIdxBlc[1] = -1;
			pBlock[i].m_nIdxBlc[2] = -1;
		}
		
		
		
		pBlock[i].m_iNumTileX		= 32;
		pBlock[i].m_iNumTileZ		= 32;
		
		pBlock[i].m_iWidthTileX	= 32;
		pBlock[i].m_iWidthTileZ	= 32;
		pBlock[i].m_fHScale		= 1.f;
		
		pBlock[i].m_iNumObj		= 1 + i%12;
		
		pBlock[i].m_pSObj			= new SObjStatic[pBlock[i].m_iNumObj];
		
		
		
		sprintf(sLine,"	TblBlockData");							fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"		{");								fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		IdxBlock	%d"
			,pBlock[i].m_nIdx);									fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		IdxSubModel	%d"
			,pBlock[i].m_iModelID);								fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		PosRot %5.f %5.f %5.f %5.f"
			, pBlock[i].m_matWorld._41
			, pBlock[i].m_matWorld._42
			, pBlock[i].m_matWorld._43
			, pBlock[i].m_matWorld._44);						fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		IdxLinkBlock	%d	%d	%d	%d	%d	%d	%d	%d"
			, pBlock[i].m_nIdxBlc[0]
			, pBlock[i].m_nIdxBlc[1]
			, pBlock[i].m_nIdxBlc[2]
			, pBlock[i].m_nIdxBlc[3]
			, pBlock[i].m_nIdxBlc[4]
			, pBlock[i].m_nIdxBlc[5]
			, pBlock[i].m_nIdxBlc[6]
			, pBlock[i].m_nIdxBlc[7]
			);													fprintf(fp,"%s\n", sLine);
		
		
		sprintf(sLine,"		NumTileXZ	%d	%d",
			pBlock[i].m_iNumTileX, pBlock[i].m_iNumTileZ);		fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		SizeTileXZ	%d	%d"
			, pBlock[i].m_iWidthTileX
			, pBlock[i].m_iWidthTileZ);							fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		HeightScale	%5.f"
			, pBlock[i].m_fHScale);								fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"\n		TblObjects");					fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"			{");							fprintf(fp,"%s\n", sLine);
		
		INT iNum = pBlock[i].m_iNumObj;
		sprintf(sLine,"			NumUnit	%d", iNum);				fprintf(fp,"%s\n", sLine);
		
		for(j=0; j< iNum; ++j)
		{
			sprintf(sLine,"			Rec*	%d	%d %5.f %5.f %5.f %5.f %5.f %5.f"
				, pBlock[i].m_pSObj[j].m_nIdxMst
				, pBlock[i].m_pSObj[j].m_nIdxSub
				, pBlock[i].m_pSObj[j].m_fScale*100.f
				, pBlock[i].m_pSObj[j].m_vecPos.x
				, pBlock[i].m_pSObj[j].m_vecPos.y
				, pBlock[i].m_pSObj[j].m_vecPos.z
				, pBlock[i].m_pSObj[j].m_fTheta
				, pBlock[i].m_pSObj[j].m_fPhi
				);												fprintf(fp,"%s\n", sLine);
		}
		
		sprintf(sLine,"			}");							fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"		}");								fprintf(fp,"%s\n\n", sLine);
	}

	SAFE_DELETE_ARRAY(pBlock);

	sprintf(sLine, "	}");									fprintf(fp,"%s\n\n", sLine);
	fclose(fp);
}