///////////////////////////////////////////////////////////////////////////////
// File:Scene.h
// Desc: interface for the CScene class.
// Date: 2003-04-12, Author: SR OnLine
// History: 


#ifndef _SCENE_H_
#define _SCENE_H_

typedef vector<PCGameObject>	ObjList;
typedef ObjList::iterator		ObjItor;


//////////////////////////////////////////////////////////////////////
// Scene manager...
//


class CScene  
{
public:
	CCamera*	m_pCamera;			// Camera
	CLight*		m_pLight;			// Lighting
	CHeight*	m_pHiMap;			// Height Map render
	CLocal*		m_pLocal;			// Field
	CPlayer*	m_pPlayer;			// player
	INT			m_iNumPc;
	ObjList		m_vObj;				// Rendering object list

public:
	FLOAT		m_fRenderDist;		// Rendering distance
	VEC			m_vecPickPos;		// Pick position

	
	
public:
	CScene();
	virtual ~CScene();
	
	INT		Init();
	VOID	Destroy();
	
	INT		Restore();
	VOID	Invalidate();
	
	INT		FrameMove();
	VOID	Render();
protected:
	INT OnRestore();
};

#endif
