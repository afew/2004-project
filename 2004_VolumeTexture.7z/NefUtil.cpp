#include "Common.h"



///////////////////////////////////////////////////////////////////////////////
// Simple Node

CSimpleNode::CSimpleNode()
{
	pNext	= NULL;
}


CSimpleNode * CDebugStringBase::pStart = NULL;

CDebugStringBase::CDebugStringBase()
{
	m_iX	= 50;
	m_iY	= 500;
	m_iData = 0;
	memset(m_szString, 0, sizeof(m_szString));

	pNext	= NULL; 
}


void CDebugStringBase::AddTail(CSimpleNode * pQueue)
{
	if(!pQueue)
		return;
	
	pNext = pQueue;
}


void CDebugStringBase::OnPrintString(int iY)
{
	if('\0'!= m_szString[0])
	{
		TextOut(GHDC, m_iX, iY, m_szString, strlen(m_szString));
	}
}


void CDebugStringBase::PrintString(int iY)
{
	OnPrintString(iY);
	
	if (pStart == this)
		return ;
		
	((CDebugStringBase*)pNext)->PrintString(iY+20);
}


void CDebugStringBase::PrintStringAll(int iY)
{
	OnPrintString(iY);
 	((CDebugStringBase*)pNext)->PrintString(iY+20);
}




CDebugString::CDebugString()
{
	ppQue = NULL;
}


CDebugString::~CDebugString()
{
	Destroy();
}


void CDebugString::Destroy()
{
	if(ppQue)
	{
		unsigned int i=0;

		for(i=0;i<m_iNum; ++i)
		{
			SAFE_DELETE(ppQue[i]);
		}
		
		SAFE_DELETE_ARRAY(ppQue);
	}
	
	ppQue = NULL;
}

int CDebugString::Init()
{
	Destroy();
	
	unsigned int i=0;
	m_iNum = GMAIN->m_dwScnW/40;
	m_iIdx = 0;
	
	ppQue = new CDebugStringBase*[m_iNum];
	
	for(i=0;i<m_iNum; ++i)
		ppQue[i] = new CDebugStringBase;
	
	for(i=0;i<m_iNum-1; ++i)
		ppQue[i]->AddTail(ppQue[i+1]);
	
	ppQue[m_iNum-1]->AddTail(ppQue[0]);

	ppQue[0]->pStart = ppQue[0];
	
	return 1;
}



void CDebugString::PrintString(int iY)
{
	((CDebugStringBase*)ppQue[(m_iIdx+1)%m_iNum])->PrintStringAll(iY);
}




void CDebugString::SetString(char * szString)
{
	++m_iIdx;
	
	ppQue[m_iIdx%m_iNum]->pStart = ppQue[m_iIdx%m_iNum];
	strcpy(ppQue[m_iIdx%m_iNum]->m_szString, szString);
}







void SeUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);
}


char *getSmallTime(void)
{
	static char tm_str[128 + 1];
	SYSTEMTIME st;

	GetLocalTime(&st);
	strcpy(tm_str,
		SeUtil_Forming("'%04d-%02d-%02d\t'%02d:%02d:%02d.%03d",
		//SeUtil_Forming("%04dy\t%02dm %02dd\t%02dh %02dm\t%02d.%03ds",
		(int)st.wYear, (int)st.wMonth, (int)st.wDay,
		(int)st.wHour, (int)st.wMinute, (int)st.wSecond, (int)st.wMilliseconds));

	return(tm_str);
} /* getSmallTime */


void SeUtil_FormatLog(TCHAR *format,...)
{
	return;

	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log.txt", "a+");
	
	fprintf(fp, "%s\t%s\n", getSmallTime(), szDbgBuf);

	fclose(fp);
	// ���� ���   
}


void SeUtil_FormatLog2(TCHAR *format,...)
{
//	if (!g_BaseInfo.File_Log) return;
	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log_2.txt", "a+");
	
	fprintf(fp, "%s\t%s\n", getSmallTime(), szDbgBuf);

	fclose(fp);
	// ���� ���   
}


// Texture Load
int SeUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color, D3DXIMAGE_INFO *pSrcInfo, D3DFORMAT d3dFormat)
{
//	HRESULT D3DXCreateTextureFromFileEx(
//	LPDIRECT3DDEVICE9 pDevice,
//    LPCTSTR pSrcFile,
//    UINT Width,
//    UINT Height,
//    UINT MipLevels,
//    DWORD Usage,
//    D3DFORMAT Format,
//    D3DPOOL Pool,
//    DWORD Filter,
//    DWORD MipFilter,
//    D3DCOLOR ColorKey,
//    D3DXIMAGE_INFO *pSrcInfo,
//    PALETTEENTRY *pPalette,
//    LPDIRECT3DTEXTURE9 *ppTexture
//);
	
	if ( FAILED(D3DXCreateTextureFromFileEx(
		GDEVICE
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat	//, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)) )
	{
		texture = NULL;
		return -1;
	}
	
	return 1;
}



void SeUtil_ReadFileLine(FILE *fp, TCHAR *str, int nStr)
{
	fgets(str, nStr, fp);
	UINT i, j;
	TCHAR * sTmp1 = NULL;
	TCHAR * sTmp2 = NULL;
	
	int nSize = strlen(str);
	
	for(i=0; i<strlen(str); ++i)
	{
		if(str[i] == '\t')	str[i] =' ';
//		if(str[i] == '"')	str[i] =' ';
		
		if(str[i] == '\n' || str[i] == '\r')
		{
			for(j=i; j<strlen(str); ++j)
				str[j] ='\0';
		}
	}
	
	int nStart=0, nEnd= strlen(str);
	
	for(i=0; i<strlen(str); ++i){	if(str[i] != ' ')	{	nStart =i;	break;	}	}
	for(i=0; i<strlen(str); ++i){	if(str[i] == '\0')	{	nEnd =i;	break;	}	}
	
	sTmp1 = new TCHAR[nEnd-nStart+1];
	memset(sTmp1,0, sizeof(TCHAR)* (nEnd-nStart+1));
	
	sTmp2 = new TCHAR[nEnd-nStart+1];
	memset(sTmp2,0, sizeof(TCHAR)* (nEnd-nStart+1));
	
	strncpy(sTmp1, str + nStart, nEnd-nStart);
	
	j=0;
	for(int k=0; k<nEnd-nStart+1; ++k)
	{
		if( !(' ' ==sTmp1[k] &&' ' ==sTmp1[k+1]))
		{
			if( ' ' ==sTmp1[k] && '\0'==sTmp1[k+1])
				sTmp2[j]= '\0';
			
			else
				sTmp2[j]= sTmp1[k];
			
			++j;
		}
	}
	
	memset(str,0, sizeof(TCHAR)*nSize);
	strcpy(str, sTmp2);
	
	delete [] sTmp1;	sTmp1 = NULL;
	delete [] sTmp2;	sTmp2 = NULL;
}


void SeUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn)
{
	TCHAR*	p;
	INT iS;
	INT iE;
	INT iD;
	INT iC = '\"';

	// Search forward
	p = strchr(strIn, iC);
	iS = p - strIn + 1;

	// Search backward
	p = strrchr( strIn, iC);
	iE = p - strIn + 1;

	iD = iE - iS -1;

	strncpy(strOut, strIn+iS, iD);
}


void	SeUtil_VBCreate(PDVB& pVB, int nSize, DWORD FVF, void* pVtx, D3DPOOL pool)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateVertexBuffer(nSize
		,	0
		,	FVF
		,	pool
		,	&pVB
		,	NULL );
	
	if( FAILED(hr) )
	{
		SeUtil_ErrMsgBox("Vertex create failed");
		return ;
	}
	
	if(!pVtx)
		return;
	
	void* p;
	
	if( FAILED( pVB->Lock( 0, 0, &p, 0)))
		return;
	
	memcpy( p, pVtx, nSize);
	pVB->Unlock();
}


void	SeUtil_IBCreate(PDIB& pIB, int nSize, void* pIdx, D3DFORMAT FMT, D3DPOOL pool)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateIndexBuffer(nSize
		,	0
		,	FMT
		,	pool
		,	&pIB
		,	NULL);
	
	if( FAILED(hr) )
	{
		SeUtil_ErrMsgBox("Vertex create failed");
		return ;
	}
	
	if(!pIdx)
		return;
	
	void* p;
	
	if( FAILED( pIB->Lock( 0, 0, &p, 0)))
		return;
	
	memcpy( p, pIdx, nSize);
	pIB->Unlock();
}


void	SeUtil_VBCopy(PDVB& pVB, int nSize, void* pVtx)
{
	void* p;
	
	if( FAILED( pVB->Lock( 0, 0, &p, 0)))
		return;
	
	memcpy(p, pVtx, nSize);
	pVB->Unlock();
}


void	SeUtil_IBCopy(PDIB& pIB, int nSize, void* pIdx)
{
	void* p;
	
	if( FAILED( pIB->Lock( 0, 0, &p, 0)))
		return;
	
	memcpy(p, pIdx, nSize);
	pIB->Unlock();
}


bool SeUtil_LineCross2D(VEC2 * p)
{
	VEC2 L1 = p[1] - p[0];
	VEC2 L2 = p[3] - p[2];
	VEC2 L3 = p[2] - p[0];
	
	
	FLOAT fAlpha = L2.x * L1.y - L2.y * L1.x;
	
	if(0.f == fAlpha)
		return false;
	
	FLOAT fBeta = fAlpha;
	
	fAlpha = (L2.x * L3.y - L2.y * L3.x)/fAlpha;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	fBeta = (L2.x * L3.y - L1.y * L3.x)/fBeta;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	return true;
}

int SeUtil_Position2D(VEC & Out, const VEC & In)
{
	MAT matView;
	MAT matProj;
	MAT matViewProj;
	MAT matViewInv;
	
	FLOAT fNear=1;
	
//	GDEVICE->GetTransform(D3DTS_VIEW, &matView);
//	GDEVICE->GetTransform(D3DTS_PROJECTION, &matProj);

	matView = GCAMERA->m_matView;
	matProj  = GCAMERA->m_matProj;
	
	
	D3DXMatrixIdentity(&matViewProj);
	D3DXMatrixMultiply(&matViewProj, &matView, &matProj);
	D3DXMatrixInverse(&matViewInv, NULL, &matView);
	
	matViewProj = matView * matProj;
	
	//camera position
	VEC vecCamPos(matViewInv._41, matViewInv._42, matViewInv._43);
	
	//Normalvector
	VEC vecZ( matView._13, matView._23, matView._33);
	
	FLOAT beta = vecZ.x * (In.x - vecCamPos.x) + vecZ.y * (In.y - vecCamPos.y) + vecZ.z * (In.z - vecCamPos.z);
	
	if(beta<=fNear)
		return 0;			// �������� ��� �ڿ� ����.


	beta = fNear/beta;
	
	
	VEC vecBefore = beta * (In - vecCamPos) -fNear * vecZ;
	
	// ���� Model view Matrix�� �����Ѵ�.
	Out.x = vecBefore.x * matViewProj._11 + vecBefore.y * matViewProj._21 + vecBefore.z * matViewProj._31;
	Out.y = vecBefore.x * matViewProj._12 + vecBefore.y * matViewProj._22 + vecBefore.z * matViewProj._32;
	Out.z = vecBefore.x * matViewProj._13 + vecBefore.y * matViewProj._23 + vecBefore.z * matViewProj._33;
	
	//	float r = sqrtf(Out.x * Out.x + Out.y * Out.y + Out.z * Out.z);
	
	//�������� ȭ�� scale�� Projection�Ѵ�.
	Out.x =  FLOAT(GMAIN->m_dwScnW) * (Out.x +1.f) * 0.5f;
	Out.y = -FLOAT(GMAIN->m_dwScnH) * (Out.y -1.f) * 0.5f;
	Out.z = Out.z;

	return 1;
	
}





bool SeUtil_PositionMouse3D(VEC & vec3dOut)
{
	MAT matView;
	MAT matProj;
	MAT matViewProj;
	MAT matViewInv;
	
	MAT matViewProjInv;
	
	GDEVICE->GetTransform(D3DTS_VIEW, &matView);
	GDEVICE->GetTransform(D3DTS_PROJECTION,&matProj);
	
	D3DXMatrixIdentity(&matViewProj);
	
	matViewProj = matView * matProj;
	D3DXMatrixInverse(&matViewProjInv, NULL, &matViewProj);
	
	POINT	pt;
	RECT	rt;
	
	::GetCursorPos(&pt);
	::GetWindowRect(GHWND, &rt);
	
	VEC vecBefore( 2.f * pt.x /FLOAT(rt.right-rt.left) -1,
		-2.f * pt.y /FLOAT(rt.bottom - rt.top) +1,
		0);
	
	VEC vecP(0,0,0);
	
	
	// ���� Model view Matrix�� �����Ѵ�.
	
	vecP.x = vecBefore.x * matViewProjInv._11 + vecBefore.y * matViewProjInv._21 + vecBefore.z * matViewProjInv._31;
	vecP.y = vecBefore.x * matViewProjInv._12 + vecBefore.y * matViewProjInv._22 + vecBefore.z * matViewProjInv._32;
	vecP.z = vecBefore.x * matViewProjInv._13 + vecBefore.y * matViewProjInv._23 + vecBefore.z * matViewProjInv._33;
	
	//camera position
	D3DXMatrixInverse(&matViewInv, NULL, &matView);
	VEC vecCamPos(matViewInv._41, matViewInv._42, matViewInv._43);
	
	//Normalvector
	VEC vecZ( matView._13, matView._23, matView._33);
	
	FLOAT beta =(vecZ.y + vecP.y);
	
	if (0.f == beta)
		return false;
	
	beta =  -vecCamPos.y/beta;
	
	vec3dOut = beta * (vecZ + vecP) + vecCamPos;
	
	return true;
}


int SeUtil_DrawHDCText(int X, int Y, LPCTSTR Text, DWORD _color)
{	
	HDC hDC;
	LPDIRECT3DSURFACE9 Surface;
	
	if(FAILED(GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &Surface)))
		return -1;
	
	Surface->GetDC(&hDC);
	
	if(NULL != hDC)
	{
		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, _color);
		TextOut(hDC, X, Y, Text, strlen(Text));

		Surface->ReleaseDC(hDC);
	}
	
	Surface->Release(); //�����Ѵ�.
	
	
	return 1;
}


void SeUtil_SetWindowTitle(const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(GHWND, s);
}



void SeUtil_TextOut(float x, float y, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	TextOut(GHDC, INT(x), INT(y), s, strlen(s));
}


void SeUtil_TextOut(VEC2 p, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	TextOut(GHDC, INT(p.x), INT(p.y), s, strlen(s));
}




void SeUtil_OutputDebug(const char * format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	::OutputDebugString(s);
}


///////////////////////////////////////////////////////////////////////////////
// SeUtil_PluckFirstField()
//  str���ڿ��� delim���� �ձ��� ���� dest�� �ִ´�. (maxlen�� ���� �ʴ� ����) 
//  �Լ� ���� �� str�� Pointer�� delim���� ������ ���δ�.
///////////////////////////////////////////////////////////////////////////////
int SeUtil_PluckFirstField(char *str, char *dest, int maxlen, const char *delim)
{
  char *endpos;
  int p;

  if (!strlen(delim)) { strcpy(dest, str); return 0; }
  endpos = strstr(str, delim);
  if (!endpos) { strcpy(dest, str); return 0; }
  p = endpos - str;

  memset(dest, 0, maxlen);
  memcpy(dest, str, p);

  // pluck it off of str...
  strcpy(str, &str[p+strlen(delim)]);

  return p;
}


char*	SeUtil_Forming(const char *fmt, ...)
{
#define FORMING_1CALL_STR_TOTAL 512
#define FORMING_RECALL_TOTAL 100
#define FORMING_BUF_TOTAL (FORMING_1CALL_STR_TOTAL * FORMING_RECALL_TOTAL)
	static char formingbuf[FORMING_BUF_TOTAL], formingfmt[FORMING_1CALL_STR_TOTAL + 1];
	static int index_formingbuf;
	va_list arglist;
	char *strp;
	
	va_start(arglist, fmt);
	vsprintf(formingfmt, fmt, arglist);
	va_end(arglist);
	if (index_formingbuf + strlen(formingfmt) + 1 >= FORMING_BUF_TOTAL) index_formingbuf = 0;
	strp = formingbuf + index_formingbuf;
	strcpy(strp, formingfmt);
	index_formingbuf += strlen(formingfmt) + 1;
	return(strp);
}