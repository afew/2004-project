// Interface for the CMcCamera class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MCCAMERA_H_
#define _MCCAMERA_H_


class CMcCamera
{
public:
	D3DXMATRIX		m_mtView;															// view matrix
	D3DXMATRIX		m_mtViewI;															// inverse view matrix
	D3DXMATRIX		m_mtProj;															// projection matrix

	D3DXMATRIX		m_mtBill;															// Billboard for All
	D3DXMATRIX		m_mtBillY;															// Billboard for Y

	D3DXVECTOR3	m_vcXAxis;
	D3DXVECTOR3	m_vcYAxis;
	D3DXVECTOR3	m_vcZAxis;

	D3DXVECTOR3	m_vcEyePt;															// Camera position
	D3DXVECTOR3	m_vcLookAt;															// Camera look at vector
	D3DXVECTOR3	m_vcUp;																// Camera up vector

	D3DXVECTOR3	m_vcRayOrg;															// Ray Position
	D3DXVECTOR3	m_vcMaster;															// ���ΰ� ĳ��������ġ

	FLOAT	m_fFov;
	FLOAT	m_fAspect;
	FLOAT	m_fNear;
	FLOAT	m_fFar;

	FLOAT	m_fYaw;
	FLOAT	m_fPitch;
	FLOAT	m_fZoom;
	TCHAR	m_szName[64];
	FLOAT	m_fAngleView;														// View Angle (Radian)

public:
	FLOAT	m_fR;																// ī�޶� �浹 �ݰ�. 
	DWORD	m_dwStart;
	FLOAT	m_fD;

	D3DXVECTOR3	m_vcAxisX;
	D3DXVECTOR3	m_vcAxisY;
	D3DXVECTOR3	m_vcAxisZ;

public:
	CMcCamera();
	~CMcCamera();

	INT		Init();
	INT		Restore();
	INT		FrameMove();

	void	Update();
	INT		FrameMoveInPortal();


public:
	void	SetMasterCamera(const FLOAT	_fY);
	TCHAR *	GetName()							{	return m_szName;		}
	D3DXMATRIX		GetViewMatrix()						{	return m_mtView;		}
	D3DXMATRIX		GetViewMatrixI()					{	return m_mtViewI;		}
	D3DXMATRIX		GetProjMatrix()						{	return m_mtProj;		}

	D3DXMATRIX		GetBillMat()						{	return m_mtBill;		}
	D3DXMATRIX		GetBillMatY()						{	return m_mtBillY;		}

	D3DXVECTOR3	GetAxisX()							{	return m_vcAxisX;		}
	D3DXVECTOR3	GetAxisY()							{	return m_vcAxisY;		}
	D3DXVECTOR3	GetAxisZ()							{	return m_vcAxisZ;		}
	D3DXVECTOR3	GetRayOrg()							{	return m_vcRayOrg;		}
	D3DXVECTOR3	GetRayDir();

	void	RotationXAxis(FLOAT	fAngle);
	void	RotationYAxis(FLOAT	fAngle);
	void	RotationZAxis(FLOAT	fAngle);
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveUpward(FLOAT	fSpeed);
	void	MoveForward(FLOAT	fSpeed);
	void	SetPosition(D3DXVECTOR3	vPos);
	void	SetProjParam();
	void	SetName(TCHAR* szName);
	void	SetDelta(FLOAT len=0);
};

#endif