// Implementation of the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


CMcInput::CMcInput()
{
	m_pDInput	= NULL;
	m_pDiKey	= NULL;
	m_pDiMouse	= NULL;
}


CMcInput::~CMcInput()
{
	Destroy();
}


void CMcInput::Destroy()
{
	if(m_pDiKey)
		m_pDiKey->Unacquire();
	
	if(m_pDiMouse)
		m_pDiMouse->Unacquire();
	
	SAFE_RELEASE(m_pDiKey);
	SAFE_RELEASE(m_pDiMouse);
	SAFE_RELEASE(m_pDInput);
}


INT CMcInput::Init()
{
	memset(Key, 0, sizeof(Key));
	memset(KeyOld, 0, sizeof(KeyOld));
	
	bLButton	= false;
	bLButtonOld	= false;
	bRButton	= false;
	bRButtonOld	= false;
	bLButtonDB	= false;
	
	memset(&MousePos, 0  , sizeof(POINT));
	memset(&MousePosOld,0, sizeof(POINT));
	
	memset(&MouseState, 0, sizeof(DIMOUSESTATE));
	memset(&MouseStateOld, 0, sizeof(DIMOUSESTATE));
	
	zDelta		= 0;
	
	if(FAILED(InitDInput()))
	{
		return -1;
	}
	
	return 1;
}


// Name: UpdateInput()
INT CMcInput::FrameMove()
{
	if(!GMAIN->m_bActive)
		return -1;

	xDelta = MousePos.x - MousePosOld.x;
	yDelta = MousePos.y - MousePosOld.y;

	memcpy(KeyOld,                 Key, sizeof(BYTE)*256);
	memcpy(&MousePosOld,     &MousePos, sizeof(POINT));
	memcpy(&MouseStateOld, &MouseState, sizeof(DIMOUSESTATE));

//	UpdateGeneral();
	UpdateDInput();
	
	return 1;
}


INT CMcInput::UpdateGeneral()
{
	memcpy(KeyOld, Key, sizeof(BYTE)*256);
	::GetKeyboardState(Key);

	::GetCursorPos(&MousePos);
	::ScreenToClient(GHWND, &MousePos );

	return 1;
}

INT CMcInput::UpdateDInput()
{
	if (FAILED(m_pDiKey->GetDeviceState(sizeof(Key), (LPVOID)Key)))
	{
		memset(Key, 0, sizeof(Key));
		
		if (FAILED(m_pDiKey->Acquire()))
			return -1;
		
		if (FAILED(m_pDiKey->GetDeviceState(sizeof(Key), (LPVOID)Key)))
			return -1;
	}
	
	
	
	if (FAILED(m_pDiMouse->GetDeviceState(sizeof(DIMOUSESTATE), &MouseState)))
	{
		if (FAILED(m_pDiMouse->Acquire()))
			return -1;
		
		if (FAILED(m_pDiMouse->GetDeviceState(sizeof(DIMOUSESTATE), &MouseState)))
			return -1;
	}

	GetCursorPos(&MousePos);
	::ScreenToClient(GHWND, &MousePos);
	GDEVICE->SetCursorPosition( MousePos.x, MousePos.y, 0 );

	return 1;
}


INT CMcInput::InitDInput()
{
	if (FAILED(DirectInput8Create(	GMAIN->m_hInst,
		DIRECTINPUT_VERSION,
		IID_IDirectInput8,
		(void **)&m_pDInput,
		NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDiKey, NULL)))
	{
		return -1;
	}
	
	if (FAILED(m_pDiKey->SetDataFormat(&c_dfDIKeyboard)))
		return -1;
	
	if (FAILED(m_pDiKey->SetCooperativeLevel(GHWND, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
		return -1;
	
	
	DWORD flags = DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDiMouse, NULL)))
		return -1;
	
	if (FAILED(m_pDiMouse->SetDataFormat(&c_dfDIMouse)))
		return -1;
	
	if (FAILED(m_pDiMouse->SetCooperativeLevel(GHWND, flags)))
		return -1;
	
	return 1;
}
