
// File: Mackerel.h
//
// Desc: Header file Mackerel sample app




// Struct to store the current input state
struct UserInput
{
	// TODO: change as needed
	BOOL bRotateUp;
	BOOL bRotateDown;
	BOOL bRotateLeft;
	BOOL bRotateRight;
};




//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------
class CMyD3DApplication : public CD3DApplication
{
public:
	BOOL			m_bLoadingApp;          // TRUE, if the app is loading
	ID3DXFont*		m_pD3DXFont;            // D3DX font    
	
	UserInput		m_UserInput;            // Struct for storing user input 

	D3DXMATRIX		matWorld;
	D3DXMATRIX		matRotY;
	D3DXMATRIX		matRotX;
	FLOAT			m_fWorldRotX;           // World rotation state X-axis
	FLOAT			m_fWorldRotY;           // World rotation state Y-axis

	CMcScene*		m_pScene;
	
public:
	virtual HRESULT OneTimeSceneInit();
	virtual HRESULT InitDeviceObjects();
	virtual HRESULT RestoreDeviceObjects();
	virtual HRESULT InvalidateDeviceObjects();
	virtual HRESULT DeleteDeviceObjects();
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	virtual HRESULT FinalCleanup();
	virtual HRESULT ConfirmDevice( D3DCAPS9*, DWORD, D3DFORMAT );
	
	HRESULT RenderText();
	
	void    UpdateInput( UserInput* pUserInput );
	
public:
	LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
	CMyD3DApplication();
	virtual ~CMyD3DApplication();
};

