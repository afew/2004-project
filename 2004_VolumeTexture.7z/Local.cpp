// Local.cpp: implementation of the CLocal class.
//
//////////////////////////////////////////////////////////////////////

#include "Common.h"

// Construction/Destruction

CLocal::CLocal()
{
	m_nIdxBlockCurrent	= -1;
	
	for(INT i=0; i< 9; ++i)
		m_LineBlock[i] = NULL;

	m_pLocalMap	= NULL;
}


CLocal::~CLocal()
{
	SAFE_DELETE(	m_pLocalMap	);
}


INT CLocal::Init()
{
	SAFE_NEWINIT(	m_pLocalMap	);

	return 1;
}


VOID CLocal::Destroy()
{
	INT i;
	
	for(i=0; i< 9; ++i)
		SAFE_DELETE(m_LineBlock[i]);
	
	SAFE_DESTROY(	m_pLocalMap	);
}



INT CLocal::Restore()
{
	m_nIdxBlockCurrent = TBLLOCAL->GetBlockIdx(GCAMERA->m_vecMaster);

	if(m_nIdxBlockCurrent<0)
	{
		MessageBox(NULL, "Get Block index failed", "Err", NULL);

		return -1;
	}
	
//	SetBlockData();

	SAFE_RESTORE(	m_pLocalMap	);

	return 1;
}


VOID CLocal::Invalidate()
{
//	InvalidateBlockLine();
	SAFE_INVALIDATE(	m_pLocalMap	);
}


void CLocal::InvalidateBlockLine()
{
	INT i;
	
	for(i=0; i< 9; ++i)
		SAFE_DELETE(m_LineBlock[i]);
}


INT CLocal::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pLocalMap	);

	INT nIdxBlock = TBLLOCAL->GetBlockIdx(GCAMERA->m_vecMaster);

	if(-1 != nIdxBlock 	&& m_nIdxBlockCurrent !=  nIdxBlock)
	{
		m_nIdxBlockCurrent =  nIdxBlock;
//		SetBlockData();
		m_pLocalMap->SetLocalMap();
	}

	return 1;
}


VOID CLocal::Render()
{
	INT i=0;
	MAT matWorld;
	
	D3DXMatrixIdentity(&matWorld);
	GDEVICE->SetTransform(D3DTS_WORLD, &matWorld);
	
	GDEVICE->SetRenderState(D3DRS_FOGENABLE, FALSE);
	
//	GDEVICE->SetTexture(0, NULL);
//	GDEVICE->SetFVF(FVF_VTXD);
	
//	for(i=0; i<9; ++i)
//	{
//		if(m_LineBlock[i])
//		{
//			GDEVICE->SetStreamSource( 0, m_LineBlock[i]->m_pVBLine, 0, sizeof(VtxD));
//			GDEVICE->DrawPrimitive(D3DPT_LINESTRIP,0, 4);
//		}
//	}

	SAFE_RENDER(m_pLocalMap);
}




INT CLocal::SetBlockData()
{
	INT i;
	INT iNumX;
	INT iNumZ;
	INT	iWidthX;
	INT iWidthZ;
	VEC vecPos;

	CTblLocal::SBlock * BlockAttrib = NULL;
	CTblLocal::SBlock * BlockLink = NULL;

	InvalidateBlockLine();

	BlockAttrib= TBLLOCAL->GetBlock(GCAMERA->m_vecMaster);
	
	if(BlockAttrib)
	{
		m_LineBlock[8] = new SLineBlock;
		
		iNumX	= BlockAttrib->m_iNumTileX;
		iNumZ	= BlockAttrib->m_iNumTileZ;
		iWidthX	= BlockAttrib->m_iWidthTileX;
		iWidthZ	= BlockAttrib->m_iWidthTileZ;
		vecPos	= BlockAttrib->m_vecPos;

		m_LineBlock[8]->m_Line[0].d = 0xff00ffff;
		m_LineBlock[8]->m_Line[1].d = 0xff00ffff;
		m_LineBlock[8]->m_Line[2].d = 0xff00ffff;
		m_LineBlock[8]->m_Line[3].d = 0xff00ffff;
		m_LineBlock[8]->m_Line[4].d = 0xff00ffff;

		m_LineBlock[8]->m_Line[0].p = vecPos;
		m_LineBlock[8]->m_Line[1].p = vecPos + VEC(						0, 0, FLOAT(iNumZ * iWidthZ));
		m_LineBlock[8]->m_Line[2].p = vecPos + VEC(FLOAT(iNumX * iWidthX), 0, FLOAT(iNumZ * iWidthZ));
		m_LineBlock[8]->m_Line[3].p = vecPos + VEC(FLOAT(iNumX * iWidthX), 0,					   0);
		m_LineBlock[8]->m_Line[4].p = vecPos;
		
		SeUtil_VBCreate(m_LineBlock[8]->m_pVBLine, 5 * sizeof(VtxD), FVF_VTXD , m_LineBlock[8]->m_Line);
		
//		sprintf(DEBUG_STRING,"Current Idx: %d  Link: %d %d %d %d %d %d %d %d"
//			, BlockAttrib->m_nIdx
//			, BlockAttrib->m_nIdxBlc[0]
//			, BlockAttrib->m_nIdxBlc[1]
//			, BlockAttrib->m_nIdxBlc[2]
//			, BlockAttrib->m_nIdxBlc[3]
//			, BlockAttrib->m_nIdxBlc[4]
//			, BlockAttrib->m_nIdxBlc[5]
//			, BlockAttrib->m_nIdxBlc[6]
//			, BlockAttrib->m_nIdxBlc[7]
//			);
				
		
		for(i=0; i<8; ++i)
		{
			if(BlockAttrib->m_nIdxBlc[i]>=0)
			{
				BlockLink = TBLLOCAL->GetBlock(BlockAttrib->m_nIdxBlc[i]);
				
				iNumX	= BlockLink->m_iNumTileX;
				iNumZ	= BlockLink->m_iNumTileZ;
				iWidthX	= BlockLink->m_iWidthTileX;
				iWidthZ	= BlockLink->m_iWidthTileZ;
				vecPos	= BlockLink->m_vecPos;

				m_LineBlock[i] = new SLineBlock;

				m_LineBlock[i]->m_Line[0].d = 0xff008888;
				m_LineBlock[i]->m_Line[1].d = 0xff008888;
				m_LineBlock[i]->m_Line[2].d = 0xff008888;
				m_LineBlock[i]->m_Line[3].d = 0xff008888;
				m_LineBlock[i]->m_Line[4].d = 0xff008888;
				
				m_LineBlock[i]->m_Line[0].p = vecPos;
				m_LineBlock[i]->m_Line[1].p = vecPos + VEC(						0, 0, FLOAT(iNumZ * iWidthZ));
				m_LineBlock[i]->m_Line[2].p = vecPos + VEC(FLOAT(iNumX * iWidthX), 0, FLOAT(iNumZ * iWidthZ));
				m_LineBlock[i]->m_Line[3].p = vecPos + VEC(FLOAT(iNumX * iWidthX), 0,					   0);
				m_LineBlock[i]->m_Line[4].p = vecPos;
				
				SeUtil_VBCreate(m_LineBlock[i]->m_pVBLine, 5 * sizeof(VtxD), FVF_VTXD, m_LineBlock[i]->m_Line);
				
			}// if
		}// for
	}// if
	
	else
	{
		SeUtil_FormatLog("There is no block");
	}
	
	return 1;
}


