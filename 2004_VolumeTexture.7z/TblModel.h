// TblModel.h: interface for the CTblModel class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _TBLMODEL_H_
#define _TBLMODEL_H_


class CTblModel  
{
public:
	typedef struct tagSTblMdlSub
	{
		INT			m_nIdxSub;			// Attribute
		TCHAR		m_szMdlFile[256];	// Model Name
		CGameModel*	m_pMdl;				// Game model
		
		tagSTblMdlSub()
			: m_nIdxSub(-1)
			, m_pMdl(NULL)
		{
			memset(&m_szMdlFile, 0, sizeof(m_szMdlFile));
		}

		~tagSTblMdlSub()
		{
			SAFE_DELETE(m_pMdl);
		}

	}STblMdlSub, * PSTblMdlSub;

	typedef struct tagSTblMdlMst
	{
		INT			m_nIdxMst;			// Model master index
		INT			m_iNumMdlSub;		// Number of model
		PSTblMdlSub	m_pTblMdlSub;
		
		tagSTblMdlMst()
			: m_iNumMdlSub(-1)			// ��������
			, m_pTblMdlSub(NULL)		// ������ �־� ������ �߻���Ŵ.
		{
			
		}

		~tagSTblMdlMst()
		{
			SAFE_DELETE_ARRAY(m_pTblMdlSub);
		}
		
	}STblMdlMst, * PSTblMdlMst;

	// Index table
	typedef struct tagSTblMstIdx
	{
		INT			m_nIdxMst;			// Model master index
		TCHAR		m_szMdlName[128];	// Model Name

		tagSTblMstIdx()
			: m_nIdxMst(-1)
		{
			memset(&m_szMdlName, 0, sizeof(m_szMdlName));
		}
	}STblMstIdx, * PSTblMstIdx;


public:
	TCHAR		m_szVersion[32];		// version
	INT			m_iNumModelClass;		// Model class Number
	PSTblMstIdx	m_pTblMdlIdx;			// Model index table
	PSTblMdlMst	m_pTblMdlMst;			// Model table
	
public:
	
	CTblModel();
	virtual ~CTblModel();
	
	INT		Init();
	INT		Load(TCHAR *pcFileName);
	VOID	Destroy();

	INT		ModelIdxSelect(TCHAR * pClassName);
	INT		SubModelNumber(INT nIdxMst);
	INT		ModelCreate (INT nMst, INT nSub=0xffff);
	VOID	ModelSelect (CGameModel ** ppGameModel, INT nMst, INT nSub);

private:
	VOID Confirm();
};

#endif
