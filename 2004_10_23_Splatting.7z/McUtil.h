// Interface for the Utility Functions.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MCUTIL_H_
#define _MCUTIL_H_

#define ONE_RADtoDEG	57.2957795130823208767981548f
#define ONE_DEGtoRAD	0.01745329251994329576923690f
#define PI				3.14159265358979323846264338f
#define DEG90toRAD		1.57079632679489661923132163f
#define RADtoDEG(p) ( (p)*ONE_RADtoDEG)
#define DEGtoRAD(p) ( (p)*ONE_DEGtoRAD)

////////////////////////////////////////////////////////////////////////////////
// 

template<class T> D3DXINLINE
bool McUtil_IsBadReadPtr(T* &t)
{
	return (IsBadReadPtr(t, sizeof(T)));
}


template<class T> D3DXINLINE
bool McUtil_IsNotAllocated(T* &t)
{
	return (!&t || !t || IsBadReadPtr(t, sizeof(T)) );	
}

template<class T> D3DXINLINE
bool McUtil_IsAllocated(T* &t)
{
	return !McUtil_IsNotAllocated(t);
}

template<class T> D3DXINLINE
void SAFE_NEW(T* &p)
{
	//	if(!p)
	if(McUtil_IsNotAllocated(p))
		p = new T;
}

template<class T> D3DXINLINE
void SAFE_NEW_ARRAY(T* &p, INT N)
{
	if(McUtil_IsNotAllocated(p))
		p = new T[N];
}

template<class T> D3DXINLINE
INT  _SAFE_NEWINIT(T* &p)
{
	if(McUtil_IsNotAllocated(p))
	{
		p = new T;
		if( p->Init()<0 )
			return -1;
	}
	
	return 1;
}


#define		SAFE_FREE(p)		{ if(p) { free(p);		(p)=NULL; } }

#define		SAFE_NEWINIT(p)		if(FAILED(_SAFE_NEWINIT(p)))	return -1;


template<class T> D3DXINLINE
void SAFE_NEWINIT_ARRAY(T* &p, INT N)
{
	if(McUtil_IsNotAllocated(p))
	{
		p = new T[N];
		for(INT i = 0; i<N ; ++i)
			p[i].Init();
	}
}

#define		SAFE_DESTROY(p)		if(p)	(p)->Destroy();

template<class T> D3DXINLINE
void SAFE_DESTROY_ARRAY	(T* &p, INT N)
{
	if(McUtil_IsAllocated(p))
		for(INT i=0; i<N ; ++i)
			p[i].Destroy();
}

#define		_SAFE_RESTORE(p)	if(p)	(p)->Restore();
#define		SAFE_RESTORE(p)		if((p) && FAILED( (p)->Restore())) return -1;

template<class T> D3DXINLINE
void SAFE_RESTORE_ARRAY	(T* &p, INT N)
{
	if(McUtil_IsAllocated(p))
		for(INT i=0; i<N ; ++i)
			p[i].Restore();
}


#define		SAFE_INVALIDATE(p)	if(p)	(p)->Invalidate();


template<class T> D3DXINLINE
void SAFE_INVALIDATE_ARRAY	(T* &p,INT N)
{
	if(McUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].Invalidate();
}

#define		SAFE_FRAMEMOVE(p)	if( (p) && FAILED( (p)->FrameMove())) return -1;
#define		SAFE_UPDATE(p)		if( (p) && FAILED( (p)->Update())) return -1;


template<class T> D3DXINLINE
void SAFE_FRAMEMOVE_ARRAY	(T* &p, INT N)
{
	if(McUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].FrameMove();
}


#define		SAFE_RENDER(p)	if(p)	(p)->Render();
#define		SAFE_RNDBCK(p)	if(p)	(p)->RndBck();


template<class T> D3DXINLINE
void SAFE_RENDER_ARRAY	(T* &p, INT N)
{
	if(McUtil_IsAllocated(p))
		for(INT i=0; i<N; ++i)
			p[i].Render();
}


template<class T> D3DXINLINE
void McUtil_Swap (T* &a, T* &b)
{
	T c; c = *a; *a = *b;*b = c;
}

template<class T> D3DXINLINE void SAFE_INIT_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<p.size; ++i)
		if(p[i])
			p[i]->Init();
}



template<class T> D3DXINLINE
void SAFE_DELETE_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_DELETE(p[i]);

	p.clear();
}


template<class T> D3DXINLINE
void SAFE_DESTROY_LIST(T &p)
{
	if(p.empty())
		return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_DESTROY(p[i]);
}


template<class T> D3DXINLINE
INT SAFE_RESTORE_LIST(T &p)
{
	if(p.empty())
		return -1;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		if((p[i]) && FAILED( (p[i])->Restore()))
			return -1;
	
	return 1;
}


template<class T> D3DXINLINE
void SAFE_INVALIDATE_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_INVALIDATE(p[i]);
}




template<class T> D3DXINLINE
INT SAFE_FRAMEMOVE_LIST(T &p)
{
	if(p.empty())
		return 2;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
	{
		if(! p[i])
			return 3;
		
		if( FAILED( (p[i])->FrameMove()))
			return -1;
	}
	
	return 1;
}



template<class T> D3DXINLINE
void SAFE_RENDER_LIST(T &p)
{
	if(p.empty())	return;

	INT iSize = p.size();

	for(INT i=0; i<iSize; ++i)
		SAFE_RENDER(p[i]);
}

#define		SAFE_DESTROY_WINDOW(p)	{	if(p)	DestroyWindow(p);		}

void	McUtil_ErrMsgBox(TCHAR *format,...);
void	McUtil_GetLastError(HWND hWnd);
INT		McUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color=0xffffffff, D3DXIMAGE_INFO *pSrcInfo=NULL, DWORD Filter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), DWORD MipFilter= (D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR), D3DFORMAT d3dFormat = D3DFMT_A8R8G8B8);
void	McUtil_ReadFileLine(FILE *fp, TCHAR *str, INT nStr);
void	McUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC='\"');

void	McUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx=NULL, D3DPOOL usage=D3DPOOL_MANAGED);
void	McUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx);
void	McUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx=NULL, D3DFORMAT fmt=D3DFMT_INDEX16, D3DPOOL usage= D3DPOOL_MANAGED);
void	McUtil_IBLock(PDIB& pIB, INT nSize, void* pIdx);


bool	McUtil_LineCross2D(D3DXVECTOR2 * p);
INT		McUtil_3Dto2D(D3DXVECTOR3 & Out, const D3DXVECTOR3 & In);
bool	McUtil_PositionMouse3D(D3DXVECTOR3 & vec3dOut);
INT		McUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color= RGB(255,255,0));
void	McUtil_SetWindowTitle(const char *format, ...);
void	McUtil_TextOut(float x, float y, const char *format, ...);
void	McUtil_TextOut(D3DXVECTOR2 p, const char *format, ...);
void	McUtil_OutputDebug(const char *Format, ...);
TCHAR*	McUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR *sTitle="Choose Folder");
TCHAR*	McUtil_DWtoStr(DWORD dwA);
char*	McUtil_Forming(const char *fmt, ...);

void	SetDlgItemFlt(HWND hWnd, UINT id, FLOAT z, INT decimal=6);
FLOAT	GetDlgItemFlt(HWND hWnd, UINT id);
void	SetDlgItemHex(HWND hWnd, UINT id, INT val);

#define PFF(s, d, l, d1) McUtil_PluckFirstField((s), (d), (l), (d1))

inline DWORD FtoDW( FLOAT f )	{ return *((DWORD*)&f); }
inline DWORD F2DW( FLOAT f )	{ return *((DWORD*)&f); }





typedef struct tagSWin
{
	PDSW	pC;																	// Swap chain
	PDSF	pB;																	//Back buffer surface
	PDSF	pS;																	//Stencil buffer surface
	HWND	hW;																	// Window Handle

	tagSWin() :	pC(0), pB(0), pS(0), hW(0){}

	void	Release()
	{
		SAFE_RELEASE(pC);
		SAFE_RELEASE(pB);
		SAFE_RELEASE(pS);
	}

}SWin;



typedef struct tagSTItmInf
{
	INT			nM;
	INT			nS;
	HTREEITEM	hT;

	tagSTItmInf():	nM(-1),	nS(-1),	hT(0){}
	tagSTItmInf(INT M, INT S, HTREEITEM T):	nM(M),	nS(S),	hT(T){}

	bool HasParent()
	{
		if(nM<0)
			return false;
		
		return true;
	}

}STItmInf;

typedef vector<STItmInf>	lsHItem;
typedef lsHItem::iterator	itHItem;

#endif