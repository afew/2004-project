// TblFonts.cpp: implementation of the CTblExpLevel class.
//
//////////////////////////////////////////////////////////////////////

#include "Common.h"

///////////////////////////////////////////////////////////////////////////////
// CTblFont definition

// CTblFont constructor
CTblFont::CTblFont()
{
	m_iN	= 0;
	m_pLF	= NULL;
	m_pHF	= NULL;

	m_pDXF	= NULL;
}


//CTblFont destructor
CTblFont::~CTblFont()
{
	Destroy();
}


// CTblFont member or etc init
INT  CTblFont::Init()
{
	if(FAILED(Load(g_BaseInfo.FileFontList)))
	{
		SeUtil_ErrMsgBox("Font list load failed");
		return -1;
	}

	INT i=0;
	m_pHF = new HFONT[m_iN];

	for(i=0; i< m_iN ; ++i)
		m_pHF[i] = CreateFontIndirect(&m_pLF[i]);

	
//	Confirm();
	return 0;
}


INT CTblFont::Restore()
{
	m_pDXF = new LPD3DXFONT[m_iN];

	for(int i=0; i< m_iN ; ++i)
		D3DXCreateFont( GDEVICE, m_pHF[i], &m_pDXF[i] );

	return 1;
}


void CTblFont::Invalidate()
{

	for(int i=0; i<m_iN; ++i)
		SAFE_RELEASE( m_pDXF[i] );

	SAFE_DELETE_ARRAY(m_pDXF);
}



void CTblFont::Destroy()
{
	INT i=0;
	for(i=0; i< m_iN ; ++i)
		DeleteObject(m_pHF[i]);

	SAFE_DELETE_ARRAY(m_pLF);
	SAFE_DELETE_ARRAY(m_pHF);
}



INT CTblFont::Load(TCHAR * pcFileName)
{
	FILE * fp = NULL;
	TCHAR sLine[512]="\0";
	
	TCHAR * sTblFontCmd[] =
	{
		"Nef_FontList_Data_Version",	//0
			"TblFontListMst",			//1
			"NumFontList",				//2
			"TblFontClass",				//3
			"Rec*",						//4
	};
	
	fp = fopen(pcFileName, "rt");
	
	if(NULL == fp)
		return -1;


#define	READ_TEXT_LINE(index)	\
	if(!strncmp(sLine, sTblFontCmd[index], strlen(sTblFontCmd[index])))
	
	while(!feof(fp))
	{
		SeUtil_ReadFileLine(fp, sLine, 512);
		
		READ_TEXT_LINE(0)
			sscanf(sLine, "%*s %s", m_sV);
		

		INT nIdx=0;

		READ_TEXT_LINE(1)
		{
			while(!feof(fp))
			{
				SeUtil_ReadFileLine(fp, sLine, 512);
				
				if('}' == sLine[0])
					break;
				
		
				READ_TEXT_LINE(2)
				{
					sscanf(sLine, "%*s %d", &m_iN);
					
					if(m_iN)
					{
						m_pLF = new LOGFONT[m_iN];
					}

					else
					{
						SeUtil_ErrMsgBox("Create font list failed");
						break;
					}
				}
				

				READ_TEXT_LINE(3)
				{
					nIdx=0;
					
					while(!feof(fp))
					{
						SeUtil_ReadFileLine(fp, sLine, 512);
						
						if('}' == sLine[0])
							break;


						READ_TEXT_LINE(4)
						{
							sscanf(sLine, "%*s %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %ld %s"
										, &(m_pLF[nIdx].lfHeight)
										, &(m_pLF[nIdx].lfWidth)
										, &(m_pLF[nIdx].lfEscapement)
										, &(m_pLF[nIdx].lfOrientation)
										, &(m_pLF[nIdx].lfWeight)
										, &(m_pLF[nIdx].lfItalic)
										, &(m_pLF[nIdx].lfUnderline)
										, &(m_pLF[nIdx].lfStrikeOut)
										, &(m_pLF[nIdx].lfCharSet)
										, &(m_pLF[nIdx].lfOutPrecision)
										, &(m_pLF[nIdx].lfClipPrecision)
										, &(m_pLF[nIdx].lfQuality)
										, &(m_pLF[nIdx].lfPitchAndFamily)
										,   m_pLF[nIdx].lfFaceName);

							
							++nIdx;
						}
					}//while
				}//if

			}// while
		}// if
		
#undef	READ_TEXT_LINE
	}// while
	
	fclose(fp);
	
	return 1;
}




void CTblFont::Confirm()
{
	INT i;
	FILE * fp;
	
	fp = fopen("Log/TblFontListConfirm.dat", "wt");
	
	fprintf(fp,"Nef_FontList_Data_Version		%s\n", m_sV);
	fprintf(fp,"\nTblFontListMst\n");
	fprintf(fp,"\n	NumHFontList %d\n", m_iN);
	
	for(i=0; i< m_iN; ++i)
	{
		fprintf(fp, "		Rec*	%ld	%ld	%ld	%ld	%ld	%ld	%ld	%ld	%ld	%ld	%ld	%ld	%ld	%s \n"
					, m_pLF[i].lfHeight
					, m_pLF[i].lfWidth
					, m_pLF[i].lfEscapement
					, m_pLF[i].lfOrientation
					, m_pLF[i].lfWeight
					, m_pLF[i].lfItalic
					, m_pLF[i].lfUnderline
					, m_pLF[i].lfStrikeOut
					, m_pLF[i].lfCharSet
					, m_pLF[i].lfOutPrecision
					, m_pLF[i].lfClipPrecision
					, m_pLF[i].lfQuality
					, m_pLF[i].lfPitchAndFamily
					, m_pLF[i].lfFaceName);
	}
	
	
	fclose(fp);
}