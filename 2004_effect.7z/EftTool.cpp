// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


CMain::CMain()
:	m_pInput	(0)
,	m_pCamera	(0)

,	m_pLine		(0)
,	m_pDXFt		(0)
,	m_pGrid		(0)
,	m_dwFl		(3)
,	m_bFld		(1)
{
	m_pPtc		= NULL;
}


CMain::~CMain()
{
}


HRESULT CMain::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	m_bLoadingApp = FALSE;
	
	return S_OK;
}


HRESULT CMain::InitDeviceObjects()
{
	int		i;

	XYZInit();
	SAFE_NEWINIT(	m_pInput	);
	SAFE_NEWINIT(	m_pCamera	);
	SAFE_NEWINIT(	m_pGrid		);
	
	m_pVtx1[8] = VtxD( 0.f, 50.f,  0.f, 0x00000000);
	m_pVtx2[8] = VtxD( 0.f, 50.f,  0.f, 0x00000000);

	for(i=0; i<8; ++i)
	{
		m_pVtx1[i].p = VEC3( 30.f * cosf(DEGtoRAD(360.f * i / 8)), 60.f * 1.f + 50.f, 30.f * sinf(DEGtoRAD(360.f * i / 8) ) );
		m_pVtx1[i].d = D3DXCOLOR( rand()%6 * 0.1f, rand()%6 * 0.1f, rand()%6 * 0.1f, 1.f);

		m_pVtx2[i].p = VEC3( 50.f * cosf(DEGtoRAD(360.f * i / 8)), 40.f * 1.f + 50.f, 50.f * sinf(DEGtoRAD(360.f * i / 8) ) );
		m_pVtx2[i].d = D3DXCOLOR( rand()%6 * 0.1f, rand()%6 * 0.1f, rand()%6 * 0.1f, 1.f);
	}
	
	
	for(i=0; i<8; ++i)
	{
		m_pIdx[i] = VtxIdx(8, (i+1)%8, (i+2)%8 );
	}




	SAFE_NEWINIT(	m_pPtc		);


	
	return S_OK;
}


HRESULT CMain::RestoreDeviceObjects()
{
	HRESULT hr=-1;
	
	HFONT hFont = CreateFont(  16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,	ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" );
	
	if( FAILED( hr = D3DXCreateFont( GDEVICE, hFont, &m_pDXFt ) ) )
		return DXTRACE_ERR( "D3DXCreateFont", hr );
	
	DeleteObject(hFont);
	
	SAFE_RESTORE(	m_pCamera	);
	
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	sprintf( m_sMsg, "%s %s   R�� ������..", m_strDeviceStats, m_strFrameStats	);
	
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCamera	);


	GET_KEY(DIK_R)
	{
//		m_pPtc->Reset(VEC(-500,100,-500), VEC(500,100,500), 5);
		m_pPtc->Reset();
	}


	SAFE_FRAMEMOVE(	m_pPtc		);
	
	return S_OK;
}




HRESULT CMain::Render()
{
	GDEVICE->Clear( 0L, NULL, m_dwClr, 0x00006688, 1.0f, 0L );	

	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;

	GDEVICE->SetRenderState(D3DRS_FILLMODE, m_dwFl);
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetRenderState( D3DRS_ZWRITEENABLE, TRUE );
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	
	XYZRender();
	SAFE_RENDER(	m_pGrid	);






	SAFE_RENDER(	m_pPtc	);










	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	
	SeRect rt(2, 10, m_d3dsdBackBuffer.Width - 20, 30);
	
	m_pDXFt->Begin();
	m_pDXFt->DrawText( m_sMsg, -1, &rt.GetRECT(), 0, D3DCOLOR_ARGB(255,255,255,0));
	m_pDXFt->End();
	
	GDEVICE->EndScene();
	
	return S_OK;
}


HRESULT CMain::InvalidateDeviceObjects()
{
	SAFE_RELEASE( m_pDXFt );
	
	return S_OK;
}



HRESULT CMain::DeleteDeviceObjects()
{
	INT i=0;
	
	XYZDestroy();
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamera	);
	SAFE_DELETE(	m_pGrid		);


	SAFE_DELETE(	m_pPtc		);
	
	return S_OK;
}



void CMain::XYZInit()
{
	INT		i;
	INT		j;
	FLOAT	fMax;
	
	fMax = 10000;
	m_pLine = (VtxD*)malloc( (6 + 8*4 ) * 2 * sizeof(VtxD));
	
	m_pLine[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pLine[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pLine[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pLine[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pLine[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pLine[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);
	
	j =6 * 2;
	
	for(i=0; i<8; ++i)
	{
		m_pLine[j + 8*i +0 ] = VtxD(-128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +1 ] = VtxD( 128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +2 ] = VtxD(-128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +3 ] = VtxD( 128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		
		m_pLine[j + 8*i +4 ] = VtxD( 16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +5 ] = VtxD( 16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +6 ] = VtxD(-16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +7 ] = VtxD(-16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
	}
	
}


void CMain::XYZDestroy()
{
	SAFE_FREE(		m_pLine		);
}

void CMain::XYZRender()
{
	// Render Lines
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
//	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
//	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetFVF(FVF_VTXD);
	
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6 + 32, m_pLine, sizeof(VtxD));
}