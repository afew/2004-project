#include "Common.h"
INT	ReadBaseInfo();


///////////////////////////////////////////////////////////////////////////////////////

// �޴� ����
int			g_iGameStatus;
int			g_iExitProgram;

SBaseGameInfo	g_BaseInfo;
CMain * g_pApp  = NULL;



INT WINAPI WinMain( HINSTANCE hInst, HINSTANCE, LPSTR lpCmdLine, INT)
{
	if(FAILED(ReadBaseInfo()))
	{
		MessageBox(NULL, "Cannot read game base information file", "Err", NULL);
		return -1;
	}
	
	InitCommonControls();
	SAFE_NEW(g_pApp);
	
	if( FAILED( g_pApp->Create( hInst ) ) )
	{
		SAFE_DELETE(g_pApp);
		return -1;
	}
	
	if(g_BaseInfo.UsingBaseUser)
	{
		strcpy(GNETWORK->m_szUsrId,  g_BaseInfo.UsrID);
		strcpy(GNETWORK->m_szUsrPwd, g_BaseInfo.UsrPwd);
	}
	else
	{
		sscanf(lpCmdLine,"%s %s", GNETWORK->m_szUsrId, GNETWORK->m_szUsrPwd);
		
		if(!strlen(GNETWORK->m_szUsrId) || !strlen(GNETWORK->m_szUsrPwd))
		{
			g_pApp->Invalidate();
			g_pApp->Destroy();
			g_pApp->FinalCleanup();
			
			SAFE_DELETE(g_pApp);
			
			return -1;
		}
	}
	
	
	if(g_BaseInfo.UsingBaseServer)
	{
		strcpy(GNETWORK->m_szServerIP,  g_BaseInfo.ServerIP);
		strcpy(GNETWORK->m_szPort,		g_BaseInfo.ServerPort);
	}
	else
	{
		strcpy(GNETWORK->m_szServerIP,  "127.0.0.1");
		strcpy(GNETWORK->m_szPort,		"10001");
	}
	
	
	INT nReturn = g_pApp->Run();

	SAFE_DELETE(g_pApp);
	
	return nReturn;
}

// Name: WndProc()
LRESULT CALLBACK WndProc( HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam )
{
	return g_pApp->MsgProc( hWnd, uMsg, wParam, lParam );
}


// Name: MsgProc()
LRESULT CMain::MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam )
{
	switch( msg )
	{
	case WM_PAINT:
		{
			if( m_bLoadingApp )
			{
				Sleep(100);
			}
			break;
		}
	}
	
	
	return CD3Window::MsgProc( hWnd, msg, wParam, lParam );
}






INT	ReadBaseInfo()
{
	FILE * fp = NULL;
	TCHAR sLine[512]="\0";
	
	TCHAR * sBaseInfoCmd[] =
	{
		"Nef_BaseInfo_Version",		// 0
			"TblBaseInfo",			// 1
			"UsingBaseUser",		// 2
			"UsrID",				// 3
			"UsrPwd",				// 4
			"UsingBaseServer",		// 5
			
			"ServerIP",				// 6
			"ServerPort",			// 7
			"DisplayFPS",			// 8
			"DisplayCameraInfo",	// 9
			"DisplayBox",			//10
			
			"StartFullMode",		//11
			"FileClimate",			//12
			"FileExpLevel",			//13
			"FileFontList",			//14
			"FileHeightMap",		//15
			
			"FileLighting",			//16
			"FileLocalData",		//17
			"FileModel",			//18
			"FileSound",			//19
			"FileTexture",			//20
			
			"FileMenuData",			//21
			"FileUIData",			//22
			"FileUISetupData",		//23
	};
	
	fp = fopen("data/_BaseInfo.dat", "rt");
	
	if(NULL == fp)
		return -1;
	
	
#define	READ_TEXT_LINE(index)	\
	if(!strncmp(sLine, sBaseInfoCmd[index], strlen(sBaseInfoCmd[index])))
	
	while(!feof(fp))
	{
		SeUtil_ReadFileLine(fp, sLine, 512);
		
		READ_TEXT_LINE(0)
			sscanf(sLine, "%*s %s", g_BaseInfo.Version);
		
		
		INT nIdx=0;
		
		READ_TEXT_LINE(1)
		{
			while(!feof(fp))
			{
				SeUtil_ReadFileLine(fp, sLine, 512);
				
				if('}' == sLine[0])
					break;
				
				READ_TEXT_LINE( 2)	sscanf(sLine, "%*s %d", &g_BaseInfo.UsingBaseUser);
				READ_TEXT_LINE( 3)	sscanf(sLine, "%*s %s", &g_BaseInfo.UsrID);
				READ_TEXT_LINE( 4)	sscanf(sLine, "%*s %s", &g_BaseInfo.UsrPwd);
				
				READ_TEXT_LINE( 5)	sscanf(sLine, "%*s %d", &g_BaseInfo.UsingBaseServer);
				READ_TEXT_LINE( 6)	sscanf(sLine, "%*s %s", g_BaseInfo.ServerIP);
				READ_TEXT_LINE( 7)	sscanf(sLine, "%*s %s", g_BaseInfo.ServerPort);
				
				READ_TEXT_LINE( 8)	sscanf(sLine, "%*s %d", &g_BaseInfo.FPS);
				READ_TEXT_LINE( 9)	sscanf(sLine, "%*s %d", &g_BaseInfo.CameraInfo);
				READ_TEXT_LINE(10)	sscanf(sLine, "%*s %d", &g_BaseInfo.Box);
				
				READ_TEXT_LINE(11)	sscanf(sLine, "%*s %d", &g_BaseInfo.StartFullMode);
				READ_TEXT_LINE(12)	sscanf(sLine, "%*s %s", g_BaseInfo.FileClimate);
				READ_TEXT_LINE(13)	sscanf(sLine, "%*s %s", g_BaseInfo.FileExpLevel);
				READ_TEXT_LINE(14)	sscanf(sLine, "%*s %s", g_BaseInfo.FileFontList);
				READ_TEXT_LINE(15)	sscanf(sLine, "%*s %s", g_BaseInfo.FileHeightMap);
				
				READ_TEXT_LINE(16)	sscanf(sLine, "%*s %s", g_BaseInfo.FileLighting);
				READ_TEXT_LINE(17)	sscanf(sLine, "%*s %s", g_BaseInfo.FileLocalData);
				READ_TEXT_LINE(18)	sscanf(sLine, "%*s %s", g_BaseInfo.FileModel);
				READ_TEXT_LINE(19)	sscanf(sLine, "%*s %s", g_BaseInfo.FileSound);
				READ_TEXT_LINE(20)	sscanf(sLine, "%*s %s", g_BaseInfo.FileTexture);
				
				READ_TEXT_LINE(21)	sscanf(sLine, "%*s %s", g_BaseInfo.FileMenuData);
				READ_TEXT_LINE(22)	sscanf(sLine, "%*s %s", g_BaseInfo.FileUIData);
				READ_TEXT_LINE(23)	sscanf(sLine, "%*s %s", g_BaseInfo.FileUISetupData);
			}// while
		}// if
		
#undef	READ_TEXT_LINE
	}// while
	
	fclose(fp);
	
	return 1;
}