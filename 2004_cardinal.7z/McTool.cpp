// Implementation of the CMcTool class.
//
//////////////////////////////////////////////////////////////////////


#include "SeCommon.h"


CMcTool::CMcTool()
{

}

CMcTool::~CMcTool()
{

}
