// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


CMain::CMain()
:	m_pInput	(0)
,	m_pCamera	(0)

,	m_pLine		(0)
,	m_pDXFt		(0)
,	m_pGrid		(0)
,	m_dwFl		(3)
,	m_bFld		(1)
{
	m_pTxScn= NULL;
	m_pSF	= NULL;
	m_pRS	= NULL;

	m_pTxOrg	= NULL;
	m_pTxSct	= NULL;
	
	m_fFeedbackRotation        = 0.0f;
	m_fFeedbackRotationAccel   = 10.0f;
	m_fImageRotation           = 0.0f;
	m_fImageRotationAccel      = 30.0f;
	m_fFeedbackScale           = 10.0f;
	m_fFeedbackScaleAccel      = 1.0f;

	m_iTxW = 1024;
	m_iTxH = 512;
	
}


CMain::~CMain()
{
}


HRESULT CMain::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	m_bLoadingApp = FALSE;
	
	return S_OK;
}


HRESULT CMain::InitDeviceObjects()
{
	XYZInit();
	SAFE_NEWINIT(	m_pInput	);
	SAFE_NEWINIT(	m_pCamera	);
	SAFE_NEWINIT(	m_pGrid		);

	
	m_pVx1[0] = VtxDUV(-1.0f,  1.f, 0.f, 0.f, 0.f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx1[1] = VtxDUV( 1.0f,  1.f, 0.f, 1.f, 0.f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx1[2] = VtxDUV(-1.0f, -1.f, 0.f, 0.f, 1.f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx1[3] = VtxDUV( 1.0f, -1.f, 0.f, 1.f, 1.f, D3DCOLOR_ARGB(200,0,0,0));


	m_pVx2[0] = VtxDUV(-2.7f,  2.f, 0.f, .15f, .15f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx2[1] = VtxDUV( 2.7f,  2.f, 0.f, .85f, .15f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx2[2] = VtxDUV(-2.7f, -2.f, 0.f, .15f, .85f, D3DCOLOR_ARGB(200,0,0,0));
	m_pVx2[3] = VtxDUV( 2.7f, -2.f, 0.f, .85f, .85f, D3DCOLOR_ARGB(200,0,0,0));

	return S_OK;
}


HRESULT CMain::RestoreDeviceObjects()
{
	HRESULT hr=-1;
	
	HFONT hFont = CreateFont(  16, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,	ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" );
	
	if( FAILED( hr = D3DXCreateFont( GDEVICE, hFont, &m_pDXFt ) ) )
		return DXTRACE_ERR( "D3DXCreateFont", hr );
	
	DeleteObject(hFont);
	
	SAFE_RESTORE(	m_pCamera	);
	
	// Setup render states
	GDEVICE->SetRenderState( D3DRS_LIGHTING, FALSE );
	GDEVICE->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
	
	D3DSURFACE_DESC desc;
	
	// create scratch texture that's the same size as the image texture.
	// this also must be created as a render target.
	if (FAILED(hr = D3DXCreateTexture(GDEVICE, m_iTxW, m_iTxH, 1, D3DUSAGE_RENDERTARGET,
		D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pTxOrg)))
	{
		return(hr);
	}
	
	if (FAILED(hr = D3DXCreateTexture(GDEVICE, m_iTxW, m_iTxH, 1, D3DUSAGE_RENDERTARGET,
		D3DFMT_A8R8G8B8, D3DPOOL_DEFAULT, &m_pTxSct)))
	{
		return(hr);
	}
	

	D3DXCreateTexture(GDEVICE, m_iTxW, m_iTxH, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,  D3DPOOL_DEFAULT, &m_pTxScn);
	m_pTxScn->GetSurfaceLevel(0, &m_pSF);
	m_pSF->GetDesc(&desc);
	D3DXCreateRenderToSurface(GDEVICE, desc.Width , desc.Height, desc.Format, TRUE, GMAIN->m_d3dSettings.DepthStencilBufferFormat() ,&m_pRS);


	return S_OK;
}


HRESULT CMain::FrameMove()
{
	sprintf( m_sMsg, "%s %s   R�� ������..", m_strDeviceStats, m_strFrameStats	);
	
	SAFE_FRAMEMOVE(	m_pInput	);
	
	VEC3 vEye = VEC3( 0.0f, -0.0f, -2.f );
	VEC3 vAt  = VEC3( 0.0f, -0.0f, 0.0f );
	VEC3 vUp  = VEC3( 0.0f, 1.0f, 0.0f );
	D3DXMatrixLookAtLH( &m_mtViw, &vEye, &vAt, &vUp );
	GDEVICE->SetTransform( D3DTS_VIEW, &m_mtViw );
	
	FLOAT fSecsPerFrame = m_fElapsedTime*4.f;

	if (fSecsPerFrame < 0.00001f)
	{
		fSecsPerFrame = 0.00001f;
	}
	
	
	m_fFeedbackRotation += m_fFeedbackRotationAccel*fSecsPerFrame;

	if (m_fFeedbackRotation > 100.0f)
		m_fFeedbackRotationAccel = -5.0f;

	if (m_fFeedbackRotation < -100.0f)
		m_fFeedbackRotationAccel = 5.0f;
	
	m_fImageRotation += m_fImageRotationAccel*fSecsPerFrame;

	if (m_fImageRotation > 100.0f)
		m_fImageRotationAccel = -100.0f;

	if (m_fImageRotation < -100.0f)
		m_fImageRotationAccel = 100.0f;
	
	m_fFeedbackScale += m_fFeedbackScaleAccel*fSecsPerFrame;
	if (m_fFeedbackScale > 95.0f)
		m_fFeedbackScaleAccel = -10.1f;

	if (m_fFeedbackScale < 5.0f)
		m_fFeedbackScaleAccel = 10.1f;
	
	
	// 1. ������ Ÿ��
	PDSF pOldRenderTarget;
	GDEVICE->GetRenderTarget(0, &pOldRenderTarget);


	// 2. ������ ���̽��ٽ� ����
	PDSF pDepthSurf;
	GDEVICE->GetDepthStencilSurface(&pDepthSurf);
	
	
	
	// 3. ����, ��ũ��ġ �ؽ����� ���ǽ��� �����´�.
	PDSF pSfSct;
	PDSF pSfOrg;
	m_pTxSct->GetSurfaceLevel(0, &pSfSct);
	m_pTxOrg->GetSurfaceLevel(0, &pSfOrg);
	
	// 4. ��ũ��ġ ���Ǹ� ������۷� ����
	// �׸��� ����̽��� Ŭ����.
	GDEVICE->SetRenderTarget(0, pSfSct);
	GDEVICE->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x000000, 1.0f, 0L );
	
	// 5. ������ ����

	GDEVICE->SetRenderState(D3DRS_ZENABLE, D3DZB_FALSE);
	
	// 6. Į��� ������ ȥ���� ����

	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	
	
	// ��ũ��ġ ���񽺿� ������
	if (FAILED(GDEVICE->BeginScene()))
		return -1;

	// ���� ������ ����Ͽ� �ȼ��� 1:1 ������
	MAT mat;
	D3DXMatrixOrthoLH(&mat, (FLOAT)m_iTxW, (FLOAT)m_iTxH, 0.0, 100.0);
	GDEVICE->SetTransform( D3DTS_PROJECTION, &mat );
	
	MAT scalemat,destmat,rotmat;

	D3DXMatrixRotationZ(&mat, m_fFeedbackRotation);
	D3DXMatrixMultiply(&destmat, &mat, D3DXMatrixScaling(&scalemat, m_iTxW/1.8f, m_iTxH/1.8f, 1.0));
	GDEVICE->SetTransform( D3DTS_WORLD, &destmat );

	// set the original texture active
	GDEVICE->SetTexture(0, m_pTxOrg);
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetFVF( FVF_VTXDUV );
	GDEVICE->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx1, sizeof(VtxDUV));

	// ���� �̹����� �׸���.
	GDEVICE->SetTexture(0, m_pTxScn);
	D3DXMatrixScaling(&scalemat, (FLOAT)m_iTxW/5, (FLOAT)m_iTxH/5, 1.0);
	D3DXMatrixMultiply(&destmat, &scalemat, D3DXMatrixRotationZ(&rotmat, m_fImageRotation));
	GDEVICE->SetTransform( D3DTS_WORLD, &destmat );
	
	GDEVICE->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx1, sizeof(VtxDUV));

	GDEVICE->EndScene();

	
	// ���� �̹����� �׸� �ʿ䰡 �ִ�.
	// ���� �̹����� ������۷� �����ϵ� ����̽��� Ŭ���� ���� �ʴ´�.
	GDEVICE->SetRenderTarget(0, pSfOrg);
	
	// �������� ���ǽ��� ��ũ��ġ ���ǽ��� ���´�.
	// ��⼭ �ǵ�� ȿ���� ��Ÿ����.
	if (FAILED(GDEVICE->BeginScene()))
		return -1;

	// ���ĸ� ��ǻ��� ����
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	
	// �������� �ٽ� ����(�̹����� ����� �� �� �ִ� �������)
	MAT matWorld;
	D3DXMatrixScaling(&matWorld, (FLOAT)m_iTxW/2.0f, (FLOAT)m_iTxH/2.0f, 1.0);
	GDEVICE->SetTransform( D3DTS_WORLD, &matWorld );
	
	GDEVICE->SetTexture(0, m_pTxSct);
	GDEVICE->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx1, sizeof(VtxDUV));

	GDEVICE->EndScene();
	
	// ������ Ÿ���� �õ� Ÿ������ �ٲ۴�.
	// ���ǽ��� ���� ������
	pSfOrg->Release();
	pSfSct->Release();

	GDEVICE->SetRenderState(D3DRS_ZENABLE, D3DZB_TRUE);


	// For our world matrix, we will just leave it as the identity
	D3DXMatrixIdentity( &matWorld );
	GDEVICE->SetTransform( D3DTS_WORLD, &matWorld );
	
	
	GDEVICE->SetSamplerState( 0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState( 0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState( 0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	
	SAFE_FRAMEMOVE(	m_pCamera	);
	m_pCamera->SetProjParam();


	GDEVICE->SetRenderTarget(0, m_pSF);
	GDEVICE->BeginScene();

		GDEVICE->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x00006688, 1.0f, 0L );
		GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
		GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
		GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
		GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
		GDEVICE->SetRenderState( D3DRS_ZWRITEENABLE, TRUE);
		GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
		GDEVICE->SetRenderState( D3DRS_ZWRITEENABLE, TRUE );

		SAFE_RENDER(	m_pGrid	);
		XYZRender();

	GDEVICE->EndScene();

	GDEVICE->SetRenderTarget(0, pOldRenderTarget);
	GDEVICE->SetDepthStencilSurface(pDepthSurf);
	pOldRenderTarget->Release();
	pDepthSurf->Release();



	// Set up the projection matrix
	FLOAT fAspectRatio = (FLOAT)m_d3dsdBackBuffer.Width / (FLOAT)m_d3dsdBackBuffer.Height;
	D3DXMatrixPerspectiveFovLH( &m_mtPrj, D3DXToRadian(90), fAspectRatio, 0.1f, 100.0f );
	GDEVICE->SetTransform( D3DTS_PROJECTION, &m_mtPrj );
	
	
	D3DXMatrixLookAtLH( &m_mtViw, &vEye, &vAt, &vUp );
	GDEVICE->SetTransform( D3DTS_VIEW, &m_mtViw );


	return S_OK;
}




HRESULT CMain::Render()
{
	// Clear the backbuffer
	GDEVICE->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER|D3DCLEAR_STENCIL, 0x00006688, 1.0f, 0L );	
	
	// begin rendering the scene
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;
	
//	GDEVICE->SetRenderState(D3DRS_FILLMODE, m_dwFl);
//	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
//	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
//	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
//	GDEVICE->SetRenderState( D3DRS_ZWRITEENABLE, TRUE );
//	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
//	
//	SAFE_RENDER(	m_pGrid	);
//	XYZRender();
//
//
//	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);
	
	// set our texture active...

	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1 );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTexture( 0, m_pTxOrg );
	GDEVICE->SetFVF( FVF_VTXDUV );
	GDEVICE->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, m_pVx2, sizeof(VtxDUV));
	
	
	
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);

	SeRect rt(2, 10, m_d3dsdBackBuffer.Width - 20, 30);
	
	m_pDXFt->Begin();
	m_pDXFt->DrawText( m_sMsg, -1, &rt.GetRECT(), 0, D3DCOLOR_ARGB(255,255,255,0));
	m_pDXFt->End();

	GDEVICE->EndScene();

	return S_OK;
}


HRESULT CMain::InvalidateDeviceObjects()
{
	SAFE_RELEASE( m_pTxOrg );
	SAFE_RELEASE( m_pTxSct );

	SAFE_RELEASE(	m_pDXFt		);


	SAFE_RELEASE(	m_pRS	);
	SAFE_RELEASE(	m_pSF	);
	SAFE_RELEASE(	m_pTxScn	);

	return S_OK;
}



HRESULT CMain::DeleteDeviceObjects()
{
	INT i=0;
	
	XYZDestroy();
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamera	);
	SAFE_DELETE(	m_pGrid		);

	return S_OK;
}



void CMain::XYZInit()
{
	INT		i;
	INT		j;
	FLOAT	fMax;
	
	fMax = 10000;
	m_pLine = (VtxD*)malloc( (6 + 8*4 ) * 2 * sizeof(VtxD));
	
	m_pLine[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pLine[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pLine[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pLine[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pLine[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pLine[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);
	
	j =6 * 2;
	
	for(i=0; i<8; ++i)
	{
		m_pLine[j + 8*i +0 ] = VtxD(-128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +1 ] = VtxD( 128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +2 ] = VtxD(-128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +3 ] = VtxD( 128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		
		m_pLine[j + 8*i +4 ] = VtxD( 16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +5 ] = VtxD( 16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +6 ] = VtxD(-16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +7 ] = VtxD(-16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
	}
	
}


void CMain::XYZDestroy()
{
	SAFE_FREE(		m_pLine		);
}

void CMain::XYZRender()
{
	// Render Lines
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
//	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
//	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetFVF(FVF_VTXD);
	
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6 + 32, m_pLine, sizeof(VtxD));
}