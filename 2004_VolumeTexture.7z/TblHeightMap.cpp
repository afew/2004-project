// TblHeightMap.cpp: implementation of the CTblHeightMap class.
//
//////////////////////////////////////////////////////////////////////


#include "Common.h"


// Construction/Destruction

CTblHeightMap::CTblHeightMap()
{
	memset(m_szVersion, 0, sizeof(TCHAR) * 32);
	m_nIdxLocal	= -1;
	m_iNumGridX	= -1;
	m_iNumGridZ	= -1;

	m_iWidthGridX =-1;
	m_iWidthGridZ =-1;

	m_ppSMapAttrib = NULL;

}

CTblHeightMap::~CTblHeightMap()
{
	Destroy();	
}


void CTblHeightMap::Destroy()
{
	if(m_ppSMapAttrib)
	{
		for(INT i=0; i<m_iNumGridZ; ++i)
			SAFE_DELETE_ARRAY(m_ppSMapAttrib[i]);
		
		SAFE_DELETE_ARRAY(m_ppSMapAttrib);
	}
}


INT CTblHeightMap::Init()
{
//	Save();				// for test

	if(FAILED(Load(g_BaseInfo.FileHeightMap)))
		return -1;

	// for grid...

	return 1;
}

INT CTblHeightMap::Load(TCHAR*	 pcFileName)
{
	INT i, j;
	FILE* fp = NULL;
	
	fp = fopen(pcFileName, "rb");

	if(NULL == fp)
	{
		return -1;
	}

	fread(m_szVersion,sizeof(TCHAR), 32, fp);	// version
	fread(&m_nIdxLocal, sizeof(INT),1,fp);		// local index
	fread(&m_iNumGridX,sizeof(INT), 1, fp);		// tile number x
	fread(&m_iNumGridZ,sizeof(INT), 1, fp);		// tile number z
	fread(&m_iWidthGridX,sizeof(INT), 1, fp);	// tile width x
	fread(&m_iWidthGridZ,sizeof(INT), 1, fp);	// tile width z

	m_ppSMapAttrib = new UMapAttrib*  [m_iNumGridZ];

	for(i=0; i< m_iNumGridZ; ++i)
		m_ppSMapAttrib[i] = new UMapAttrib[m_iNumGridX];


	for(j=0; j< m_iNumGridZ; ++j)
	{
		for(i=0; i< m_iNumGridX; ++i)
		{
			fread(&m_ppSMapAttrib[j][i], sizeof(UMapAttrib), 1, fp);
//			printf("%d %d %d \n" , j, i, m_ppSMapAttrib[j][i]);
		}
	}
	
	fclose(fp);

	return 1;
}




INT CTblHeightMap::Save()
{
	INT i, j;
	FILE* fp = NULL;
	
	TCHAR	sVersion[32]="0.0.1";
	INT		nIdxLocal = 1;
	INT		iWidthGridX = 16;
	INT		iWidthGridZ = 16;
	INT		iNumGridX = iWidthGridX * 4 * 20;
	INT		iNumGridZ = iWidthGridZ * 4 * 20;
	
	

	UMapAttrib ** ppiAttrib = NULL;

	fp = fopen(g_BaseInfo.FileHeightMap, "wb");

	if(NULL == fp)
		return -1;

	fwrite(sVersion,sizeof(TCHAR), 32, fp);		// version
	fwrite(&nIdxLocal, sizeof(INT),1,fp);		// local index
	fwrite(&iNumGridX,sizeof(INT), 1, fp);		// tile number x
	fwrite(&iNumGridZ,sizeof(INT), 1, fp);		// tile number z
	fwrite(&iWidthGridX,sizeof(INT), 1, fp);	// tile width x
	fwrite(&iWidthGridZ,sizeof(INT), 1, fp);	// tile width z


	// for attribute
	ppiAttrib = new UMapAttrib*  [iNumGridZ];

	for(i=0; i< iNumGridZ; ++i)
		ppiAttrib[i] = new UMapAttrib[iNumGridX];


	for(j=0; j< iNumGridZ; ++j)
	{
		for(i=0; i< iNumGridX; ++i)
		{
			ppiAttrib[j][i].m_dwAttrib = 1+ (i+ j * iNumGridZ)%15;
		}
	}


	for(j=0; j< iNumGridZ; ++j)
	{
		for(i=0; i< iNumGridX; ++i)
		{
			fwrite(&ppiAttrib[j][i],sizeof(UMapAttrib), 1, fp);
		}
	}
	
	fclose(fp);


	if(ppiAttrib)
	{
		for(INT i=0; i<iNumGridZ; ++i)
			SAFE_DELETE_ARRAY(ppiAttrib[i]);
		
		SAFE_DELETE_ARRAY(ppiAttrib);
	}


	return 1;
}