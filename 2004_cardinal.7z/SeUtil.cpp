//////////////////////////////////////////////////////////////////////
// SeUtil.cpp: implementation of the CSeScene class.
//

#include "SeCommon.h"

CStrRoll::CStrRoll()
{
	iCur	=   0;
	nNumLine=   0;
	iDY		=  15;		// ����
	m_szString= NULL;
}


INT CStrRoll::Init()
{
	INT i=0;

	iCur	=   0;
	nNumLine=  20;
	iStartX	= 800;
	iDY		=  15;

	m_szString = new char[nNumLine][2048];

	for(i=0; i<nNumLine; ++i)
		memset(m_szString[i], 0, sizeof(char)*2048);


	return 1;
}

void CStrRoll::Destroy()
{
	SAFE_DELETE_ARRAY(m_szString);
}

void CStrRoll::SetString(const char *format, ...)
{
	va_list ap;
	char str[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)str, format, ap);
	va_end(ap);
	
	if (str == NULL)
		return;
	
	++iCur;			// Current�� ���� ��Ű��

	iCur %= nNumLine;
	sprintf(m_szString[iCur], "%s", str);
//	sprintf(m_szString[iCur], "%d %s", iCur, str);
}

CStrRoll::~CStrRoll()
{
	Destroy();
}



void CStrRoll::PrintString(INT iStartY)
{
	INT i=0;
	INT j=0;
	INT iY=0;

	for(i= iCur + nNumLine; i>iCur ; --i)
	{
		if(m_szString[i%nNumLine])
		{
			iY = iStartY- j*iDY;
			TextOut(GHDC, iStartX, iY, m_szString[i%nNumLine], strlen(m_szString[i%nNumLine]));
			++j;
		}// if
	}// for
}




_TICK::_TICK()
{
	m_tick = 0;
} /* _TICK::_TICK */

_TICK::~_TICK()
{
} /* _TICK::~_TICK */

void _TICK::clear(void)
{
	//  ���� �ð��� ���� Ŭ���� ��;
	m_next_tick = timeGetTime() + m_tick;
//	m_next_tick = GETIME + m_tick;

	over = tog = 0;
} /* _TICK::clear */

void _TICK::clear2cur(void)
{
	// ���� �ð����� Ŭ���� ��;
	m_next_tick = timeGetTime();
//	m_next_tick = GETIME;
	over = tog = 0;
} /* _TICK::clear2cur */

void _TICK::init(INT tick)
{
	m_tick = tick;
	
	clear();
} /* _TICK::init */

void _TICK::user(void)
{
	DWORD tick;
	
	if (m_tick == 0)
		return;
	
	tick = timeGetTime();
//	tick = GETIME;
	
	if (tick >= m_next_tick)
	{
		m_next_tick += m_tick;
		
		tog ^= 1;
		over = 1;
	}
	else {
		over = 0;
	}
} /* _TICK::user */




void SeUtil_ErrMsgBox(TCHAR *format,...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	MessageBox(NULL, s, "Err", MB_OK | MB_ICONERROR);
}



void SeUtil_GetLastError(HWND hWnd)
{
	LPVOID lpMsgBuf;
	FormatMessage(FORMAT_MESSAGE_ALLOCATE_BUFFER|FORMAT_MESSAGE_FROM_SYSTEM,
				  NULL, GetLastError(), MAKELANGID(LANG_NEUTRAL, SUBLANG_DEFAULT),
				  (LPTSTR) &lpMsgBuf, 0, NULL);
	MessageBox(hWnd, (LPTSTR)lpMsgBuf, "GetLastError", MB_OK|MB_ICONERROR);
	LocalFree(lpMsgBuf);
}



char *getSmallTime(void)
{
	static char tm_str[128 + 1];
	SYSTEMTIME st;

	GetLocalTime(&st);
	strcpy(tm_str,
		SeUtil_Forming("'%04d-%02d-%02d\t'%02d:%02d:%02d.%03d",
		//SeUtil_Forming("%04dy\t%02dm %02dd\t%02dh %02dm\t%02d.%03ds",
		(INT)st.wYear, (INT)st.wMonth, (INT)st.wDay,
		(INT)st.wHour, (INT)st.wMinute, (INT)st.wSecond, (INT)st.wMilliseconds));

	return(tm_str);
} /* getSmallTime */


void SeUtil_FormatLog(TCHAR *format,...)
{
	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log.txt", "a+");
	
	fprintf(fp, "%s\t%s\n", getSmallTime(), szDbgBuf);

	fclose(fp);
	// ���� ���   
}


void SeUtil_FormatLog2(TCHAR *format,...)
{
//	if (!g_BaseInfo.File_Log) return;
	va_list		vl;
	TCHAR		szDbgBuf[2048];
	
	
	va_start(vl, format);
	wvsprintf(szDbgBuf, format, vl);
	va_end(vl);
	
	FILE * fp;
	
	fp = fopen("Log/Log_2.txt", "a+");
	
	fprintf(fp, "%s\t%s\n", getSmallTime(), szDbgBuf);

	fclose(fp);
	// ���� ���   
}


// Texture Load
INT SeUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color, D3DXIMAGE_INFO *pSrcInfo, DWORD Filter, DWORD MipFilter, D3DFORMAT d3dFormat)
{
//	HRESULT D3DXCreateTextureFromFileEx(
//	LPDIRECT3DDEVICE9 pDevice,
//    LPCTSTR pSrcFile,
//    UINT Width,
//    UINT Height,
//    UINT MipLevels,
//    DWORD Usage,
//    D3DFORMAT Format,
//    D3DPOOL Pool,
//    DWORD Filter,
//    DWORD MipFilter,
//    D3DCOLOR ColorKey,
//    D3DXIMAGE_INFO *pSrcInfo,
//    PALETTEENTRY *pPalette,
//    LPDIRECT3DTEXTURE9 *ppTexture
//);
	
	if ( FAILED(D3DXCreateTextureFromFileEx(
		GDEVICE
		, sFileName
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, D3DX_DEFAULT
		, 0
		, d3dFormat	//, D3DFMT_UNKNOWN
		, D3DPOOL_MANAGED
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
//		, D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR
		, Filter
		, MipFilter
		, _color
		, pSrcInfo
		, NULL
		, &texture
		)) )
	{
		texture = NULL;
		return -1;
	}
	
	return 1;
}





void SeUtil_ReadFileLine(FILE *fp, TCHAR *str, INT nStr)
{
	static TCHAR sTmp1[1024];
	static TCHAR sTmp2[1024];
	
	INT nSize;
	INT nStart, nEnd;
	UINT i, j, k;

	memset(sTmp1,0, sizeof(sTmp1));
	memset(sTmp2,0, sizeof(sTmp2));

	fgets(str, nStr, fp);

	nSize = strlen(str);
	
	for(i=0; i<strlen(str); ++i)
	{
		if(str[i] == '\t')	str[i] =' ';
//		if(str[i] == '"')	str[i] =' ';
		
		if(str[i] == '\n' || str[i] == '\r')
		{
			for(j=i; j<strlen(str); ++j)
				str[j] ='\0';
		}
	}
	
	nStart=0;
	nEnd= strlen(str);
	
	for(i=0; i<strlen(str); ++i){	if(str[i] != ' ')	{	nStart =i;	break;	}	}
	for(i=0; i<strlen(str); ++i){	if(str[i] == '\0')	{	nEnd =i;	break;	}	}
	
	strncpy(sTmp1, str + nStart, nEnd-nStart);
	
	j=0;
	for(k=0; k<nEnd-nStart+1; ++k)
	{
		if( !(' ' ==sTmp1[k] &&' ' ==sTmp1[k+1]))
		{
			if( ' ' ==sTmp1[k] && '\0'==sTmp1[k+1])
				sTmp2[j]= '\0';
			
			else
				sTmp2[j]= sTmp1[k];
			
			++j;
		}
	}
	
	strcpy(str, sTmp2);
}


void SeUtil_ReadLineQuot(TCHAR *strOut, TCHAR *strIn, INT iC)
{
	TCHAR*	p;
	INT iS;
	INT iE;
	INT iD;

	// Search forward
	p = strchr(strIn, iC);
	iS = p - strIn + 1;

	if(!p)
	{
		strOut[0]=0;
		return;
	}

	// Search backward
	p = strrchr( strIn, iC);

	iE = p - strIn + 1;

	if(iS != iE)
		iD = iE - iS -1;

	else
		iD = strlen(strIn) - iS;

	strncpy(strOut, strIn+iS, iD);
	strOut[iD]=0;
}


void SeUtil_VBCreate(PDVB& pVB, INT nSize, DWORD fvf, void* pVtx, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateVertexBuffer(nSize,
		0,
		fvf,
		usage,
		&pVB, NULL );
	
	if( FAILED(hr) )
	{
		SeUtil_ErrMsgBox("Vertex create failed");
		return ;
	}
	
	if(!pVtx)
		return;

	SeUtil_VBLock(pVB, nSize, pVtx);
}


void SeUtil_VBLock(PDVB& pVB, INT nSize, void* pVtx)
{
	void* p;
	
	if( FAILED( pVB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy( p, pVtx, nSize);
	pVB->Unlock();
}


void SeUtil_IBCreate(PDIB& pIB, INT nSize, void* pIdx, D3DFORMAT fmt, D3DPOOL usage)
{
	HRESULT hr;
	
	hr = GDEVICE->CreateIndexBuffer( nSize, 0, fmt, usage, &pIB, NULL);
	
	if( FAILED(hr) )
	{
		SeUtil_ErrMsgBox("Index buffer create failed");
		return ;
	}
	
	if(!pIdx)
		return;

	SeUtil_IBLock(pIB, nSize, pIdx);
}


void SeUtil_IBLock(PDIB & pIB, INT nSize, void* pIdx)
{
	void* p;
	
	if( FAILED( pIB->Lock( 0, 0, &p, 0 )))
		return;
	
	memcpy(p, pIdx, nSize);
	pIB->Unlock();
}



bool SeUtil_LineCross2D(VEC2 * p)
{
	VEC2 L1 = p[1] - p[0];
	VEC2 L2 = p[3] - p[2];
	VEC2 L3 = p[2] - p[0];
	
	
	FLOAT fAlpha = L2.x * L1.y - L2.y * L1.x;
	
	if(0.f == fAlpha)
		return false;
	
	FLOAT fBeta = fAlpha;
	
	fAlpha = (L2.x * L3.y - L2.y * L3.x)/fAlpha;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	fBeta = (L2.x * L3.y - L1.y * L3.x)/fBeta;
	
	if( (0.f > fAlpha) || (fAlpha > 1.f) )
		return false;
	
	return true;
}

INT SeUtil_3Dto2D(VEC3& Out, const VEC3& In)
{
	MAT		mtV;																// View matrix
	MAT		mtP;																// Projection matrix
	MAT		mtVP;																// view matrix * projection matrix
	VEC3	vcPc;																// Camera pos
	VEC3	vcZ;																// Normal vector
	FLOAT	fNear=1.f;
	FLOAT	beta;
	VEC3	vcB;
	FLOAT	fW;
	FLOAT	fH;

	mtV		= GCAMERA->GetViewMatrix();
	mtP		= GCAMERA->GetProjMatrix();
	vcPc	= GCAMERA->GetPos();
	vcZ		= GCAMERA->GetAxisZ();
	
	beta	= D3DXVec3Dot(&vcZ, &(In - vcPc));
	
	if(beta<=fNear)
		return 0;			// �������� ��� �ڿ� ����.

	beta = fNear/beta;
	vcB = beta * (In - vcPc) -fNear * vcZ;

	D3DXMatrixMultiply(&mtVP, &mtV, &mtP);
	
	Out.x	= vcB.x * mtVP._11 + vcB.y * mtVP._21 + vcB.z * mtVP._31;			// ���� Model view Matrix�� �����Ѵ�.
	Out.y	= vcB.x * mtVP._12 + vcB.y * mtVP._22 + vcB.z * mtVP._32;
	Out.z	= vcB.x * mtVP._13 + vcB.y * mtVP._23 + vcB.z * mtVP._33;
	
	fW		= FLOAT(GMAIN->m_dwCreationWidth);									//�������� ȭ�� scale�� Projection�Ѵ�.
	fH		= FLOAT(GMAIN->m_dwCreationHeight);
	
	Out.x	=  fW * (Out.x +1.f) * 0.5f;
	Out.y	= -fH * (Out.y -1.f) * 0.5f;

	return 1;
}





bool SeUtil_PositionMouse3D(VEC3& vec3dOut)
{
	MAT matView;
	MAT matProj;
	MAT matViewProj;
	MAT matViewInv;
	
	MAT matViewProjInv;
	
	GDEVICE->GetTransform(D3DTS_VIEW, &matView);
	GDEVICE->GetTransform(D3DTS_PROJECTION,&matProj);
	
	D3DXMatrixIdentity(&matViewProj);
	
	matViewProj = matView * matProj;
	D3DXMatrixInverse(&matViewProjInv, NULL, &matViewProj);
	
	POINT	pt;
	RECT	rt;
	
	::GetCursorPos(&pt);
	::GetWindowRect(GHWND, &rt);
	
	VEC3 vecBefore( 2.f * pt.x /FLOAT(rt.right-rt.left) -1,
		-2.f * pt.y /FLOAT(rt.bottom - rt.top) +1,
		0);
	
	VEC3 vecP(0,0,0);
	
	
	// ���� Model view Matrix�� �����Ѵ�.
	
	vecP.x = vecBefore.x * matViewProjInv._11 + vecBefore.y * matViewProjInv._21 + vecBefore.z * matViewProjInv._31;
	vecP.y = vecBefore.x * matViewProjInv._12 + vecBefore.y * matViewProjInv._22 + vecBefore.z * matViewProjInv._32;
	vecP.z = vecBefore.x * matViewProjInv._13 + vecBefore.y * matViewProjInv._23 + vecBefore.z * matViewProjInv._33;
	
	//camera position
	D3DXMatrixInverse(&matViewInv, NULL, &matView);
	VEC3 vecCamPos(matViewInv._41, matViewInv._42, matViewInv._43);
	
	//Normalvector
	VEC3 vecZ( matView._13, matView._23, matView._33);
	
	FLOAT beta =(vecZ.y + vecP.y);
	
	if (0.f == beta)
		return false;
	
	beta =  -vecCamPos.y/beta;
	
	vec3dOut = beta * (vecZ + vecP) + vecCamPos;
	
	return true;
}


INT SeUtil_DrawHDCText(INT X, INT Y, LPCTSTR Text, DWORD _color)
{	
	HDC hDC;
	LPDIRECT3DSURFACE9 Surface;
	
	if(FAILED(GDEVICE->GetBackBuffer(0, 0, D3DBACKBUFFER_TYPE_MONO, &Surface)))
		return -1;
	
	Surface->GetDC(&hDC);
	
	if(NULL != hDC)
	{
		SetBkMode(hDC, TRANSPARENT);
		SetTextColor(hDC, _color);
		TextOut(hDC, X, Y, Text, strlen(Text));

		Surface->ReleaseDC(hDC);
	}
	
	Surface->Release(); //�����Ѵ�.
	
	
	return 1;
}


void SeUtil_SetWindowTitle(const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	SetWindowText(GHWND, s);
}



void SeUtil_TextOut(float x, float y, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	TextOut(GHDC, INT(x), INT(y), s, strlen(s));
}


void SeUtil_TextOut(VEC2 p, const char *format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;

	TextOut(GHDC, INT(p.x), INT(p.y), s, strlen(s));
}




void SeUtil_OutputDebug(const char * format, ...)
{
	va_list ap;
	char s[2048];
	
	if (format == NULL) return;
	
	va_start(ap, format);
	vsprintf((char *)s, format, ap);
	va_end(ap);
	
	if (s == NULL)	return;
	
	::OutputDebugString(s);
}



TCHAR*	SeUtil_GetFolder(TCHAR*	sPath, HWND hWnd, TCHAR* sTitle)
{
	BROWSEINFO		bi;
	static TCHAR	sPathName[1024];
	static TCHAR	sPathFull[1024];
	LPITEMIDLIST	pidl = NULL;
	LPITEMIDLIST	pidlFolder= NULL;
	LPMALLOC		pMalloc = NULL;

	memset(sPathName, 0, sizeof(sPathName));
	memset(sPathFull, 0, sizeof(sPathFull));
	memset(&bi, 0, sizeof(BROWSEINFO));

	bi.hwndOwner = hWnd;
	bi.lpszTitle = sTitle;
	bi.ulFlags = BIF_STATUSTEXT |BIF_EDITBOX   ;
	bi.ulFlags = BIF_EDITBOX   ;

	GetCurrentDirectory(1024, sPathFull);

	LPSHELLFOLDER pShellFolder = NULL;
	OLECHAR wszPath[MAX_PATH] = {0};
	ULONG nCharsParsed = 0;
	
	// Get an IShellFolder interface pointer
	::SHGetDesktopFolder(&pShellFolder);
	
	// Convert the path name to Unicode
	::MultiByteToWideChar(CP_ACP, MB_PRECOMPOSED, sPathFull, -1, wszPath, MAX_PATH);
	
	// Call ParseDisplayName() to do the job
	pShellFolder->ParseDisplayName(NULL, NULL, wszPath, &nCharsParsed, &pidl, NULL);

	bi.pidlRoot = pidl;


	pidlFolder = SHBrowseForFolder(&bi);

	if(pidlFolder == NULL)
	{
		sPath[0] =0;
		sPathFull[0];
		return sPathFull;														//����� ���
	}

	SHGetPathFromIDList(pidlFolder, sPathName);

	strcpy(sPath, sPathName);
	strcpy(sPathFull, sPathName);

	SHGetMalloc(&pMalloc);
	pMalloc->Free(pidl);
	pMalloc->Free(pidlFolder);
	pMalloc->Release();

	return sPathFull;
}


TCHAR*	SeUtil_DWtoStr(DWORD dwA)
{
	static char		s[32];
	static char*	pDst;

	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", dwA);
	pDst = s + strlen(s) - 8;

	return pDst;
}


void SetDlgItemFloat(HWND hWnd, UINT id, float z, INT decimal)
{
	char s[128];
	char f[64];
	
	sprintf(f,"%%.%df", decimal);
	memset(s, 0, sizeof(s));
	sprintf(s, f, z);
	SetDlgItemText(hWnd,id,s);
}

FLOAT GetDlgItemFloat(HWND hWnd, UINT id)
{
	char s[256];
	memset(s, 0, sizeof(s));

	GetDlgItemText(hWnd, id, s, sizeof(s));
	return atof(s);
}

void SetDlgItemHex(HWND hWnd, UINT id, INT val)
{
	char	buf[64] = "0x";
	char	s[32];
	char*	pDst;
	memset(s, 0, sizeof(s));
	sprintf(s, "0000000000%X", val);
	pDst = s + strlen(s) - 8;

	strcat(buf, pDst);
	SetDlgItemText(hWnd,id,buf);
}


///////////////////////////////////////////////////////////////////////////////
// SeUtil_PluckFirstField()
//  str���ڿ��� delim���� �ձ��� ���� dest�� �ִ´�. (maxlen�� ���� �ʴ� ����) 
//  �Լ� ���� �� str�� Pointer�� delim���� ������ ���δ�.
///////////////////////////////////////////////////////////////////////////////
INT SeUtil_PluckFirstField(char *str, char *dest, INT maxlen, const char *delim)
{
  char *endpos;
  INT p;

  if (!strlen(delim)) { strcpy(dest, str); return 0; }
  endpos = strstr(str, delim);
  if (!endpos) { strcpy(dest, str); return 0; }
  p = endpos - str;

  memset(dest, 0, maxlen);
  memcpy(dest, str, p);

  // pluck it off of str...
  strcpy(str, &str[p+strlen(delim)]);

  return p;
}



char*	SeUtil_Forming(const char *fmt, ...)
{
#define FORMING_1CALL_STR_TOTAL 512
#define FORMING_RECALL_TOTAL 100
#define FORMING_BUF_TOTAL (FORMING_1CALL_STR_TOTAL * FORMING_RECALL_TOTAL)
	static char formingbuf[FORMING_BUF_TOTAL], formingfmt[FORMING_1CALL_STR_TOTAL + 1];
	static INT index_formingbuf;
	va_list arglist;
	char *strp;
	
	va_start(arglist, fmt);
	vsprintf(formingfmt, fmt, arglist);
	va_end(arglist);
	if (index_formingbuf + strlen(formingfmt) + 1 >= FORMING_BUF_TOTAL) index_formingbuf = 0;
	strp = formingbuf + index_formingbuf;
	strcpy(strp, formingfmt);
	index_formingbuf += strlen(formingfmt) + 1;
	return(strp);
}


char *special_symbols = "";
INT special_symbol_is_token;
INT strtoken_case_sensitive;
INT accept_string_token;
INT white_space_is_token;
INT detect_special_symbol_only;

char tokenv_str[TOKENV_TOTAL];
INT tokenv_orgpos[TOKENV_TOTAL / 2];
INT tokenv_pos[TOKENV_TOTAL / 2]; // total # of token is (TOKENV_TOTAL / 2). when string fill by (1 chr. + ' ')n;


void init_token(void)
 {
	special_symbols = "";
	special_symbol_is_token = 0;
	strtoken_case_sensitive = 0;
	accept_string_token = 0;
	white_space_is_token = 0;
	detect_special_symbol_only = 0;
} /* init_token */


INT _isspace(INT ch) {
	


	if (detect_special_symbol_only) return(0);
	if (ch < 0) return(0);
	return(isspace(ch));
} /* _isspace */



INT tokenc(char *ss) {
   char togl, ch;
   INT iii, jjj, len, index;
   INT skip;

   if (ss[0] == '\0' || strlen(ss) >= TOKENV_TOTAL) return(0);
   tokenv_str[0] = 0;
   index = 0;
   togl = 0;
   jjj = 0;
   skip = 0;
   len = strlen(ss);
   for (iii = 0; iii < len; iii++) {
       ch = ss[iii];
	   if (accept_string_token) {
		   if (ch == '"') skip ^= 1;
		   } // if (accept_string_token);
       if (!skip && ((!white_space_is_token && _isspace(ch)) || (!special_symbol_is_token && strchr(special_symbols, ch) != NULL))) {
          tokenv_str[index] = 0;
          if (togl) {
             index++;
             togl = 0;
             }
          }
       else {
            if (!skip && ((white_space_is_token && _isspace(ch)) || strchr(special_symbols, ch) != NULL)) { // is special-symbol;
               if (togl) {
                  tokenv_str[index++] = 0;
                  togl = 0;
                  }
               tokenv_orgpos[jjj] = iii;
               tokenv_pos[jjj++] = index;
               tokenv_str[index++] = ch;
               tokenv_str[index++] = 0;
               }
            else {
                 if (togl == 0) {
                    tokenv_orgpos[jjj] = iii;
                    tokenv_pos[jjj++] = index;
                    }
                 tokenv_str[index++] = ch;
                 togl = 1;
                 }
            }
       if (index >= TOKENV_TOTAL) return(0);
       } // for (iii);
   tokenv_str[index] = 0;
   return(jjj);
} /* tokenc */

char *tokenv(INT num) {
   return(tokenv_str + tokenv_pos[num]);
} /* tokenv */




INT chkabound2(INT x1, INT y1, INT x2, INT y2, INT x3, INT y3, INT x4, INT y4)
{
	if (x1 <= x4 && x2 >= x3 && y1 <= y4 && y2 >= y3) return(1);
	return(0);
}






void *(*fastcpy)(void *pDest, const void *pSrc, UINT size);


void pathcpy(TCHAR *dst, TCHAR *src)
{
	INT iii;
	
	strcpy(dst, src);
	for (iii = strlen(dst); ; iii--)
	{
		if (dst[iii] == '\\')
		{
			dst[iii] = 0;
			break;
		}
	} // for (iii);
} /* pathcpy */


TCHAR *strptr(TCHAR *str, INT next)
{
	while (next)
	{
		str += strlen(str) + 1;
		next--;
	} // while;
	
	return(str);
} /* strptr */



INT htoi(TCHAR *str)
{
	// Hex to Int.;
	INT len, iii, val, ch;
	
	len = strlen(str);
	val = 0;
	for (iii = 0; iii < len; iii++)
	{
		val *= 16;
		ch = toupper(*str++);
		if (ch >= '0' && ch <= '9') val += ch - '0';
		else
		{
			if (ch >= 'A' && ch <= 'F') val += 10 + ch - 'A';
			else return(0);
		}
	}
	
	return(val);
} /* htoi */




INT folder(BYTE *dst, BYTE *src, INT len_src)
{
	INT iii, cnt, index, iold;
	INT same;
	
	same = (src[0] == src[1]) ? 1 : 0;
	index = iold = 0;
	cnt = 1;
	for (iii = 0; iii < len_src - 1; iii++)
	{
		switch (same)
		{
		case 0 :
			if (src[iii] == src[iii + 1])
			{
				same = 1;
				cnt--;
				while (cnt > 127)
				{
					dst[index++] = 127;
					memcpy(dst + index, src + iold, 127);
					index += 127;
					iold += 127;
					cnt -= 127;
				}
				if (cnt)
				{
					dst[index++] = cnt;
					memcpy(dst + index, src + iold, cnt);
					index += cnt;
				}
				cnt = 1;
				iii--;
			}
			else cnt++;
			break;
		case 1 :
			if (src[iii] != src[iii + 1])
			{
				same = 0;
				iold = iii + 1;
				while (cnt > 127)
				{
					dst[index++] = 127 | 0x80;
					dst[index++] = src[iii];
					cnt -= 127;
				}
				if (cnt)
				{
					dst[index++] = cnt | 0x80;
					dst[index++] = src[iii];
				}
				cnt = 1;
			}
			else cnt++;
			break;
		}
	}
	if (cnt == 1 && same) cnt++;
	if (same == 0)
	{
		while (cnt > 127)
		{
			dst[index++] = 127;
			memcpy(dst + index, src + iold, 127);
			index += 127;
			iold += 127;
			cnt -= 127;
		}
		if (cnt)
		{
			dst[index++] = cnt;
			memcpy(dst + index, src + iold, cnt);
			index += cnt;
		}
	}
	else
	{
		while (cnt > 127)
		{
			dst[index++] = 127 | 0x80;
			dst[index++] = src[iii];
			cnt -= 127;
		}
		if (cnt)
		{
			dst[index++] = cnt | 0x80;
			dst[index++] = src[iii];
		}
	}
	return(index);
} /* folder */

void unfolder(BYTE *dst, BYTE *src, INT len_src)
{
	INT iii, index;
	INT cnt;
	
	index = 0;
	for (iii = 0; iii < len_src; iii++)
	{
		if (src[iii] > 127)
		{
			cnt = src[iii] & 0x7f;
			iii++;
			memset(dst + index, src[iii], cnt);
			index += cnt;
		}
		else
		{
			cnt = src[iii];
			memcpy(dst + index, src + iii + 1, cnt);
			iii += cnt;
			index += cnt;
		}
	} // for (iii);
} /* unfolder */

INT folder(FILE *dst, BYTE *src, INT len_src) { // from Memory to File;
	INT iii, cnt, index, iold;
	INT same, tmp;
	
	same = (src[0] == src[1]) ? 1 : 0;
	index = iold = 0;
	cnt = 1;
	for (iii = 0; iii < len_src - 1; iii++)
	{
		switch (same)
		{
		case 0 :
			if (src[iii] == src[iii + 1])
			{
				same = 1;
				cnt--;
				while (cnt > 127)
				{
					tmp = 127;
					fwrite(&tmp, 1, 1, dst);
					index++;
					fwrite(src + iold, 127, 1, dst);
					index += 127;
					iold += 127;
					cnt -= 127;
				}
				if (cnt)
				{
					fwrite(&cnt, 1, 1, dst);
					index++;
					fwrite(src + iold, cnt, 1, dst);
					index += cnt;
				}
				cnt = 1;
				iii--;
			}
			else cnt++;
			break;
		case 1 :
			if (src[iii] != src[iii + 1])
			{
				same = 0;
				iold = iii + 1;
				while (cnt > 127)
				{
					tmp = (src[iii] << 8) + (127 | 0x80);
					fwrite(&tmp, 2, 1, dst);
					index += 2;
					cnt -= 127;
				}
				if (cnt)
				{
					tmp = (src[iii] << 8) + (cnt | 0x80);
					fwrite(&tmp, 2, 1, dst);
					index += 2;
				}
				cnt = 1;
			}
			else cnt++;
			break;
		}
	}
	if (cnt == 1 && same) cnt++;
	if (same == 0)
	{
		while (cnt > 127)
		{
			tmp = 127;
			fwrite(&tmp, 1, 1, dst);
			index++;
			fwrite(src + iold, 127, 1, dst);
			index += 127;
			iold += 127;
			cnt -= 127;
		}
		if (cnt)
		{
			fwrite(&cnt, 1, 1, dst);
			index++;
			fwrite(src + iold, cnt, 1, dst);
			index += cnt;
		}
	}
	else
	{
		while (cnt > 127)
		{
			tmp = (src[iii] << 8) + (127 | 0x80);
			fwrite(&tmp, 2, 1, dst);
			index += 2;
			cnt -= 127;
		}
		if (cnt)
		{
			tmp = (src[iii] << 8) + (cnt | 0x80);
			fwrite(&tmp, 2, 1, dst);
			index += 2;
		}
	}
	return(index);
} /* folder */

void unfolder(BYTE *dst, FILE *src, INT len_src) { // from File to Memory;
	INT iii, index;
	INT cnt, tmp;
	
	index = 0;
	tmp = 0;
	for (iii = 0; iii < len_src; iii++)
	{
		fread(&tmp, 1, 1, src);
		if (tmp > 127)
		{
			cnt = tmp & 0x7f;
			iii++;
			fread(&tmp, 1, 1, src);
			memset(dst + index, tmp, cnt);
			index += cnt;
		}
		else
		{
			cnt = tmp;
			fread(dst + index, cnt, 1, src);
			iii += cnt;
			index += cnt;
		}
	} // for (iii);
} /* unfolder */

INT strcmp2(TCHAR *s1, TCHAR *s2) { // No Case-Sensitive;
	TCHAR ch1, ch2;
	INT len;
	
	len = min(strlen(s1), strlen(s2));
	
	while (len)
	{
		ch1 = *s1++;
		ch2 = *s2++;
		
		if (toupper(ch1) > toupper(ch2)) return(1);
		if (toupper(ch1) < toupper(ch2)) return(-1);
		
		len--;
	} // while;
	
	if (*s1 == 0 && *s2 == 0) return(0);
	if (*s2 == 0) return(1);
	return(-1);
} /* strcmp2 */



INT copyStrB2W(TCHAR *s1, USHORT *w1)
{
	
	INT len = 0;
	
	while (*s1)
	{
		if (*s1 & 0x80)
		{
			*w1++ = ((USHORT *)s1)[0];
			s1 += 2;
		}
		else
		{
			*w1++ = *s1++;
		}
		
		len++;
	} // while;
	
	*w1 = 0;
	
	return(len);
} /* copyStrB2W */

INT strstrW(TCHAR *s1, TCHAR *s2, INT dir)
{
	TCHAR *src, *dest;
	INT slen, dlen;
	INT iii, jjj;
	USHORT src_w[512], dest_w[512], *wptr;
	
	if (dir == 'BI')
	{
		if (strlen(s1) > strlen(s2))
		{
			src = s1;
			dest = s2;
		}
		else
		{
			src = s2;
			dest = s1;
		}
	}
	else
	{
		src = s1;
		dest = s2;
	}
	
	slen = copyStrB2W(src, src_w);
	dlen = copyStrB2W(dest, dest_w);
	
	wptr = src_w;
	
	iii = slen;
	while (iii)
	{
		for (jjj = 0; jjj < dlen; jjj++)
		{
			if (wptr[jjj] != dest_w[jjj]) break;
		} // for (jjj);
		
		if (jjj >= dlen) return(1);
		
		if (iii <= dlen) return(0);
		
		wptr++;
		iii--;
	} // while;
	
	return(0);
} /* strstrW */

//============================================================================
//   Interrupt Call
//============================================================================

//============================================================================
//   Memory Function
//============================================================================
void *RAMalloc(DWORD size)
{
#if AFTER // ������� �� ���� �޸� �Ҵ����� ���� ��� �� ��;
	void *bptr;
	
	size += sizeof(DWORD);
	bptr = VirtualAlloc(NULL, size, MEM_COMMIT, PAGE_READWRITE);
	if (bptr == NULL)
	{
		return(NULL);
	}
	VirtualLock(bptr, size);
	((DWORD *)bptr)[0] = size;
	bptr = (void *)(((BYTE *)bptr) + sizeof(DWORD));
	return(bptr);
#endif
	return(malloc(size));
} /* RAMalloc */

void RAMfree(void *bptr)
{
#if AFTER
	DWORD size;
	
	bptr = (void *)(((BYTE *)bptr) - sizeof(DWORD));
	size = ((DWORD *)bptr)[0];
	VirtualUnlock(bptr, size);
	VirtualFree(bptr, 0, MEM_RELEASE); // flag�� MEM_DECOMMIT�� ���� �Ҵ�� �޸𸮰� ������ �� �ǰ� ���� �ְ� �ȴ�!;
#endif
	free(bptr);
} /* RAMfree */



UINT getdrest(TCHAR ch)
{
	static TCHAR *drv_path = "?:\\";
	DWORD SpC,	 // Sectors per Cluster;
		BpS,	 // Bytes per Sector;
		NuFC, // Number of Free Cluster;
		TNuC, // Total Number of Cluster;
		avail;
	
	drv_path[0] = ch;
	if (GetDiskFreeSpace(drv_path, &SpC, &BpS, &NuFC, &TNuC) == FALSE) avail = 0;
	else avail = SpC * BpS * NuFC;
	return(avail);
} /* getdrest */

HANDLE fopen4w(LPSTR fnm, INT mode) { // fopen for windows;
	switch (mode)
	{
	case 'r' :
	case 'R' :
		return(CreateFile(fnm, GENERIC_READ, 0/*FILE_SHARE_READ*/, NULL, OPEN_EXISTING, /*FILE_FLAG_RANDOM_ACCESS | */FILE_ATTRIBUTE_ARCHIVE, 0));
	case 'w' :
	case 'W' :
		return(CreateFile(fnm, GENERIC_WRITE, 0/*FILE_SHARE_WRITE*/, NULL, CREATE_ALWAYS, /*FILE_FLAG_RANDOM_ACCESS | */FILE_ATTRIBUTE_ARCHIVE, 0));
	} // switch (mode);
	return(NULL);
} /* fopen4w */

UINT fread4w(HANDLE hFile, void *mptr, INT len)
{
	UINT read_len;
	
	if (ReadFile(hFile, mptr, len, (LPDWORD)&read_len, NULL) == FALSE) return(0);
	return(read_len);
} /* fread4w */

UINT fwrite4w(HANDLE hFile, void *mptr, INT len)
{
	UINT write_len;
	
	if (WriteFile(hFile, mptr, len, (LPDWORD)&write_len, NULL) == FALSE) return(0);
	return(write_len);
} /* fwrite4w */

TCHAR *fgets2(TCHAR *str, INT n, FILE *fft)
{
	if (fgets(str, n, fft) == NULL) return(NULL);
	if (strchr(str, '\n')) *strchr(str, '\n') = 0;
	if (strchr(str, '\r')) *strchr(str, '\r') = 0;
	return(str);
} /* fgets2 */

TCHAR *fgetsl(TCHAR *str, INT n, FILE *fft)
{
	TCHAR temp_str[80 + 2];
	
	if (fgets(str, n, fft) == NULL) return(NULL);
	if (strchr(str, '\n')) *strchr(str, '\n') = 0;
	else
	{
		if (strchr(str, '\r')) *strchr(str, '\r') = 0;
		else
		{
			do
			{
				fgets(temp_str, 80, fft);
			} while (strchr(temp_str, '\n') != NULL && strchr(temp_str, '\r') != NULL);
		}
	}
	return(str);
} /* fgetsl */

INT filecmp(TCHAR *fnm, TCHAR *fnm2) { // fnm, fnm2 file must be exist;
	HANDLE hFile;
	FILETIME ftm, ftm2;
	
	hFile = fopen4w((LPSTR)fnm, 'r');
	GetFileTime(hFile, NULL, NULL, &ftm);
	fclose4w(hFile);
	hFile = fopen4w((LPSTR)fnm2, 'r');
	GetFileTime(hFile, NULL, NULL, &ftm2);
	fclose4w(hFile);
	return((INT)CompareFileTime(&ftm, &ftm2));
} /* filecmp */

void filecpy(TCHAR *fnm2, TCHAR *fnm)
{
/* if (fnm == NULL) then copy NULL file to fnm2.
so, filecpy(fnm2, NULL) means delete fnm2 file;
	*/
	SetFileAttributes(fnm2, FILE_ATTRIBUTE_ARCHIVE);
	if (fnm) CopyFile(fnm, fnm2, FALSE);
	else DeleteFile(fnm2);
} /* filecpy */

void filecpy(TCHAR *fnm2, TCHAR *fnm, UINT attr)
{
/* if (fnm == NULL) then copy NULL file to fnm2.
so, filecpy(fnm2, NULL) means delete fnm2 file;
	*/
	SetFileAttributes(fnm2, FILE_ATTRIBUTE_ARCHIVE);
	if (fnm)
	{
		CopyFile(fnm, fnm2, FALSE);
		SetFileAttributes(fnm2, attr);
	}
	else DeleteFile(fnm2);
} /* filecpy */

//============================================================================
// Miscellaneous Function
//============================================================================


//----------------------------------------------------------------------------
// Rounding;
//----------------------------------------------------------------------------
double round(double val)
{
	if (fmod(val, 1.0) >= 0.5) val += 0.5;
	return(val);
} /* round */





//----------------------------------------------------------------------------
// Get CRC;
//----------------------------------------------------------------------------
USHORT crc_tbl0[] =
{
	0x0000, 0xC0C1, 0xC181, 0x0140, 0xC301, 0x03C0, 0x0280, 0xC241,
		0xC601, 0x06C0, 0x0780, 0xC741, 0x0500, 0xC5C1, 0xC481, 0x0440,
		0xCC01, 0x0CC0, 0x0D80, 0xCD41, 0x0F00, 0xCFC1, 0xCE81, 0x0E40,
		0x0A00, 0xCAC1, 0xCB81, 0x0B40, 0xC901, 0x09C0, 0x0880, 0xC841,
		0xD801, 0x18C0, 0x1980, 0xD941, 0x1B00, 0xDBC1, 0xDA81, 0x1A40,
		0x1E00, 0xDEC1, 0xDF81, 0x1F40, 0xDD01, 0x1DC0, 0x1C80, 0xDC41,
		0x1400, 0xD4C1, 0xD581, 0x1540, 0xD701, 0x17C0, 0x1680, 0xD641,
		0xD201, 0x12C0, 0x1380, 0xD341, 0x1100, 0xD1C1, 0xD081, 0x1040,
		0xF001, 0x30C0, 0x3180, 0xF141, 0x3300, 0xF3C1, 0xF281, 0x3240,
		0x3600, 0xF6C1, 0xF781, 0x3740, 0xF501, 0x35C0, 0x3480, 0xF441,
		0x3C00, 0xFCC1, 0xFD81, 0x3D40, 0xFF01, 0x3FC0, 0x3E80, 0xFE41,
		0xFA01, 0x3AC0, 0x3B80, 0xFB41, 0x3900, 0xF9C1, 0xF881, 0x3840,
		0x2800, 0xE8C1, 0xE981, 0x2940, 0xEB01, 0x2BC0, 0x2A80, 0xEA41,
		0xEE01, 0x2EC0, 0x2F80, 0xEF41, 0x2D00, 0xEDC1, 0xEC81, 0x2C40,
		0xE401, 0x24C0, 0x2580, 0xE541, 0x2700, 0xE7C1, 0xE681, 0x2640,
		0x2200, 0xE2C1, 0xE381, 0x2340, 0xE101, 0x21C0, 0x2080, 0xE041,
		0xA001, 0x60C0, 0x6180, 0xA141, 0x6300, 0xA3C1, 0xA281, 0x6240,
		0x6600, 0xA6C1, 0xA781, 0x6740, 0xA501, 0x65C0, 0x6480, 0xA441,
		0x6C00, 0xACC1, 0xAD81, 0x6D40, 0xAF01, 0x6FC0, 0x6E80, 0xAE41,
		0xAA01, 0x6AC0, 0x6B80, 0xAB41, 0x6900, 0xA9C1, 0xA881, 0x6840,
		0x7800, 0xB8C1, 0xB981, 0x7940, 0xBB01, 0x7BC0, 0x7A80, 0xBA41,
		0xBE01, 0x7EC0, 0x7F80, 0xBF41, 0x7D00, 0xBDC1, 0xBC81, 0x7C40,
		0xB401, 0x74C0, 0x7580, 0xB541, 0x7700, 0xB7C1, 0xB681, 0x7640,
		0x7200, 0xB2C1, 0xB381, 0x7340, 0xB101, 0x71C0, 0x7080, 0xB041,
		0x5000, 0x90C1, 0x9181, 0x5140, 0x9301, 0x53C0, 0x5280, 0x9241,
		0x9601, 0x56C0, 0x5780, 0x9741, 0x5500, 0x95C1, 0x9481, 0x5440,
		0x9C01, 0x5CC0, 0x5D80, 0x9D41, 0x5F00, 0x9FC1, 0x9E81, 0x5E40,
		0x5A00, 0x9AC1, 0x9B81, 0x5B40, 0x9901, 0x59C0, 0x5880, 0x9841,
		0x8801, 0x48C0, 0x4980, 0x8941, 0x4B00, 0x8BC1, 0x8A81, 0x4A40,
		0x4E00, 0x8EC1, 0x8F81, 0x4F40, 0x8D01, 0x4DC0, 0x4C80, 0x8C41,
		0x4400, 0x84C1, 0x8581, 0x4540, 0x8701, 0x47C0, 0x4680, 0x8641,
		0x8201, 0x42C0, 0x4380, 0x8341, 0x4100, 0x81C1, 0x8081, 0x4040
};
USHORT crc_tbl1[] =
{
	0x0000, 0xCC01,	0xD801,	0x1400,	0xF001,	0x3C00,	0x2800,	0xE401,
		0xA001,	0x6C00,	0x7800,	0xB401,	0x5000,	0x9C01,	0x8801,	0x4400
};

UINT getCRC(void *ptr, INT size, UINT crc)
{
	BYTE *bptr = (BYTE *)ptr;
	INT ch, iii;
	USHORT crc0 = 0xffff, crc1 = 0xffff;
	
	for (iii = -4; iii < size; iii++)
	{
		if (iii < 0)
		{
			ch = crc & 0xff;
			crc >>= 8;
		}
		else ch = *bptr++;
		crc0 = crc_tbl0[(BYTE)ch ^ (BYTE)crc0] ^ (BYTE)(crc0 >> 8);
		crc1 = crc_tbl1[(ch ^ crc1) & 0x0f] ^ (crc1 >> 4);
		crc1 = crc_tbl1[((ch >> 4) ^ crc1) & 0x0f] ^ (crc1 >> 4);
	} // for (iii);
	
	crc = (((UINT)crc0) << 16) | (UINT)crc1;
	return(crc);
} /* getCRC */
//----------------------------------------------------------------------------
// Get Next Line Pos.;
//----------------------------------------------------------------------------
void getNextLinePos(INT *x1, INT *y1, INT x2, INT y2, INT limit_pixel) { 
	INT iii, dx, dy, steps, dd, d1, d2, ax1, ax2, ay1, ay2;
	
	dx = abs(x2 - *x1);
	dy = abs(y2 - *y1);
	
	if (dx == 0 && dy == 0) return;
	
	if (limit_pixel <= 0) limit_pixel = 1;
	
	if (dx >= dy)
	{
		steps = dx + 1;
		dd = 2 * dy - dx;
		d1 = dy >> 1;
		d2 = (dy - dx) >> 1;
		ax1 = 1;
		ax2 = 1;
		ay1 = 0;
		ay2 = 1;
	}
	else
	{
		steps = dy + 1;
		dd = 2 * dx - dy;
		d1 = dx >> 1;
		d2 = (dx - dy) >> 1;
		ax1 = 0;
		ax2 = 1;
		ay1 = 1;
		ay2 = 1;
	}
	
	if (*x1 > x2)
	{
		ax1 = -ax1;
		ax2 = -ax2;
	}
	if (*y1 > y2)
	{
		ay1 = -ay1;
		ay2 = -ay2;
	}
	
	for (iii = 0; (iii < steps && iii < limit_pixel); iii++)
	{
		if (dd < 0)
		{
			dd += d1;
			*x1 += ax1;
			*y1 += ay1;
		}
		else
		{
			dd += d2;
			*x1 += ax2;
			*y1 += ay2;
		}
		
		if (*x1 == x2 && *y1 == y2) break;
	} // for (iii);
} /* getNextLinePos */


//============================================================================
// Fast Copy;
//============================================================================
//	FPU�������͸� �̿��� ������ ���ؼ� �ʿ��� ���ӵǴ� �޸�(���� ���� 16����Ʈ�� ���´ٴ� ����.. ==;
#define FPU_ALIGN	16 /* 8, 32 */
//	MMX�������͸� �̿��� ������ ���ؼ� �ʿ��� ���ӵǴ� �޸�(���� ���� 8 ����Ʈ�� ���´ٴ� ����.. ==;
#define MMX_ALIGN	8  /*16, 32 */	// 16����Ʈ�� ���� �Ǿ� �־��µ�.. �� �׷�����.. ������ �ƽô� ��
//	���� �ּ���..
// FPUȤ�� MMX �� Ư���� �����ڵ带 ����ϱ� ���� �ּ����� ���ĵ� ����Ʈ�� �̺��� ���� memcpy�� �������.
#define THIN_THRESHOLD 46
// CPU Ÿ��
static DWORD	gProcessorType;
static BOOL		gIsPentiumProcessor		= FALSE;		//	�̰� ��Ƽ���̴�.
static BOOL		gIsPentiumProProcessor	= FALSE;		//	�̰� ��Ƽ�� ���δ�..
static BOOL		gIsPentiumIIProcessor	= FALSE;		//	�̰� ��Ƽ�� II��.
static BOOL		gHasMMXTechnology		= FALSE;		//	�̰� MMX�� �ȴ�. �̰� �� �߿���..
static BOOL		gFloatingEmulation		= FALSE;		//	FPU!!?
static BOOL		gSupportsCPUID			= TRUE;			//	CPUID�� �����Ѵ�.
static TCHAR		*gCpuSignature			="Unknown CPU";	//	CPU�̸�..

// needed since CPUID isn't part of the VC++ 5.0 inline assembler
#define CPUID __asm _emit 0x0F __asm _emit 0xA2

static void *	fpucpy(void *pDest ,const void *pSrc,UINT size);
static void *	mmxcpy(void *pDest ,const void *pSrc,UINT size);
static DWORD	GetProcessorType(void);
static BOOL		CheckMMXTechnology(void);
static void		EnumerateProcessorType(void);



void
memset(WORD *dest,WORD value,UINT size)
{	UINT *dest32=(UINT *)dest;
UINT width=size;

__asm
{	mov edi, dword ptr [dest32]
mov	ax,value
ror	eax,16
mov	ax,value
mov	ecx,width
shr	ecx,1
rep	stosd
mov	 edx, width
test edx, 1
jne __makeworddata1
jmp	__endmakedata1

__makeworddata1:
stosw
__endmakedata1:
}
}

// --------------------------------------------------------------------------
// return values for GetProcessorType
//	Type (bits 13-12), Family (bits 11-8), Model (bits 7-4), Stepping (bits 3-0)
//
//	T = 00, F = 0101, M = 0001, for Pentium Processors (60, 66 MHz)
//	T = 00, F = 0101, M = 0010, for Pentium Processors (75, 90, 100, 120, 133, 150, 166, 200 MHz)
//	T = 00, F = 0101, M = 0100, for Pentium Processors with MMX technology
//
//	T = 00, F = 0110, M = 0001, for Pentium Pro Processor
//	T = 00, F = 0110, M = 0011, for Pentium II Processor

//
//	T = 00 for original OEM processor
//	T = 01 for Intel OverDrive Processor
//	T = 10 for dual processor
//	T = 11 is reserved
static DWORD GetProcessorType(void)
{	volatile DWORD retval;

__try 
{	_asm 
{	mov eax, 1		// set up CPUID to return processor version and features
//	0 = vendor string, 1 = version info, 2 = cache info
CPUID			// code bytes = 0fh,  0a2h
and eax, 03fffh	// type, family, model, stepping returned in eax
mov retval, eax
}
} __except(EXCEPTION_EXECUTE_HANDLER)
{	retval = 0;
}

return retval;
}

//
// VF - NOTE
//
//		Added the 'volatile' keyword to these Intel sources because
//		the compiler was clobbering retval in Release builds with Maximize Speed
//
static BOOL CheckMMXTechnology(void)
{	volatile BOOL retval = TRUE;
volatile DWORD RegEDX;

__try 
{	_asm 
{	mov eax, 1		// set up CPUID to return processor version and features
//	0 = vendor string, 1 = version info, 2 = cache info
CPUID           // code bytes = 0fh,  0a2h
mov RegEDX, edx	// features returned in edx
}
} __except(EXCEPTION_EXECUTE_HANDLER)
{
	retval = 0;
}

if (retval == 0)
{	gSupportsCPUID=FALSE;
return FALSE;        	// processor does not support CPUID
}

if (RegEDX & 0x800000) 		// bit 23 is set for MMX technology
{	__try { _asm emms } 	// try executing the MMX instruction "emms"
__except(EXCEPTION_EXECUTE_HANDLER) { retval = FALSE; }
return retval;
}
else return FALSE;        	// processor supports CPUID but does not support MMX technology

// if retval == 0 here, it means the processor has MMX technology but
// floating-point emulation is on; so MMX technology is unavailable
gFloatingEmulation=TRUE;

return retval;
}

//	CPU�� Ȯ���ϰ� ���μ����� ȯ��� �ɷ��� ������ ���� �������� �ʱ�ȭ�Ѵ�..
static void EnumerateProcessorType( void )
{	DWORD type, family, model, stepping, signature;

gProcessorType		= GetProcessorType();
gHasMMXTechnology	= CheckMMXTechnology();

type     = (gProcessorType>>12) & 0x3;
family   = (gProcessorType>>8)  & 0xf;
model    = (gProcessorType>>4)  & 0xf;
stepping =  gProcessorType      & 0xf;
signature=  gProcessorType      & 0x0ff0 ;

if (family == 5)
{	gIsPentiumProcessor = TRUE;
gCpuSignature="Intel Pentium";
}
else if (family == 6 && model == 1)
{	gIsPentiumProProcessor = TRUE;
gCpuSignature="Intel Pentium Pro";
}
else if (family == 6 && model == 3)
{	gIsPentiumIIProcessor = TRUE;
gCpuSignature="Intel Pentium II";
}
else
{	switch( signature )
{	case 0x0500: gCpuSignature="AMD K5 Model 0"; break;
case 0x0510: gCpuSignature="AMD K5 Model 1"; break;
case 0x0520: gCpuSignature="AMD K5 Model 2"; break;
case 0x0530: gCpuSignature="AMD K5 Model 3"; break;
case 0x0560: gCpuSignature="AMD K6"; break;
case 0x0400: gCpuSignature="AMD 486/Am5x86"; break;
}
}
}
//        void *  __cdecl memcpy(void *, const void *, size_t);

// fpu�� �̿��� 16����Ʈ ������ �Ѵ�. mmx 8����Ʈ ���� ������.. 
static void * fpucpy(void *pDest ,const void *pSrc,UINT size)
{	UINT	prebytes,qdwords,postbyte=size;

if( postbyte	>=	THIN_THRESHOLD )
{	prebytes	= (FPU_ALIGN-(((long)pDest)%FPU_ALIGN))%FPU_ALIGN;
if( prebytes>postbyte ) prebytes=postbyte;
postbyte	= postbyte-prebytes;
qdwords		= postbyte/16;
postbyte	= postbyte-qdwords*16;

__asm
{	MOV		ESI,[pSrc]
MOV		EDI,[pDest]

MOV		ECX,[prebytes]
JCXZ	QDWORDSTART
REP	MOVS	[EDI],[ESI]

QDWORDSTART:

MOV		ECX,[qdwords]
JCXZ	POSTBYTES

ALIGN 16
QDWORDLOOP:
FILD    QWORD PTR [ESI]        //	�̰� ���� �ƽôº� �� ���� �ּ���.. FPU �����ΰ�??
FILD    QWORD PTR [ESI+8]        
FXCH
FISTP   QWORD PTR [EDI]
FISTP   QWORD PTR [EDI+8]

ADD     ESI, 16
ADD     EDI, 16
LOOP	QDWORDLOOP

POSTBYTES:
MOV		ECX,[postbyte]
JCXZ	DONE
REP	MOVS	[EDI],[ESI]

DONE:
}
}
else	memcpy( pDest, pSrc, postbyte );

return NULL;
}

// MMX ������ �̿��� 8����Ʈ ������ �Ѵ�.
static void * mmxcpy(void *pDest ,const void *pSrc,UINT size)
{	UINT	prebytes,qdwords,postbyte=size;

if( postbyte	>=	THIN_THRESHOLD )
{	prebytes=(MMX_ALIGN-(((long)pDest)%MMX_ALIGN))%MMX_ALIGN;
if( prebytes>postbyte ) prebytes=postbyte;
postbyte	= postbyte-prebytes;
qdwords		= postbyte/8;
postbyte	= postbyte-qdwords*8;

__asm
{	MOV		ESI,[pSrc]
MOV		EDI,[pDest]

MOV		ECX,[prebytes]
JCXZ	QWORDSTART
REP	MOVS	[EDI],[ESI]

QWORDSTART:

MOV		ECX,[qdwords]
JCXZ	POSTBYTES

ALIGN 16
QWORDLOOP:
MOVQ    MM0,[ESI]
MOVQ    [EDI],MM0
ADD     ESI, 8
ADD     EDI, 8
LOOP	QWORDLOOP

POSTBYTES:
MOV		ECX,[postbyte]
JCXZ	DONE
REP	MOVS	[EDI],[ESI]

DONE:
}
}
else	memcpy( pDest, pSrc, postbyte );

__asm
{
	EMMS
}

return NULL;
}

BOOL
setFPUcpy()
{	fastcpy=fpucpy;
return TRUE;
}

BOOL
setMEMcpy()
{	fastcpy=memcpy;
return TRUE;
}

BOOL
setMMXcpy()
{	if (gHasMMXTechnology)	{fastcpy=mmxcpy;return TRUE;}
return FALSE;
}

void init_fastcpy(void)
{
	EnumerateProcessorType();
	if (!setMMXcpy()) setFPUcpy();
} /* init_fastcpy */


//----------------------------------------------------------------------------
// Get Direction;
// ::
//       (0)
//        | 
// (90) --+-- (270)
//        |
//      (180)
// - ���� ���� ���� �Լ��� ������ ���� Angle = (360 - 90 - getDirection());
// - �� ȸ�� ������ �ٲٷ��� Angle = (360 - getDirection()) % 360;
// - (x1, y1)�� (0, 0)���κ����� �����ǥ�� ���ؾ� �Ѵ�;
//----------------------------------------------------------------------------
INT getDirection(INT x1, INT y1)
{
	INT angle;
	
	if (x1 == 0)
	{
		if (y1 <= 0) return(0);
		else return(180);
	}
	if (y1 == 0)
	{
		if (x1 <= 0) return(90);
		else return(270);
	}
	
	angle = (INT)(360.0 * atan((double)y1 / (double)x1) / (2.0 * PI));
	if (x1 < 0) angle = 90 - angle;
	else angle = 270 - angle;
	
	return(angle);
} /* getDirection */

//----------------------------------------------------------------------------
// Get Circle Pos.;
// ::
// - [In]  (x1, y1)�� �߽� ��ǥ, r1 ������, a1 ����;
//   [Out] (x1, y1)�� ����� ��ǥ;
//----------------------------------------------------------------------------
void getCirclePos(INT r1, INT a1, INT &x1, INT &y1)
{
	double rad;
	
	a1 %= 360;
	rad = 2.0 * PI * (double)(360 - 90 - a1) / 360.0;
	x1 += (INT)((double)r1 * cos(rad));
	y1 += (INT)((double)r1 * sin(rad));
} /* getCirclePos */

//----------------------------------------------------------------------------
// Get Length;
//----------------------------------------------------------------------------
INT getLength(INT x1, INT y1, INT x2, INT y2)
{
	return((INT)sqrt((double)(x1 - x2) * (x1 - x2) + (double)(y1 - y2) * (y1 - y2)));
} /* getLength */

//----------------------------------------------------------------------------
// Get Clipping;
//----------------------------------------------------------------------------
INT getClipping(INT x1, INT y1, INT xw1, INT yw1, INT &x2, INT &y2, INT &xw2, INT &yw2)
{
	if (x2 < x1)
	{
		xw2 -= (x1 - x2);
		x2 = x1;
	}
	if (y2 < y1)
	{
		yw2 -= (y1 - y2);
		y2 = y1;
	}
	if (xw2 <= 0 || yw2 <= 0) return(0);
	
	if (x2 + xw2 - 1 > x1 + xw1 - 1) xw2 = x1 + xw1 - x2;
	if (y2 + yw2 - 1 > y1 + yw1 - 1) yw2 = y1 + yw1 - y2;
	if (xw2 <= 0 || yw2 <= 0) return(0);
	
	return(1);
} /* getClipping */