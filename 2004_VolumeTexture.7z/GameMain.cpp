// File: Main.cpp
//
#include "Common.h"

PDVB	m_pVB;
PDIB	m_pIB;
LPDIRECT3DVOLUMETEXTURE9 m_pVolumeTexture = NULL;

CCamera*	m_pCamera;					// Camera

DWORD	m_dwNumVertices;				// Vertex Total
DWORD	m_dwNumFaces;					// Index Total
INT		m_nMapSizeX;
INT		m_nMapSizeY;

// Name: CMain()
CMain::CMain()
{
	m_pInput		= NULL;					// input device
	m_pNetwork		= NULL;					// network
	m_pScene		= NULL;					// game play
	
	// data table
	m_pTblLcl		= NULL;					// Local table
	m_pTblMdl		= NULL;					// Model
	m_pTblTx		= NULL;					// Model
	m_pTblMap		= NULL;					// Height map
	m_pTblFnt		= NULL;
	m_pDbgstr		= NULL;
}


// Name: ~CMain()
CMain::~CMain()
{
}

// Name: OneTimeSceneInit()

HRESULT CMain::OneTimeSceneInit()
{
#define ONE_TIME_SCENE_INT(p, msg)						\
	if(FAILED(_SAFE_NEWINIT(p)))	{	SeUtil_ErrMsgBox(msg);	SendMessage( m_hWnd, WM_CLOSE, 0, 0 );	return -1;	}
	
	ONE_TIME_SCENE_INT(m_pNetwork	, "Network init failed"			);
	ONE_TIME_SCENE_INT(m_pDbgstr	, "Debug string init failed"	);
	ONE_TIME_SCENE_INT(m_pTblMdl	, "Model table init failed"		);
	ONE_TIME_SCENE_INT(m_pTblTx		, "Texture table init failed"	);
	ONE_TIME_SCENE_INT(m_pTblMap	, "Map table init failed"		);
	ONE_TIME_SCENE_INT(m_pTblLcl	, "Local table init failed"		);
	ONE_TIME_SCENE_INT(m_pTblFnt	, "Font table init failed"		);
	
#undef ONE_TIME_SCENE_INT
	
	
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	m_bLoadingApp = false;
	
	return S_OK;
}


// Name: Init()
// Rendering Models..
HRESULT CMain::Init()
{
	SAFE_NEWINIT(m_pInput	);
	
	//	SAFE_NEWINIT(m_pScene	);
	
	SAFE_NEWINIT(	m_pCamera	);
	SAFE_NEWINIT(	m_pTblFnt	);
	
	m_nMapSizeX			= 32;		//nTile in nLOCAL_X
	m_nMapSizeY			= 32;		//nTile in nLOCAL_Y

	// Create a volume texture
	D3DXIMAGE_INFO imageinfo;
    D3DXIMAGE_INFO imageinfo2;

	TCHAR sFile[] = "Texture/map.dds";
	
    if( FAILED( D3DXGetImageInfoFromFile( sFile, &imageinfo ) ) )
    {
        return -1;
    }


	HRESULT hr;

	if( FAILED(hr = D3DXCreateVolumeTextureFromFileEx( m_pd3dDevice, sFile, 
            imageinfo.Width, imageinfo.Height, imageinfo.Depth, imageinfo.MipLevels,
            0, imageinfo.Format, D3DPOOL_MANAGED, D3DX_FILTER_TRIANGLE, D3DX_FILTER_TRIANGLE,
            0x00ffffff, &imageinfo2, NULL, (LPDIRECT3DVOLUMETEXTURE9*)&m_pVolumeTexture ) ) )
    {
		switch(hr)
		{
		case D3DERR_NOTAVAILABLE:
			break;
		case D3DERR_OUTOFVIDEOMEMORY:
			break;
		case D3DERR_INVALIDCALL:
			break;
		case D3DXERR_INVALIDDATA:
			break;
		case E_OUTOFMEMORY:
			break;
		}

        return -1;
    }

	int i, j;
	
	
	VtxDUVW	*pVB;
	WORD		*pIB;
	m_dwNumVertices = 33 * 33;
	m_dwNumFaces =  32 * 32 * 2;
	GDEVICE->CreateVertexBuffer(m_dwNumVertices * sizeof(VtxDUVW), 0, FVF_VTXDUVW, D3DPOOL_MANAGED, &m_pVB, NULL);
	GDEVICE->CreateIndexBuffer(m_dwNumFaces * 3 * sizeof(WORD), 0, D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pIB, 0);
	
	
	m_pVB->Lock(0, 0, (void**)&pVB, 0);
	for (j = 0; j < 33; j++)
	{
		for (i = 0; i < 33; i++)
		{
			int idx = j * 33 + i;
			pVB[idx].p = VEC(i * 32, 0, j * 32);
			pVB[idx].d = 0xFFFFFFFF;
			
			pVB[idx].u = i / 2.f;
			pVB[idx].v = j / 2.f;

			FLOAT w = sinf( D3DXToRadian (rand()%360));
			pVB[idx].w = (2.5f+w)/imageinfo.Depth;

//			if(i<8)
//				pVB[idx].w = .5f/imageinfo.Depth;//
//			else if( i<16)
//				pVB[idx].w = 1.5f/imageinfo.Depth;
//
//			else if( i<24)
//				pVB[idx].w = 2.5f/imageinfo.Depth;
//
//			else 
//				pVB[idx].w = 3.5f/imageinfo.Depth;		//			(i/16) +1    32.f) ;/// imageinfo.Depth;//FLOAT(2+rand()%(imageinfo.Depth -2) - 0.5f) / imageinfo.Depth;
//
//			if(i ==16 && j==16)
//				pVB[idx].w = 2.5f/imageinfo.Depth;
		}
	}
	m_pVB->Unlock();
	
	m_pIB->Lock(0, 0, (void**)&pIB, 0);
	for (i = 0; i < 32; i++)
	{
		for (j = 0; j < 32; j++)
		{
			
			int idx = i * 32 + j;
			
			pIB[idx * 6 + 0] = i * 33 + j;
			pIB[idx * 6 + 1] = (i + 1) * 33 + j;
			pIB[idx * 6 + 2] = (i + 1) * 33 + j + 1;
			
			pIB[idx * 6 + 3] = pIB[idx * 6 + 2];
			pIB[idx * 6 + 4] = i * 33 + j + 1;
			pIB[idx * 6 + 5] = pIB[idx * 6 + 0];
		}
	}
	
	m_pIB->Unlock();
	
	return S_OK;
}


// Name: Delete()
HRESULT CMain::Destroy()
{
	SAFE_RELEASE(m_pVolumeTexture);
	SAFE_RELEASE(m_pVB);
	SAFE_RELEASE(m_pIB);
	SAFE_DESTROY(m_pInput);
	SAFE_DESTROY(m_pNetwork);
	SAFE_DESTROY(m_pScene);
	
	SAFE_DELETE(m_pTblMdl	);
	SAFE_DELETE(m_pTblTx	);
	SAFE_DELETE(m_pTblLcl	);
	SAFE_DELETE(m_pTblMap	);
	SAFE_DELETE(m_pTblFnt	);
	
	if(m_hDC)
		m_pd3dSurface->ReleaseDC(m_hDC);
	
	SAFE_RELEASE(m_pd3dSurface);
	
	return S_OK;
}



// Name: FinalCleanup()
HRESULT CMain::FinalCleanup()
{
	SAFE_DELETE(m_pInput	);
	SAFE_DELETE(m_pNetwork	);
	SAFE_DELETE(m_pScene	);
	SAFE_DELETE(m_pDbgstr	);
	return S_OK;
}






// Name: Restore()
HRESULT CMain::Restore()
{
	SAFE_RESTORE(	m_pScene	);
	SAFE_RESTORE(	m_pTblFnt	);
	

	D3DDISPLAYMODE d3ddm;
	
	if( FAILED( GMAIN->m_pD3D->GetAdapterDisplayMode( D3DADAPTER_DEFAULT, &d3ddm ) ) )
		return E_FAIL;
	
	GDEVICE->SetRenderState( D3DRS_LIGHTING, FALSE );
	
	
	return S_OK;
}




// Name: Invalidate()
HRESULT CMain::Invalidate()
{
	SAFE_INVALIDATE(	m_pScene	);
	SAFE_INVALIDATE(	m_pTblFnt	);
	
	
	return S_OK;
}



// Name: FrameMove()
HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pNetwork	);
	SAFE_FRAMEMOVE(	m_pScene	);
	
	SAFE_FRAMEMOVE(	m_pCamera	);
	
//	GET_KEY(DIK_SPACE)
//	{
//		if(GetTextureFilter())
//			SetTextureFilter(false);
//		else
//			SetTextureFilter(true);
//	}
	
	return S_OK;
}


// Name: Render()
HRESULT CMain::Render()
{
	
	TCHAR szMsg[MAX_PATH] = TEXT("");
	memset(szMsg, 0, sizeof(szMsg));
	
	strcpy( szMsg, m_sDeviceStats );	strcat(szMsg, "  ");	strcat( szMsg, m_sFrameStats);
	strcat( szMsg, TEXT("    Game Play"));
	
	GDEVICE->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0x00000000, 1.f, 0L );
	
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;
	
	// Rendering Scene
	SAFE_RENDER(m_pScene);
	
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
//	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
//	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
//	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);
//	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSW, D3DTADDRESS_MIRROR);


	GDEVICE->SetIndices(m_pIB);
	GDEVICE->SetFVF(FVF_VTXDUVW);
	
	m_pd3dDevice->SetTexture( 0, m_pVolumeTexture );
	GDEVICE->SetStreamSource(0, m_pVB, 0, sizeof(VtxDUVW));
	GDEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_dwNumVertices, 0, m_dwNumFaces);

	RECT rt;
	rt.left  = 5;
	rt.top   = 15;
	rt.right = rt.left + 900;
	rt.bottom= rt.top  + 20;
	
	if(TBLFNT->m_pDXF)
		TBLFNT->m_pDXF[2]->DrawText( szMsg, -1, &rt, 0, D3DCOLOR_XRGB( 255, 255, 0));

	GDEVICE->EndScene();
	
	return S_OK;
}



void SetTextureFilter(bool xisTextureFilter)
{
	if(xisTextureFilter)
	{
		GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	}
	else
	{
		GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
	}
}