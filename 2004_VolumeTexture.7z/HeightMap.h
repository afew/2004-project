///////////////////////////////////////////////////////////////////////////////
// File: HeightMap.h
// Desc: Rendering Height map...
//		 interface for the CTblHeightMap class.
// Date: 2003-04-18, Author: SR OnLine
// History: 

#ifndef _HEIGHTMAP_H_
#define _HEIGHTMAP_H_

class CHeight
{
public:
	// frame move data
	INT		m_nIdxGridX;		// index of X tile
	INT		m_nIdxGridZ;		// index of Z tile
	VEC		m_vecPickPos;		// MousePosition to 3D
	VEC		m_vecPickRegion[4];	// Picking world

public:
	INT		m_nCntLine;			// Line count
	VtxD*	m_pLineGrid;		// grid..
	PDVB 	m_pVBGrid;			// grid vertex buffer...
	

public:
	PDVB 	m_pVBAxis;			// Axis vertex buffer.
	VtxD	m_LineAxis[6];		// Axis
	
public:
	PDVB 	m_pVBPick;			// picking vertex buffer.
	VtxD	m_LinePick[5];		// picking region
	VEC		m_vecDelta[5];		// delta...
	

public:
	CHeight();
	virtual ~CHeight();

	INT		Init();
	VOID	Destroy();

	INT		Restore();
	VOID	Invalidate();

	INT		FrameMove();
	
	VOID	Render();

	VEC		GetPickPos();
};

#endif