// TblTexture.h: interface for the CTblTexture class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _TBLTEXTURE_H_
#define _TBLTEXTURE_H_

class CTblTexture  
{
public:
	typedef struct tagSTblTexSub
	{
		INT			m_nIdxSub;			// Attribute
		TCHAR		m_szTexFile[512];	// Texture Name
		PDTX		m_pTex;				// Game model
		
		tagSTblTexSub()
			: m_nIdxSub(-1)
			, m_pTex(NULL)
		{
			memset(&m_szTexFile, 0, sizeof(TCHAR)* 512 );
		}

		~tagSTblTexSub()
		{
			SAFE_RELEASE(m_pTex);
		}

	}STblTexSub, * PSTblTexSub;

	typedef struct tagSTblTexMst
	{
		INT			m_nIdxMst;			// Texture master index
		INT			m_iNumTexSub;		// Number of Texture
		PSTblTexSub	m_pTblTexSub;
		
		tagSTblTexMst()
			: m_iNumTexSub(-1)			// ��������
			, m_pTblTexSub(NULL)		// ������ �־� ������ �߻���Ŵ.
		{
			
		}

		~tagSTblTexMst()
		{
			SAFE_DELETE_ARRAY(m_pTblTexSub);
		}
		
	}STblTexMst, * PSTblTexMst;

	// Index table
	typedef struct tagSTblMstIdx
	{
		INT			m_nIdxMst;			// Texture master index
		TCHAR		m_szTexName[256];	// Texture Name

		tagSTblMstIdx()
			: m_nIdxMst(-1)
		{
			memset(&m_szTexName, 0, sizeof(TCHAR)* 256);
		}
	}STblMstIdx, * PSTblMstIdx;


public:
	TCHAR		m_szVersion[32];		// version
	INT			m_iNumTextureClass;		// Texture class Number
	PSTblMstIdx	m_pTblTexIdx;			// Texture index table
	PSTblTexMst	m_pTblTexMst;			// Texture table
	
public:
	CTblTexture();
	virtual ~CTblTexture();
	
	INT		Init();
	INT		Load(TCHAR *pcFileName);
	VOID	Destroy();

	INT		TextureCreate (INT nMst, INT nSub, DWORD dwColor=0);
	PDTX	TextureSelect (INT nMst, INT nSub);
	INT		TextureRelease(INT nMst, INT nSub);
	
private:
	VOID Confirm();
};

#endif
