// Implementation of the CMcMap class.
//
//////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

D3DLIGHT9 m_light;

CMcMap::CMcMap()
{
	m_pVB	= NULL;
}

CMcMap::~CMcMap()
{
}


INT		CMcMap::InitDeviceObjects()
{
	m_fW	= .2f;
	
	m_vcI	= -VEC3(1, 0, 1) * 1.f;
	
	HRESULT hr;
	// Create the vertex buffer
	if( FAILED( hr = GDEVICE->CreateVertexBuffer( 32* 32 * 3 * 2 * sizeof(VtxN)
		, 0
		, FVF_VTXN
		, D3DPOOL_MANAGED
		, &m_pVB
		, NULL ) ) )
		
		return DXTRACE_ERR( "CreateVertexBuffer", hr );

	INT	nIdx;
	
	VEC3	p0;
	VEC3	p1;
	VEC3	p2;
	VEC3	p3;

	VEC3	n = VEC3(0,1,0);

	
	VtxN* pVtx = (VtxN* )malloc( 32* 32 * 3 * 2 * sizeof(VtxN) );

	for(int j=0; j<32; ++j)
	{
		for(int i=0; i<32; ++i)
		{
			nIdx = j * 32 + i;
			
			p0 = m_vcI + VEC3( i+0.f, 0.f, j+0.f) * m_fW;
			p1 = m_vcI + VEC3( i+0.f, 0.f, j+1.f) * m_fW;
			p2 = m_vcI + VEC3( i+1.f, 0.f, j+0.f) * m_fW;
			p3 = m_vcI + VEC3( i+1.f, 0.f, j+1.f) * m_fW;
			
			pVtx[nIdx *6 + 0] = VtxN( p0, n);
			pVtx[nIdx *6 + 1] = VtxN( p1, n);
			pVtx[nIdx *6 + 2] = VtxN( p2, n);
			pVtx[nIdx *6 + 3] = VtxN( p3, n);
			
			pVtx[nIdx *6 + 4] = pVtx[nIdx *6 + 2];
			pVtx[nIdx *6 + 5] = pVtx[nIdx *6 + 1];
		}
	}
	
	
	
	
	
	
	
	
	void *p;

	if( FAILED( hr = m_pVB->Lock( 0, 0, &p, 0 ) ) )
		return DXTRACE_ERR( "Lock", hr );
	
	memcpy(p, pVtx, 32* 32 * 3 * 2 * sizeof(VtxN));
	m_pVB->Unlock();

	free (pVtx);
	
	
	return 1;
}
void	CMcMap::RestoreDeviceObjects()
{
}

INT		CMcMap::InvalidateDeviceObjects()
{
	return 1;
}

void	CMcMap::DeleteDeviceObjects()
{
	SAFE_RELEASE(	m_pVB	);
}

INT		CMcMap::FrameMove()
{
	return 1;
}

void	CMcMap::Render()
{
	GDEVICE->SetRenderState( D3DRS_FILLMODE,  D3DFILL_WIREFRAME);
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
	GDEVICE->SetRenderState( D3DRS_CULLMODE,  D3DCULL_NONE);
	
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetFVF(FVF_VTXN);
	GDEVICE->SetStreamSource(0, m_pVB, 0, sizeof(VtxN));
	GDEVICE->DrawPrimitive(D3DPT_TRIANGLELIST, 0, 32 * 32 * 2);
}