// McScene.cpp: implementation of the CMcScene class.
//
//////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

// Construction/Destruction

CMcScene::CMcScene()
{
	m_pVbLine	= NULL;
	m_pMap		= NULL;
	m_pFnt	= NULL;
}

CMcScene::~CMcScene()
{
	
}



INT		CMcScene::InitDeviceObjects()
{
	// TODO: create device objects
	HRESULT hr;

	if(FAILED(hr = GDEVICE->CreateVertexBuffer( 6 * 2 * sizeof(VtxD)
						, 0
						, FVF_VTXD
						, D3DPOOL_MANAGED
						, &m_pVbLine
						, NULL)))
						return hr;

	void * pVtx;

	FLOAT fMax = 10000;

	if(FAILED(hr = m_pVbLine->Lock(0,0, &pVtx, 0)))
		return hr;

	((VtxD*)pVtx)[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	((VtxD*)pVtx)[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	((VtxD*)pVtx)[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	((VtxD*)pVtx)[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);

	((VtxD*)pVtx)[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	((VtxD*)pVtx)[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	((VtxD*)pVtx)[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	((VtxD*)pVtx)[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);

	((VtxD*)pVtx)[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	((VtxD*)pVtx)[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	((VtxD*)pVtx)[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	((VtxD*)pVtx)[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);

	m_pVbLine->Unlock();



	if(NULL == m_pMap)
	{
		m_pMap = new CMcMap();
		m_pMap->InitDeviceObjects();
	}

	if(NULL == m_pFnt)
	{
		m_pFnt = new CMcFont2D[59];

		for(int i=0; i<59; ++i)
		{
			(m_pFnt +i )->SetString("����ȭ ���� �Ǿ����ϴ�.ABCDEFGHI abcdef 12 345 ����ȭ ���� �Ǿ����ϴ�.����ȭ ���� �Ǿ����ϴ�.����ȭ ���� �Ǿ����ϴ�.����ȭ ���� �Ǿ����ϴ�.����ȭ ���� �Ǿ����ϴ�.����ȭ");
			(m_pFnt +i )->SetPos( VEC2(0, i*13.f));
		}
	}

	
	return 1;
}


void	CMcScene::RestoreDeviceObjects()
{
	SAFE_RESTORE(	m_pMap	);
}

INT		CMcScene::InvalidateDeviceObjects()
{
	SAFE_INVALIDATE(	m_pMap	);

	return 1;
}

void	CMcScene::DeleteDeviceObjects()
{
	SAFE_DESTROY(	m_pMap	);
	SAFE_DELETE(	m_pMap	);

	SAFE_RELEASE(	m_pVbLine	);
	SAFE_DELETE_ARRAY(	m_pFnt	);
}

INT		CMcScene::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pMap	);

	static int cnt =0;
	static DWORD dwS = timeGetTime();

	DWORD dwE	= timeGetTime();

	if(dwE > (dwS+400) )
	{
		dwS = dwE;
		
		++cnt;

//		McUtil_SetWindowTitle("%d", cnt);
//		DWORD color = RGB( rand()%256, rand()%256 , rand()%256);


		for(int i=0;i<59; ++i)
		{
//			(m_pFnt +i )->SetColorFrnt(color);
		}
		

	}


	return 1;
}

void	CMcScene::Render()
{
	// Render triangle
//	SAFE_RENDER(	m_pMap	);

	if(	m_pFnt	)
	{
		for(int i=0; i<59; ++i)
			(m_pFnt +i )->DrawTxt();
		
	}

	RenderXYZ();
}


void CMcScene::RenderXYZ()
{
	GDEVICE->SetTransform( D3DTS_WORLD, &GMAIN->matWorld );
	// Render Lines
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
	
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetFVF(FVF_VTXD);
	GDEVICE->SetStreamSource(0, m_pVbLine, 0, sizeof(VtxD));
	GDEVICE->DrawPrimitive(D3DPT_LINELIST, 0, 6);
}