#ifndef _MCVTXFORMAT_H_
#define _MCVTXFORMAT_H_

#define D3DFVF_CUSTOMVERTEX (D3DFVF_XYZ|D3DFVF_NORMAL)
#define FVF_VTXD			(D3DFVF_XYZ|D3DFVF_DIFFUSE)
#define FVF_VTXN			(D3DFVF_XYZ|D3DFVF_NORMAL)



// Custom D3D vertex format used by the vertex buffer
typedef struct tagVtxDUV
{
    VEC3	p;																	// vertex position
    DWORD	d;																	// diffuse
	FLOAT	u, v;																	// uv

	tagVtxDUV(){}
	tagVtxDUV(VEC3 P,FLOAT U,FLOAT V,DWORD D=0xFFFFFFFF){	p=P; u=U; v=V;d=D;							}
	tagVtxDUV(FLOAT X,FLOAT Y,FLOAT Z
			,FLOAT U, FLOAT V,DWORD D=0xFFFFFFFF)		{	p.x=X;p.y=Y;p.z=Z;u=U;v=V;d=D;				}
}VtxDUV;


typedef struct tagVtxN
{
    VEC3	p;																	// vertex position
    VEC3	n;																	// diffuse

	tagVtxN(){}
	tagVtxN(VEC3 P,VEC3 N)								{	p=P; n=N;									}
}VtxN;



typedef struct tagVtxD
{
	VEC3	p;
	DWORD	d;
	
	tagVtxD()											{	p.x=p.y=p.z = 0.f;		d = 0xffffffff;		}
	tagVtxD(VEC3 P, DWORD D)							{	p = P;					d= D;				}
	tagVtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D=0xFFFFFFFF)	{	p.x = X;	p.y = Y;	p.z = Z;	d = D;	}
}VtxD;

#endif