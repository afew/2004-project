#ifndef __STDAFX_H_
#define __STDAFX_H_

#pragma once

#define STRICT
#include <windows.h>
#include <commctrl.h>
#include <commdlg.h>
#include <basetsd.h>
#include <math.h>
#include <stdio.h>
#include <d3dx9.h>
#include <dxerr9.h>
#include <tchar.h>
#include "DXUtil.h"
#include "D3DEnum.h"
#include "D3DSettings.h"
#include "D3DApp.h"
#include "D3DFile.h"
#include "D3DUtil.h"
#include "resource.h"

#include "CommonType.h"

#define GMAIN		g_pApp
#define GHWND		g_pApp->m_hWnd
#define GDEVICE		g_pApp->m_pd3dDevice
#define GSURFACE	g_pApp->m_pd3dSf
#define GSPRITE		g_pApp->m_pd3dSprite

#include "McVtxformat.h"
#include "McUtil.h"

#include "McFont2D.h"
#include "McMap.h"
#include "McScene.h"

#include "Mackerel.h"

extern CMyD3DApplication* g_pApp;
extern HINSTANCE          g_hInst;

#endif