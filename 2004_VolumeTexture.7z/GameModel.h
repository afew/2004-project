///////////////////////////////////////////////////////////////////////////////
// GameModel.h: interface for the GameModel class.
// Explain:
// Date : 2003-04-18, Author: SR OnLine
// History:

#ifndef _GAMEMODEL_H_
#define _GAMEMODEL_H_

#define SRMODEL_VERSION ("SROnline")
#define SRMODEL_BUILD_NUM (7)

typedef struct tagPhysique
{
	INT iNumBlendedNodes;
	INT* piBlendedBoneID;
	FLOAT* pfWeights;

	tagPhysique()
	{
		iNumBlendedNodes = 0;
		piBlendedBoneID = NULL;
		pfWeights = NULL;
	}

	~tagPhysique()
	{
		iNumBlendedNodes = 0;

		if ( piBlendedBoneID != NULL )
			delete[] (piBlendedBoneID);

		if ( pfWeights != NULL )
			delete[] (pfWeights);		
	}
} PHYSIQUE, *PPHYSIQUE; 

typedef struct tagGeom
{
	TCHAR Name[32];

	INT iNumVertices;
	VtxNUV* pVertices;
	VtxNUV* pAnimVertices;

	INT iNumFaces;
	WORD* pIndices;

	INT iNumPhysique;
	PPHYSIQUE pPhysique;
	
	D3DMATERIAL9 mtrl;
	TCHAR* pTexturePath;
	LPDIRECT3DTEXTURE9 pTexture;

	// Test
	LPDIRECT3DVERTEXBUFFER9 pVertexBuffer;
	LPDIRECT3DINDEXBUFFER9 pIndexBuffer;

	tagGeom()
	{
		ZeroMemory(Name, sizeof(Name));

		iNumVertices = 0;
		pVertices = NULL;
		pAnimVertices = NULL;

		iNumFaces = 0;
		pIndices = NULL;

		iNumPhysique = 0;
		pPhysique = NULL;

		pTexturePath = NULL;
		pTexture = NULL;

		D3DUtil_InitMaterial(mtrl, 1.0f, 1.0f, 1.0f, 0.0f);

		pVertexBuffer = NULL;
		pIndexBuffer = NULL;
	}
	~tagGeom()
	{
		SAFE_DELETE_ARRAY(pVertices);
		SAFE_DELETE_ARRAY(pAnimVertices);
		SAFE_DELETE_ARRAY(pIndices);
		SAFE_DELETE_ARRAY(pPhysique);
		SAFE_DELETE_ARRAY(pTexturePath);

		SAFE_RELEASE(pTexture);
		SAFE_RELEASE(pVertexBuffer);
		SAFE_RELEASE(pIndexBuffer);
	}
} GEOM;

typedef struct tagTransKey
{
//	INT iMilliTime;
	VEC v;
	tagTransKey()
	{
//		iMilliTime = 0;
		ZeroMemory(&v, sizeof(VEC));
	}
} TRANSLATIONKEY;
typedef struct tagRotKey
{
//	INT iMilliTime;
	QAT qt;
	tagRotKey()
	{
//		iMilliTime = 0;
		D3DXQuaternionIdentity(&qt);
	}
} ROTATIONKEY;

typedef struct tagBone
{
	TCHAR Name[32];

	INT iParentID;

	INT iNumChildren;
	INT* pChildIDs;

	MAT matLocalScale;

	INT iNumTransKeys;
	TRANSLATIONKEY* pTransKeys;
	
	INT iNumRotKeys;
	ROTATIONKEY* pRotKeys;

	// animation matrix
	MAT matAni;
	MAT matResult;
	MAT matInverse;

	tagBone()
	{
		ZeroMemory(Name, sizeof(TCHAR)*32);
		iParentID = -1;
		iNumChildren = 0;
		iNumTransKeys = 0;
		iNumRotKeys = 0;

		D3DXMatrixIdentity(&matAni);
		D3DXMatrixIdentity(&matResult);
		D3DXMatrixIdentity(&matInverse);
	}

	~tagBone()
	{
		SAFE_DELETE_ARRAY(pChildIDs);
		SAFE_DELETE_ARRAY(pTransKeys);
		SAFE_DELETE_ARRAY(pRotKeys);
	}
} BONE;

typedef struct tagAnimInfo
{
	INT iStartFrame;
	INT iEndFrame;
	INT iFrameRate;
	INT iTotalKeys;
} ANIMINFO;





typedef struct tagSObjAni
{
	bool	m_bRender;
	INT		m_iCurrentFrame;
	DWORD	m_dwLastTime;
	FLOAT	m_fInterpolation;
	FLOAT	m_fAnimSpeed;
	INT		m_iCurrentAnim;
	
	DWORD	m_dwCurTime;

	tagSObjAni()
		: m_bRender(true)
		, m_iCurrentFrame(0)
		, m_dwLastTime(0)
		, m_fInterpolation(0.0f)
		, m_fAnimSpeed(1.0f)
		, m_iCurrentAnim(0)
		, m_dwCurTime(0)
	{
		m_dwLastTime = timeGetTime();
	}
}SObjAni, *PSObjAni;



class CGameModel  : public CGameObject
{
public:
	INT			m_iNumGeoms;
	GEOM	*	m_pGeom;	
	INT			m_iNumBones;
	BONE	*	m_pBone;
	INT			m_iNumAnims;
	ANIMINFO*	m_pAnims;

	MAT			m_Mat;

	
public:
	CGameModel();
	virtual ~CGameModel();
		
	INT Init();
	VOID Destroy();
	
	INT Restore();
	VOID Invalidate();
	
	VOID Render();
	
	INT Load(TCHAR* pszFileName);
	
	INT UpdateAnimation(SObjAni * pAni);
	INT UpdateVertex();
	
	VOID SetAnimation(INT & iAnimNum);

private:
	VOID CreateVertexBuffer();
	VOID BuildAnimTree(BONE *pBone, MAT& matOld);
	VOID MatrixMulByFloat(MAT& matTarget, MAT& mat, FLOAT f);
};

#endif
