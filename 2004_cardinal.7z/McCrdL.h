// Interface for the CMcCrdL class.
// Cardinal , Hermit & Bezier curve
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCCRDL_H_
#define _MCCRDL_H_

typedef vector<VEC3>	lsPos;
typedef lsPos::iterator	itPos;


class CMcCrdL
{
public:
	INT		iN		;															// Points Number
	VEC3*	pCrv	;															// for Curve
	lsPos	vPt		;															// Points
	FLOAT	fT		;															// Tension
	FLOAT	fS		;															// Step
	MAT		mtCd	;															// cardinal Matrix


public:																			// for rendering
	bool	bC		;															// Circle?
	INT		iNx		;															// total Points Max
	INT		iC		;															// current vertex
	VtxD*	pVtx	;
	PXMS	pMsh	;
	

public:
	CMcCrdL();
	~CMcCrdL();

	INT		Init();
	void	Destroy();
	INT		FrameMove();
	void	Render();

public:
	INT		VtxUp();															// Vertex Update
	INT		CurveUp();															// Slope Update

	void	PointAdd(VEC3);														// Point add


};

#endif _MCCRDL_H_
