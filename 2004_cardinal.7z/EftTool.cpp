// Implementation of the CMain class.
//
//////////////////////////////////////////////////////////////////////

#include "SeCommon.h"

CMain::CMain()
:	m_pInput	(0)
,	m_pCamera	(0)

,	m_pLine		(0)
,	m_pDXFt		(0)
,	m_pGrid		(0)
,	m_dwFl		(3)
,	m_bFld		(1)

,	m_nTxm		(-1)
,	m_nTxs		(-1)

,	m_pCrd		(0)
{
}


CMain::~CMain()
{
}


HRESULT CMain::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	m_bLoadingApp = FALSE;
	
	return S_OK;
}

HRESULT CMain::InitDeviceObjects()
{
	XYZInit();
	SAFE_NEWINIT(	m_pInput	);
	SAFE_NEWINIT(	m_pCamera	);
	SAFE_NEWINIT(	m_pGrid		);

	SAFE_NEWINIT(	m_pCrd		);

	return S_OK;
}


HRESULT CMain::RestoreDeviceObjects()
{
	HRESULT hr=-1;
	
	HFONT hFont = CreateFont( 14, 0, 0, 0, FW_BOLD, FALSE, FALSE, FALSE, ANSI_CHARSET, OUT_DEFAULT_PRECIS, CLIP_DEFAULT_PRECIS,	ANTIALIASED_QUALITY, FF_DONTCARE, "Arial" );
	
	if( FAILED( hr = D3DXCreateFont( m_pd3dDevice, hFont, &m_pDXFt ) ) )
		return DXTRACE_ERR( "D3DXCreateFont", hr );

	DeleteObject(hFont);

	SAFE_RESTORE(	m_pCamera	);


	return S_OK;
}


HRESULT CMain::FrameMove()
{
	memset(m_sMsg, 0, sizeof(m_sMsg));
	lstrcpy( m_sMsg, m_strDeviceStats );
	lstrcat( m_sMsg, " ");
	lstrcat( m_sMsg, m_strFrameStats	);

	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCamera	);

	SAFE_FRAMEMOVE(	m_pCrd		);
	
	return S_OK;
}


HRESULT CMain::Render()
{
	m_pd3dDevice->Clear( 0L, NULL, m_dwClr, 0x0000688A, 1.0f, 0L );	
	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, m_dwFl);
	m_pd3dDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, FALSE);

	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
	{

		SAFE_RENDER(	m_pGrid	);
		SAFE_RENDER(	m_pCrd		);

		GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
		XYZRender();

		m_pd3dDevice->EndScene();
	}

	m_pd3dDevice->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);

	if( SUCCEEDED( m_pd3dDevice->BeginScene() ) )
	{
		RECT rt;
		rt.left   = 2;
		rt.right  = m_d3dsdBackBuffer.Width - 20;
		rt.top = 10;
		rt.bottom = rt.top + 20;

		m_pDXFt->Begin();
		m_pDXFt->DrawText( m_sMsg, -1, &rt, 0, D3DCOLOR_ARGB(255,255,255,0));
		m_pDXFt->End();

		m_pd3dDevice->EndScene();
	}

	return S_OK;
}


HRESULT CMain::InvalidateDeviceObjects()
{
	SAFE_RELEASE( m_pDXFt );

	return S_OK;
}



HRESULT CMain::DeleteDeviceObjects()
{
	INT i=0;

	XYZDestroy();

	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamera	);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pCrd		);

	return S_OK;
}



void CMain::XYZInit()
{
	INT		i;
	INT		j;
	FLOAT	fMax;
	INT		iSize;

	fMax = 10000;
	m_pLine = (VtxD*)malloc( (6 + 16 + 16 + 4 + 4 + 4) * 2 * sizeof(VtxD));

	iSize = _msize(m_pLine)/sizeof(VtxD);

	m_pLine[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pLine[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pLine[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pLine[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pLine[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pLine[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);

	j =6 * 2;

	for(i=0; i<8; ++i)
	{
		m_pLine[j + 8*i +0 ] = VtxD(-128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +1 ] = VtxD( 128, 1,  16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +2 ] = VtxD(-128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +3 ] = VtxD( 128, 1, -16* (i+1), (i%2)? 0xFF999999 : 0xFF666666);

		m_pLine[j + 8*i +4 ] = VtxD( 16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +5 ] = VtxD( 16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +6 ] = VtxD(-16* (i+1), 1,-128, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +7 ] = VtxD(-16* (i+1), 1, 128, (i%2)? 0xFF999999 : 0xFF666666);
	}


	j =6*2 + 16* 2 * 2 + 4*2*0;
	for(i=0; i<4; ++i)
	{
		m_pLine[j + i*2+0] = VtxD( 0,0,0, 0xAAAA8888);
		m_pLine[j + i*2+1] = 
		VtxD( fMax* cosf(DEGtoRAD(45 + i*90)),     0,     fMax* sinf(DEGtoRAD(45 + i*90)), 0xAAAA8888);
	}


	j =6*2 + 16* 2 * 2 + 4*2*1;
	for(i=0; i<4; ++i)
	{
		m_pLine[j + i*2+0] = VtxD( 0,0,0, 0xAA88AA88);
		m_pLine[j + i*2+1] = 
			VtxD( fMax* cosf(DEGtoRAD(45 + i*90)),     fMax* sinf(DEGtoRAD(45 + i*90)), 0 , 0xAA88AA88);
	}

	j =6*2 + 16* 2 * 2 + 4*2*2;
	for(i=0; i<4; ++i)
	{
		m_pLine[j + i*2+0] = VtxD( 0,0,0, 0xAA8888AA);
		m_pLine[j + i*2+1] = 
			VtxD( 0,   fMax* sinf(DEGtoRAD(45 + i*90)),       fMax* sinf(DEGtoRAD(45 + i*90)), 0xAA8888AA);
	}

}


void CMain::XYZDestroy()
{
	SAFE_FREE(		m_pLine		);
}

void CMain::XYZRender()
{
	// Render Lines
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
	
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetFVF(FVF_VTXD);
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6 + 32 + 4*0, m_pLine, sizeof(VtxD));
}