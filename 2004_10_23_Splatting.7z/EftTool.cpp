// Implementation of the CMain class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"


CMain::CMain()
:	m_pInput	(0)
,	m_pCamera	(0)

,	m_pLine		(0)
,	m_pDXFt		(0)
,	m_pGrid		(0)
,	m_pSlat		(0)
,	m_pSlt		(0)
,	m_bSpt		(0)
,	m_dwFl		(3)
,	m_bFld		(1)
{
	
}


CMain::~CMain()
{
}


HRESULT CMain::OneTimeSceneInit()
{
	SendMessage( m_hWnd, WM_PAINT, 0, 0 );
	m_bLoadingApp = FALSE;
	
	return S_OK;
}


HRESULT CMain::InitDeviceObjects()
{
	int		i;

	XYZInit();
	SAFE_NEWINIT(	m_pInput	);
	SAFE_NEWINIT(	m_pCamera	);
	SAFE_NEWINIT(	m_pGrid		);
	SAFE_NEWINIT(	m_pSlat		);
	
	m_pVtx1[8] = VtxD( 0.f, 50.f,  0.f, 0x00000000);
	m_pVtx2[8] = VtxD( 0.f, 50.f,  0.f, 0x00000000);

	for(i=0; i<8; ++i)
	{
		m_pVtx1[i].p = D3DXVECTOR3( 30.f * cosf(DEGtoRAD(360.f * i / 8)), 60.f * 1.f + 50.f, 30.f * sinf(DEGtoRAD(360.f * i / 8) ) );
		m_pVtx1[i].d = D3DXCOLOR( rand()%6 * 0.1f, rand()%6 * 0.1f, rand()%6 * 0.1f, 1.f);

		m_pVtx2[i].p = D3DXVECTOR3( 50.f * cosf(DEGtoRAD(360.f * i / 8)), 40.f * 1.f + 50.f, 50.f * sinf(DEGtoRAD(360.f * i / 8) ) );
		m_pVtx2[i].d = D3DXCOLOR( rand()%6 * 0.1f, rand()%6 * 0.1f, rand()%6 * 0.1f, 1.f);
	}
	
	for(i=0; i<8; ++i)
		m_pIdx[i] = VtxIdx(8, (i+1)%8, (i+2)%8 );


	SAFE_NEWINIT(	m_pSlt	);

	return S_OK;
}


HRESULT CMain::RestoreDeviceObjects()
{
	HRESULT hr=-1;

	if( FAILED( hr = D3DXCreateFont( GDEVICE, 16, 0, FW_BOLD, 0, FALSE, HANGEUL_CHARSET, OUT_DEFAULT_PRECIS, ANTIALIASED_QUALITY, FF_DONTCARE, "Arial", &m_pDXFt ) ) )
		return DXTRACE_ERR( "D3DXCreateFont", hr );
	

	SAFE_RESTORE(	m_pCamera	);
	SAFE_RESTORE(	m_pSlat		);
	
	return S_OK;
}


HRESULT CMain::FrameMove()
{
	SAFE_FRAMEMOVE(	m_pInput	);
	SAFE_FRAMEMOVE(	m_pCamera	);
	SAFE_FRAMEMOVE(	m_pSlat		);
	SAFE_FRAMEMOVE(	m_pSlt		);

	if(GINPUT->GetKey(DIK_F1))
		m_bSpt ^=1;

	if(m_bSpt)
	{
		sprintf( m_sMsg, "%s %s Alpha Map Splatting", m_strDeviceStats, m_strFrameStats	);
	}
	else
	{
		sprintf( m_sMsg, "%s %s Diffuse Splatting", m_strDeviceStats, m_strFrameStats	);
	}

	return S_OK;
}




HRESULT CMain::Render()
{	
	D3DXMATRIX		mtW;
	D3DXMatrixIdentity(&mtW);
	
	GDEVICE->SetTransform(D3DTS_VIEW, &GCAMERA->GetViewMatrix());
	
	
	GDEVICE->Clear( 0L, NULL, m_dwClr, 0x00006688, 1.0f, 0L );
	GDEVICE->Clear( 0L, NULL, m_dwClr, 0x00000000, 1.0f, 0L );
	GDEVICE->SetRenderState(D3DRS_FILLMODE, m_dwFl);

	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);
	
	
	if( FAILED( GDEVICE->BeginScene() ) )
		return -1;
	
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetRenderState( D3DRS_ZWRITEENABLE, TRUE );
	GDEVICE->SetRenderState(D3DRS_LIGHTING, FALSE);
	XYZRender();

	if(m_bSpt)
	{
		SAFE_RENDER(	m_pSlat	);
	}
	else
	{
		SAFE_RENDER(	m_pSlt	);
	}

	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	
	
	RECT rt;
	rt.left   = 2;
	rt.right  = m_d3dsdBackBuffer.Width - 20;
	rt.top = 10;
	rt.bottom = rt.top + 20;
	
	m_pDXFt->DrawText(NULL, m_sMsg, -1, &rt, 0, D3DCOLOR_ARGB(255,255,255,0));
	
	GDEVICE->EndScene();
	
	
	return S_OK;
}


HRESULT CMain::InvalidateDeviceObjects()
{
	SAFE_RELEASE	(	m_pDXFt );
	SAFE_INVALIDATE	(	m_pSlat	);

	return S_OK;
}



HRESULT CMain::DeleteDeviceObjects()
{
	INT i=0;
	
	XYZDestroy();
	SAFE_DELETE(	m_pInput	);
	SAFE_DELETE(	m_pCamera	);
	SAFE_DELETE(	m_pGrid		);

	SAFE_DELETE(	m_pSlat		);
	SAFE_DELETE(	m_pSlt		);

	return S_OK;
}



void CMain::XYZInit()
{
	INT		i;
	INT		j;
	FLOAT	fMax;
	
	fMax = 10000;
	m_pLine = (VtxD*)malloc( (6 + 8*4 ) * 2 * sizeof(VtxD));
	
	m_pLine[ 0] = VtxD(-fMax,     0,     0, 0xFFFF0000);
	m_pLine[ 1] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 2] = VtxD(    0,     0,     0, 0xFFFF0000);
	m_pLine[ 3] = VtxD( fMax,     0,     0, 0xFFFF0000);
	
	m_pLine[ 4] = VtxD(    0, -fMax,     0, 0xFF00FF00);
	m_pLine[ 5] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 6] = VtxD(    0,     0,     0, 0xFF00FF00);
	m_pLine[ 7] = VtxD(    0,  fMax,     0, 0xFF00FF00);
	
	m_pLine[ 8] = VtxD(    0,     0, -fMax, 0xFF0000FF);
	m_pLine[ 9] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[10] = VtxD(    0,     0,     0, 0xFF0000FF);
	m_pLine[11] = VtxD(    0,     0,  fMax, 0xFF0000FF);
	
	j =6 * 2;
	
	for(i=0; i<8; ++i)
	{
		m_pLine[j + 8*i +0 ] = VtxD(-128.0F, 1.0F,  16.0F* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +1 ] = VtxD( 128.0F, 1.0F,  16.0F* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +2 ] = VtxD(-128.0F, 1.0F, -16.0F* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +3 ] = VtxD( 128.0F, 1.0F, -16.0F* (i+1), (i%2)? 0xFF999999 : 0xFF666666);
		
		m_pLine[j + 8*i +4 ] = VtxD( 16.0F* (i+1), 1.0F,-128.0F, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +5 ] = VtxD( 16.0F* (i+1), 1.0F, 128.0F, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +6 ] = VtxD(-16.0F* (i+1), 1.0F,-128.0F, (i%2)? 0xFF999999 : 0xFF666666);
		m_pLine[j + 8*i +7 ] = VtxD(-16.0F* (i+1), 1.0F, 128.0F, (i%2)? 0xFF999999 : 0xFF666666);
	}
	
}


void CMain::XYZDestroy()
{
	SAFE_FREE(		m_pLine		);
}

void CMain::XYZRender()
{
	// Render Lines
	GDEVICE->SetRenderState( D3DRS_LIGHTING,  FALSE);
//	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,  FALSE);
//	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE,  FALSE);
	
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetFVF(FVF_VTXD);
	
	GDEVICE->DrawPrimitiveUP(D3DPT_LINELIST, 6 + 32, m_pLine, sizeof(VtxD));
}