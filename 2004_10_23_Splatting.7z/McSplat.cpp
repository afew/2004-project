// Implementation of the CMcSplat class.
//
////////////////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"



CMcSplat::CMcSplat()
{
	
}

CMcSplat::~CMcSplat()
{
	Destroy();
}



INT CMcSplat::Init()
{
	m_nMapSizeX			= 32;		//nTile in nLOCAL_X
	m_nMapSizeY			= 32;		//nTile in nLOCAL_Y
	m_nChunkTileSize	= 32;		//nTILE in One Chunk
	m_nAlphaPixelSize	= 32;		//nTILE * 2
	m_nTileTextureNum	= 4;		//Number of Tile Set
	
	int i, j;
	
	m_ppMapTileTextureIndex = new BYTE*[m_nMapSizeY];
	
	for (i = 0; i < m_nMapSizeY; ++i)
	{
		m_ppMapTileTextureIndex[i] = new BYTE[m_nMapSizeX];
	}
	
	
	//Create Tile Texture (���Ǵ� Tile�� ��� Upload�Ѵ�);
	m_pBaseTexture = new LPDIRECT3DTEXTURE9[m_nTileTextureNum];
	
	for (i = 0; i < m_nTileTextureNum; ++i)
	{
		D3DXCreateTextureFromFile(GDEVICE, McUtil_Forming("Texture/Base_%02d.png", i + 1), &m_pBaseTexture[i]);
	}
	
	VtxTerrain	*pVB;
	WORD		*pIB;
	m_dwNumVertices = 33 * 33;
	m_dwNumFaces =  32 * 32 * 2;
	GDEVICE->CreateVertexBuffer(m_dwNumVertices * sizeof(VtxTerrain), 0, D3DFVF_VTXTERRAIN, D3DPOOL_MANAGED, &m_pVB, NULL);
	GDEVICE->CreateIndexBuffer(m_dwNumFaces * 3 * sizeof(WORD), 0, D3DFMT_INDEX16, D3DPOOL_MANAGED, &m_pIB, 0);
	
	
	m_pVB->Lock(0, 0, (void**)&pVB, 0);
	for (i = 0; i < 33; ++i)
	{
		for (j = 0; j < 33; ++j)
		{
			int idx = i * 33 + j;
			pVB[idx].p = D3DXVECTOR3(j * 32, 0, i * 32);
			pVB[idx].n = D3DXVECTOR3(0, 1, 0);
			pVB[idx].d = 0x00FFFFFF;
			
			pVB[idx].u1 = j / 8.f;
			pVB[idx].u2 = j / 32.f;
			
			pVB[idx].v1 = i / 8.f;
			pVB[idx].v2 = i / 32.f;
		}
	}

	m_pVB->Unlock();
	
	m_pIB->Lock(0, 0, (void**)&pIB, 0);
	for (i = 0; i < 32; ++i)
	{
		for (j = 0; j < 32; ++j)
		{
			int idx = i * 32 + j;
			
			pIB[idx * 6 + 0] = i * 33 + j;
			pIB[idx * 6 + 1] = (i + 1) * 33 + j;
			pIB[idx * 6 + 2] = (i + 1) * 33 + j + 1;
			
			pIB[idx * 6 + 3] = pIB[idx * 6 + 2];
			pIB[idx * 6 + 4] = i * 33 + j + 1;
			pIB[idx * 6 + 5] = pIB[idx * 6 + 0];
		}
	}

	m_pIB->Unlock();
	
	
	//Create Alpha Texture (m_nTotalChunk * m_nTileTextureNum)
	m_nChunkNumX  = (int)(m_nMapSizeX / m_nChunkTileSize);	//nChunk_X
	m_nChunkNumY  = (int)(m_nMapSizeY / m_nChunkTileSize);	//nChunk_Y
	m_nTotalChunk = m_nChunkNumX * m_nChunkNumY;			//nTotal_Chunk
	
	if (m_nTotalChunk)
	{
		m_ppPerChunkAlphaTexture = new LPDIRECT3DTEXTURE9* [m_nTotalChunk];
		
		for (i = 0; i < m_nTotalChunk; ++i)
		{
			//�� ûũ���� Ÿ�ϼ� �� ��ŭ ���� �ؽ��� �Ҵ�
			m_ppPerChunkAlphaTexture[i] = new LPDIRECT3DTEXTURE9[m_nTileTextureNum];
			
			for (j = 0; j < m_nTileTextureNum ; ++j )
			{
				//���ĸ� �����.
				D3DXCreateTexture( GDEVICE ,m_nAlphaPixelSize ,m_nAlphaPixelSize,
					1, 0, D3DFMT_A4R4G4B4, D3DPOOL_MANAGED, &m_ppPerChunkAlphaTexture[i][j]);
			}
		}
	}
	
	//SetTileByPic(forming("%s\\lightmap.tga", exe_path));
	SetTectureMapTileArray();
	CalculateMap();
	
	return 1;
}

void CMcSplat::Destroy()
{
	INT		i, j;

	SAFE_RELEASE(m_pIB);
	SAFE_RELEASE(m_pVB);

	for (i=0; i<m_nMapSizeY; ++i)
		SAFE_DELETE_ARRAY(	m_ppMapTileTextureIndex[i]	);
	
	SAFE_DELETE_ARRAY(	m_ppMapTileTextureIndex	);


	for (i = 0; i < m_nTileTextureNum; ++i)
		SAFE_RELEASE(	m_pBaseTexture[i]);

	SAFE_DELETE_ARRAY(	m_pBaseTexture	);

	for (i = 0; i < m_nTotalChunk; ++i)
	{
		//�� ûũ���� Ÿ�ϼ� �� ��ŭ ���� �ؽ��� �Ҵ�
		
		
		for (j = 0; j < m_nTileTextureNum ; ++j )
		{
			//���ĸ� �����.
			SAFE_RELEASE(	m_ppPerChunkAlphaTexture[i][j]	);
		}

		SAFE_DELETE_ARRAY(	m_ppPerChunkAlphaTexture[i]	);
	}

	SAFE_DELETE_ARRAY(	m_ppPerChunkAlphaTexture);
}



INT CMcSplat::Restore()
{
	return 1;
}


void CMcSplat::Invalidate()
{
}

INT CMcSplat::FrameMove()
{
	if(GINPUT->GetKey(DIK_SPACE))
	{
		if(GetTextureFilter())
			SetTextureFilter(false);
		else
			SetTextureFilter(true);
	}

	return 1;
}

void CMcSplat::Render()
{
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE,   TRUE );
	GDEVICE->SetRenderState( D3DRS_SRCBLEND,  D3DBLEND_SRCALPHA );
	GDEVICE->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
	
	GDEVICE->SetTextureStageState( 1, D3DTSS_COLOROP,   D3DTOP_SELECTARG1);
	GDEVICE->SetTextureStageState( 1, D3DTSS_COLORARG1, D3DTA_CURRENT );
	
	GDEVICE->SetTextureStageState( 1, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	GDEVICE->SetTextureStageState( 1, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	
	GDEVICE->SetIndices(m_pIB);
	GDEVICE->SetFVF(D3DFVF_VTXTERRAIN);

	D3DXMATRIX	mtW;

	D3DXMatrixIdentity(&mtW);
	mtW._41 = -512.f;
	mtW._43 = -512.f;

	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);

	for (int yy = 0; yy < m_nChunkNumY; yy++ )
	{
		for (int xx = 0; xx < m_nChunkNumX; xx++)
		{
			//for (i = 0; i <= 3; ++i)
			for (int i = 0; i < m_nTileTextureNum; ++i)
			{
				GDEVICE->SetTexture(0, m_pBaseTexture[i]);
				GDEVICE->SetTexture(1, m_ppPerChunkAlphaTexture[yy * xx][i]);
				GDEVICE->SetStreamSource(0, m_pVB, 0, sizeof(VtxTerrain));
				GDEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, m_dwNumVertices, 0, m_dwNumFaces);
			}
		}
	}

	mtW._41 = 0.f;
	mtW._43 = 0.f;

	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);

	GDEVICE->SetTexture(0, 0);
	GDEVICE->SetTexture(1, 0);
}







//////////////////////////////////////////////////////////////////////////////////////
void CMcSplat::CalculateMap()
{
	int i, j;
	
	//ûũ Ÿ�� ���� ��ŭ
	for (i = 0; i < m_nTotalChunk; ++i )
	{
		//�ؽ��� ���� ��ŭ
		for (j = 0; j < m_nTileTextureNum; ++j )
		{
			if (j == 0)	//0���� ��Chunk�� Base Tile�� ���� Alpha Value�� Skip�ϵ��� �Ѵ�;
				CalculateMapTile(i, j + 1, m_ppPerChunkAlphaTexture[i][j], true);
			else
				CalculateMapTile(i, j + 1, m_ppPerChunkAlphaTexture[i][j]);
		}
	}
}

void CMcSplat::CalculateMapTile(int xnChunkTileNum, int xnTexNum, LPDIRECT3DTEXTURE9 xpTexAlpha, bool bflag)
{
	int	yy, xx, i, j;
	int	nIndexFormChunkX, nIndexFormChunkY;
	
	//���� ûũ�� X , Y ��ǥ
	int nChunkMapX = (xnChunkTileNum % m_nChunkNumY) * m_nChunkTileSize;
	int nChunkMapY = (xnChunkTileNum / m_nChunkNumY) * m_nChunkTileSize;
	
	int nTileX, nTileY, nTileComTileX, nTileComTileY;
	
	int nTilePerPixel = (int)(m_nAlphaPixelSize / m_nChunkTileSize);
	
	float		fPixelX , fPixelY;
	D3DXVECTOR2 v2PixelXY;
	
	float fWeight, fAlpha;
	float fTexWeight;
	
	bool is;
	
	D3DLOCKED_RECT d3dlr;
	xpTexAlpha->LockRect( 0, &d3dlr, 0, 0 );
	BYTE* pDstRow;
	pDstRow = (BYTE*)d3dlr.pBits;
	//BYTE *pPrc;
	WORD *pPrc;
	
	
	for (yy = 0; yy < m_nAlphaPixelSize; yy++)
	{
		
		pPrc = (WORD*)pDstRow;
		//pPrc = pDstRow;
		
		for (xx = 0; xx < m_nAlphaPixelSize; xx++)
		{
			
			if (bflag)
			{
				fAlpha = 1.0f;
			}

			else
			{
				//ûũ�ȿ����� Ÿ�� �ε��� = (Y ��ǥ / Ÿ�ϴ� �ȼ�) * ûũ�� Ÿ�� ���� + (X ��ǥ / Ÿ�ϴ� �ȼ� )
				//nIndexFormChunk = (yy / nTilePerPixel) * m_nChunkTileSize + (xx / nTilePerPixel);
				
				nIndexFormChunkX = xx / nTilePerPixel;
				nIndexFormChunkY = yy / nTilePerPixel;
				
				//�ȼ��� �÷�Ʈ ��ǥ
				fPixelX = (xx % nTilePerPixel) / nTilePerPixel - 0.5f;
				fPixelY = (yy % nTilePerPixel) / nTilePerPixel - 0.5f;
				
				nTileX = nIndexFormChunkX + nChunkMapX;
				nTileY = nIndexFormChunkY + nChunkMapY;
				
				//�ڽ� Ÿ���� ������ ������ Ÿ�� ������ŭ
				//3 X 3 
				fWeight = 0.0f;
				for (i = -1; i < 2; ++i)
				{
					for (j  = -1; j < 2; ++j)
					{
						nTileComTileX = nTileX + j;
						nTileComTileY = nTileY + i;
						
						if (nTileComTileX >= m_nMapSizeX )
							nTileComTileX = -1;

						if (nTileComTileY >= m_nMapSizeY )
							nTileComTileY = -1;
						
						//if (nTileComTileX < 0 || nTileComTileY < 0)
						//{
						//	fWeight += 1.0f;
						//}
						
						//���� ���ϴ� Ÿ���̰ų�
						//�����̸�
						
						is = false;
						if (nTileComTileX < 0 || nTileComTileY < 0)
						{
							//is = true;
							is = false;
						}
						
						else
						{
							if (m_ppMapTileTextureIndex[nTileComTileY][nTileComTileX] == xnTexNum)
								is = true;
						}
						
						//if (m_ppTileMap[nTileComTileY][nTileComTileX].nTextureNum == xnTexNum || (nTileComTileX < 0 || nTileComTileY < 0)) {
						if (is)
						{
							v2PixelXY.x = fPixelX - j;
							v2PixelXY.y = fPixelY - i;
							
							//fWeight += 1 - D3DXVec2LengthSq( &v2PixelXY ) / 1.75 ^ 2;
							//fTexWeight = 1 - D3DXVec2LengthSq( &v2PixelXY ) / 3.0f;
							//�Ÿ��� ���� 0 ~ 1 �� ��
							fTexWeight = (2.0f - D3DXVec2Length (&v2PixelXY)) / 2.0f;
							
							//�߰� ����?
							
							//����
							fWeight += fTexWeight;
						}
					} //for(j);
				} //for(i)
				
				//7 �� ������.
				//������ 8�� Ÿ���� �ִ� ���⵵(0.75 * 8) + ���� Ÿ��( 1 ) = 7
				fAlpha = fWeight / 2;
				
				if( fAlpha > 1.0f )
					fAlpha = 1.0f;

				if( fAlpha < 0.0f)
					fAlpha = 0.0f;
			}
			
			//���� ����
			//*pPrc = (0xffff * fAlpha);
			*pPrc = ( (BYTE)(0xF * fAlpha) << 12 );
			//*pPrc = ((0xFFFFFFFF * fAlpha) );
			
			//*pPrc = 0xaf00;
			pPrc += 1;
			
		} //for (xx);
		
		pDstRow += d3dlr.Pitch;
	} //for (yy);
	
	xpTexAlpha->UnlockRect(0);
}


void CMcSplat::SetTileByPic(TCHAR *xszFileName)
{
	LPDIRECT3DTEXTURE9 lpTex;
	
	D3DXCreateTextureFromFile(GDEVICE , xszFileName , &lpTex);
	
	D3DSURFACE_DESC Desc;
	
	lpTex->GetLevelDesc( 0 ,&Desc );
	
	
	D3DLOCKED_RECT d3dlr;
	lpTex->LockRect( 0, &d3dlr, 0, 0 );
	BYTE* pD,*pSrc;
	pD = (BYTE*)d3dlr.pBits;
	
	int		x,y;
	int		TexX , TexY;
	int		a,r,g,b;
	float	fWei;
	BYTE	t;
	
	int maxV = 1;
	
	for ( y = 0 ; y < Desc.Height ; y++ )
	{
		for( x = 0 ; x < Desc.Width ; x++ )
		{
			pSrc = pD + ( y * d3dlr.Pitch ) + (x * 4);
			
			a = *pSrc;pSrc++;
			r = *pSrc;pSrc++;
			g = *pSrc;pSrc++;
			b = *pSrc;pSrc++;
			
			if( maxV < (r+g+b))
			{
				maxV = (r+g+b);
			}
		}
	}
	
	
	
	for ( y = 0; y < m_nMapSizeY ; y++ )
	{
		TexY = ( (float)y / m_nMapSizeY ) * Desc.Height;

		for( x = 0 ; x < m_nMapSizeX ; x++ )
		{
			TexX = ((float)x / m_nMapSizeX ) * Desc.Width;
			
			pSrc = pD + ( TexY * d3dlr.Pitch ) + (TexX * 4);
			
			a = *pSrc;pSrc++;
			r = *pSrc;pSrc++;
			g = *pSrc;pSrc++;
			b = *pSrc;pSrc++;
			
			
			fWei = (float)(r+g+b) / maxV;
			
			t = 1;
			if( fWei < 0.6f )	t = 2;
			if( fWei < 0.3f )	t = 3;
			if( fWei < 0.25f )	t = 4;
			
			m_ppMapTileTextureIndex[y][x] = t;
		}
	}
	
	lpTex->Release();
}

int Data[] = 
	{
		2,2,2,4,4,2,2,2,4,2,4,4,2,2,2,2,2,2,2,4,4,2,2,2,4,2,4,4,2,2,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
		2,2,3,1,3,3,3,2,2,4,3,1,3,3,3,2,2,2,3,1,3,3,3,2,2,4,3,1,3,3,3,2,
		3,1,3,3,1,3,3,1,3,4,4,4,1,3,3,1,3,1,3,3,1,3,3,1,3,4,4,4,1,3,3,1,
		3,2,2,3,1,1,3,2,3,4,4,3,1,1,3,2,3,2,2,3,1,1,3,2,3,4,4,3,1,1,3,2,
		3,2,2,3,3,4,1,2,3,2,2,3,1,1,1,2,3,2,2,3,3,4,1,2,3,2,2,3,1,1,1,2,
		2,1,2,4,4,2,2,2,2,1,2,3,1,2,2,2,2,1,2,4,4,2,2,2,2,1,2,3,1,2,2,2,
		3,3,3,2,4,2,2,2,3,3,3,2,1,2,2,1,1,3,3,2,4,2,2,2,3,3,3,2,1,2,2,2,
		2,2,2,2,4,2,2,2,2,2,2,2,2,2,2,1,1,2,2,2,4,2,2,2,2,2,2,2,2,2,2,2,
		3,3,3,3,4,2,3,3,3,3,3,3,2,2,3,1,1,3,3,3,4,2,3,3,3,3,3,3,2,2,3,3,
		2,2,3,1,3,3,3,2,2,2,3,1,3,3,3,1,1,2,3,1,3,3,3,2,2,2,3,1,3,3,3,2,
		3,1,3,3,1,3,3,1,3,1,3,3,1,3,3,1,3,1,3,3,1,3,3,1,3,1,3,3,1,3,3,1,
		3,2,2,3,1,1,3,2,3,2,2,3,4,1,3,2,3,2,2,3,1,1,3,2,3,2,2,3,4,1,3,2,
		3,2,2,3,1,1,1,2,3,2,4,4,4,1,1,2,3,2,2,3,1,1,1,2,3,2,4,4,4,1,1,2,
		2,1,2,3,1,2,4,4,2,1,2,3,1,2,2,2,2,1,2,3,1,2,4,4,2,1,2,3,1,2,2,2,
		3,3,3,2,1,2,4,4,3,3,3,2,1,2,2,2,3,3,3,2,1,2,4,4,3,3,3,2,1,2,2,2,
		2,2,2,4,4,2,2,2,4,2,4,4,2,2,2,2,2,2,2,4,4,2,2,2,4,2,4,4,2,2,2,2,
		3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,3,
		2,2,3,1,3,3,3,2,2,4,3,1,3,3,3,2,2,2,3,1,3,3,3,2,2,4,3,1,3,3,3,2,
		3,1,3,3,1,3,3,1,3,4,4,4,1,3,3,1,3,1,3,3,1,3,3,1,3,4,4,4,1,3,3,1,
		3,2,2,3,1,1,3,2,3,4,4,3,1,1,3,2,3,2,2,3,1,1,3,2,3,4,4,3,1,1,3,2,
		3,2,2,3,3,4,1,2,3,2,2,3,1,1,1,2,3,2,2,3,3,4,1,2,3,2,2,3,1,1,1,2,
		2,1,2,4,4,2,2,2,1,1,2,3,1,2,2,2,2,1,2,4,4,2,2,2,2,1,2,3,1,2,2,2,
		3,3,3,2,4,2,2,2,1,3,3,2,1,2,2,2,3,3,3,2,4,2,2,2,3,3,3,2,1,2,2,2,
		2,2,2,2,4,2,2,2,1,2,2,2,2,2,2,2,2,2,2,2,4,2,2,2,2,2,2,2,2,2,2,2,
		3,3,3,3,4,2,1,1,1,3,3,3,2,2,3,3,3,3,3,3,4,2,3,3,3,3,3,3,2,2,3,3,
		2,2,3,1,3,3,1,1,1,2,3,1,3,3,3,2,2,2,3,1,3,3,3,2,2,2,3,1,3,3,3,2,
		3,1,3,3,1,3,1,1,1,1,3,3,1,3,3,1,3,1,3,3,1,3,3,1,3,1,3,3,1,3,3,1,
		3,2,2,3,1,1,1,2,3,2,2,3,4,1,3,2,3,2,2,3,1,1,3,2,3,2,2,3,4,1,3,2,
		3,2,2,3,1,1,1,2,3,2,4,4,4,1,1,2,3,2,2,3,1,1,1,2,3,2,4,4,4,1,1,2,
		2,1,2,3,1,2,4,4,2,1,2,3,1,2,2,2,2,1,2,3,1,2,4,4,2,1,2,3,1,2,2,2,
		3,3,3,2,1,2,4,4,3,3,3,2,1,2,2,2,3,3,3,2,1,2,4,4,3,3,3,2,1,2,2,2
	};

void CMcSplat::SetTectureMapTileArray( /* void *xppValue */ )
{
	int i, j;
	//�ӽ� ������ ����
	
	
	
	
	for (i = 0; i < 32; ++i )
	{
		for (j = 0; j < 32; ++j)
		{
			m_ppMapTileTextureIndex[i][j] = Data[i * 16 + j];
		}
	}
}

void CMcSplat::SetTextureFilter(bool xisTextureFilter)
{
	m_isTextureFilter = xisTextureFilter;
	if(xisTextureFilter) {
		GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
		GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	}
	else {
		GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
		GDEVICE->SetSamplerState(1, D3DSAMP_MAGFILTER, D3DTEXF_POINT);
	}
}