///////////////////////////////////////////////////////////////////////////////
// File: Player.h
// Desc:  Rendering Height map...
// Date: 2003-04-18, Author: SR OnLine
// History:

#ifndef _PLAYER_H_
#define _PLAYER_H_

class CPlayer  
{
// for Server...
public:
	
	// for Rendering
public:
	VEC			m_vecScale;			// Scale
	MAT			m_matScale;

	PSObjAni	m_pAni;				// �ִϸ��̼� ������
	CGameModel*	m_pObj;				// ��
	SPcInfo		m_PcInfo;			// ������ ����ϴ� ������

public:
	CPlayer();
	virtual ~CPlayer();

public:
	INT		Init();
	void	Destroy();
	
	INT		Restore();
	void	Invalidate();
	
	INT		FrameMove();
	void	Render();

public:
	void	MoveTo();
};



#endif
