///////////////////////////////////////////////////////////////////////////////
// 
// Explain:  Light.cpp: implementation of the CLight class.
// Date : 2003-04-13, Author: SR OnLine
// History: 

#include "Common.h"

// Construction/Destruction

CLight::CLight()
{
	m_pLight	= NULL;
}

CLight::~CLight()
{
	Destroy();
	Invalidate();
}

INT CLight::Init()
{
	INT i=0;
	if(FAILED(Load(g_BaseInfo.FileLighting)))
		return -1;

//	Confirm();


	return 1;
}

VOID CLight::Destroy()
{
	SAFE_DELETE_ARRAY(m_pLight);
}


INT CLight::FrameMove()
{
	return 1;
}

INT CLight::Restore()
{
	// Set miscellaneous render states
	GDEVICE->SetRenderState( D3DRS_DITHERENABLE,   TRUE );
	GDEVICE->SetRenderState( D3DRS_SPECULARENABLE, TRUE );
	GDEVICE->SetRenderState( D3DRS_ZENABLE,        TRUE );
	
	// Set fog
	FLOAT fogStart = 1000.f;
	FLOAT fogEnd = 1500.f;
	GDEVICE->SetRenderState(D3DRS_FOGENABLE, FALSE);
	GDEVICE->SetRenderState(D3DRS_FOGCOLOR, D3DCOLOR_COLORVALUE(0.2f, 0.3f, 0.7f, 1.f ));
	GDEVICE->SetRenderState(D3DRS_FOGSTART, *((DWORD*) (&fogStart)));
	GDEVICE->SetRenderState(D3DRS_FOGEND, *((DWORD*) (&fogEnd)));
	GDEVICE->SetRenderState(D3DRS_FOGTABLEMODE, D3DFOG_LINEAR);
	GDEVICE->SetRenderState(D3DRS_RANGEFOGENABLE, TRUE);

	GDEVICE->SetRenderState(D3DRS_LIGHTING, TRUE);

	return 1;
}

VOID CLight::Invalidate()
{

}

INT CLight::Load(TCHAR *pcFileName)
{
	TCHAR * sTblLightCmd[] =
	{
		"Nef_Lighting_Data_Version",//  0
			"TblLightingData",		//  1
			"NumLighting",			//  2
			
			"Lighting",				//  3
			"IdxLight",				//  4
			"Type",					//  5
			"Diffuse",				//  6
			"Specular",				//  7
			"Ambient",				//  8
			"Position",				//  9
			"Direction",			// 10
			"Range",				// 11
			"Falloff",				// 12
			
			"Attenuation0",			// 13
			"Attenuation1",			// 14
			"Attenuation2",			// 15
			"Theta",				// 16
			"Phi",					// 17
	};


	FILE * fp = NULL;
	
	fp = fopen(pcFileName, "rt");

	if(NULL == fp)
		return -1;
	
	TCHAR sLine[256]= "\0";
	INT nIdxLight = -1;
	
#define	READ_TEXT_LINE(index)	\
	if(!strncmp(sLine, sTblLightCmd[index], strlen(sTblLightCmd[index])))
	
	while(!feof(fp))
	{
		SeUtil_ReadFileLine(fp, sLine, 256);
		
		READ_TEXT_LINE(0)
			sscanf(sLine, "%*s %s", m_szVersion);
		
		READ_TEXT_LINE(1)
		{
			while(!feof(fp))
			{
				SeUtil_ReadFileLine(fp, sLine, 256);
				
				if('}' == sLine[0])
					break;
				
				READ_TEXT_LINE(2)
				{
					sscanf(sLine, "%*s %d", &m_iNumLight);
					
					if(m_iNumLight<=0)
					{
						MessageBox(GHWND, "Lighting data read failed", "Err", NULL);
						return -1;
					}

					m_pLight = new D3DLIGHT9[m_iNumLight];

					for(INT iCntLight=0 ; iCntLight<m_iNumLight; ++iCntLight)
						memset(&m_pLight[iCntLight], 0 , sizeof(D3DLIGHT9));
				}
				
				// Lighting data �б�
				READ_TEXT_LINE(3)
				{
					
					while(!feof(fp))
					{
						SeUtil_ReadFileLine(fp, sLine, 256);
						
						if('}' == sLine[0])
							break;
						
						READ_TEXT_LINE(4)
							sscanf(sLine, "%*s %d", &nIdxLight	);
						
						READ_TEXT_LINE(5)
							sscanf(sLine, "%*s %d", &m_pLight[nIdxLight].Type);

						READ_TEXT_LINE(6)
							sscanf(sLine, "%*s %f %f %f %f"
										, &m_pLight[nIdxLight].Diffuse.r
										, &m_pLight[nIdxLight].Diffuse.g
										, &m_pLight[nIdxLight].Diffuse.b
										, &m_pLight[nIdxLight].Diffuse.a
									);

						READ_TEXT_LINE(7)
							sscanf(sLine, "%*s %f %f %f %f"
										, &m_pLight[nIdxLight].Specular.r
										, &m_pLight[nIdxLight].Specular.g
										, &m_pLight[nIdxLight].Specular.b
										, &m_pLight[nIdxLight].Specular.a
									);

						READ_TEXT_LINE(8)
							sscanf(sLine, "%*s %f %f %f %f"
										, &m_pLight[nIdxLight].Ambient.r
										, &m_pLight[nIdxLight].Ambient.g
										, &m_pLight[nIdxLight].Ambient.b
										, &m_pLight[nIdxLight].Ambient.a
									);

						READ_TEXT_LINE(9)
							sscanf(sLine, "%*s %f %f %f"
										, &m_pLight[nIdxLight].Position.x
										, &m_pLight[nIdxLight].Position.y
										, &m_pLight[nIdxLight].Position.z
									);


						READ_TEXT_LINE(10)
							sscanf(sLine, "%*s %f %f %f"
										, &m_pLight[nIdxLight].Direction.x
										, &m_pLight[nIdxLight].Direction.y
										, &m_pLight[nIdxLight].Direction.z
									);


						READ_TEXT_LINE(11)
							sscanf(sLine, "%*s %f", &m_pLight[nIdxLight].Range);

						READ_TEXT_LINE(12)
							sscanf(sLine, "%*s %f", &m_pLight[nIdxLight].Falloff);


						READ_TEXT_LINE(13)
							sscanf(sLine, "%*s %f", &m_pLight[nIdxLight].Attenuation0);

						READ_TEXT_LINE(14)
							sscanf(sLine, "%*s %f", &m_pLight[nIdxLight].Attenuation1);

						READ_TEXT_LINE(15)
							sscanf(sLine, "%*s %f", &m_pLight[nIdxLight].Attenuation2);


						READ_TEXT_LINE(16)
							sscanf(sLine, "%*s %f", &m_pLight[nIdxLight].Theta);

						READ_TEXT_LINE(17)
							sscanf(sLine, "%*s %f", &m_pLight[nIdxLight].Phi);
					}// while
				}// if
			}//while
		}//if
	}//while


	fclose(fp);
	
#undef	READ_TEXT_LINE

	return 1;
}

VOID CLight::Confirm()
{

	INT i;
	FILE * fp=NULL;
	
	fp = fopen("Log/TblLightingDataConfirm.dat", "wt");
	
	TCHAR	sLine[256]="\0";
	
	sprintf(sLine, "Nef_Local_Data_Version  %s", m_szVersion);	fprintf(fp,"%s\n\n", sLine);
	sprintf(sLine, "TblLightingData");							fprintf(fp,"%s\n", sLine);
	sprintf(sLine, "	NumLighting	%d", m_iNumLight);			fprintf(fp,"%s\n", sLine);
	
	for(i=0; i< m_iNumLight; ++i)
	{
		sprintf(sLine,"	Lighting");								fprintf(fp,"%s\n\n", sLine);
		sprintf(sLine,"		IdxLight	%d", i);				fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"		Type	%d",m_pLight[i].Type);		fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		Diffuse %4.2f %4.2f %4.2f %4.2f"
			, m_pLight[i].Diffuse.r
			, m_pLight[i].Diffuse.g
			, m_pLight[i].Diffuse.b
			, m_pLight[i].Diffuse.a);							fprintf(fp,"%s\n", sLine);

		sprintf(sLine,"		Specular %4.2f %4.2f %4.2f %4.2f"
			, m_pLight[i].Specular.r
			, m_pLight[i].Specular.g
			, m_pLight[i].Specular.b
			, m_pLight[i].Specular.a);							fprintf(fp,"%s\n", sLine);

		sprintf(sLine,"		Ambient %4.2f %4.2f %4.2f %4.2f"
			, m_pLight[i].Ambient.r
			, m_pLight[i].Ambient.g
			, m_pLight[i].Ambient.b
			, m_pLight[i].Ambient.a);							fprintf(fp,"%s\n", sLine);


		sprintf(sLine,"		Position %4.2f %4.2f %4.2f"
			, m_pLight[i].Position.x
			, m_pLight[i].Position.y
			, m_pLight[i].Position.z);							fprintf(fp,"%s\n", sLine);
		
		sprintf(sLine,"		Direction %4.2f %4.2f %4.2f"
			, m_pLight[i].Direction.x
			, m_pLight[i].Direction.y
			, m_pLight[i].Direction.z);							fprintf(fp,"%s\n", sLine);

		sprintf(sLine,"		Range %4.2f", m_pLight[i].Range);		fprintf(fp,"%s\n", sLine);

		sprintf(sLine,"		Falloff %4.2f", m_pLight[i].Range);	fprintf(fp,"%s\n", sLine);

		sprintf(sLine,"		Attenuation0 %4.2f", m_pLight[i].Attenuation0);	fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"		Attenuation0 %4.2f", m_pLight[i].Attenuation1);	fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"		Attenuation0 %4.2f", m_pLight[i].Attenuation2);	fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"		Attenuation0 %4.2f", m_pLight[i].Theta);	fprintf(fp,"%s\n", sLine);
		sprintf(sLine,"		Attenuation0 %4.2f", m_pLight[i].Phi);		fprintf(fp,"%s\n", sLine);

		fprintf(fp,"\n", sLine);		
	}
	
	fclose(fp);

}