// McChase.cpp: implementation of the CMcChase class.
//
//////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"

CMcChase::CMcChase()
{
	m_dL =0.f;
	m_dV =0.f;
	m_pTxS	= 0;
	m_pTxT	= 0;
}

CMcChase::~CMcChase()
{
	Destroy();	
}


INT CMcChase::Init()
{
	D3DXCreateSphere(GDEVICE, 30, 15,10, &m_qS, 0);
	D3DXCreateSphere(GDEVICE, 30, 15,10, &m_qT, 0);
	
	m_vcPs.x = 0.f;
	m_vcPs.y = 0.f;
	m_vcPs.z = 0.f;
	
	m_vcVs.x = 0.f;
	m_vcVs.y = 15.f;
	m_vcVs.z = 0.f;
	
	m_vcPt.x = 300.f;
	m_vcPt.y = 0.f;
	m_vcPt.z = -500.f;
	
	m_fSpd =12.f;
	
	m_fAngle=0.f;
	m_lR = 15.f;

	McUtil_TextureLoad("Texture/Red.png", m_pTxS,0x00FFFFFF);
	McUtil_TextureLoad("Texture/Green.png", m_pTxT,0x00FFFFFF);

	return 1;
}



void CMcChase::Destroy()
{
	SAFE_RELEASE(	m_qS	);
	SAFE_RELEASE(	m_qT	);

	SAFE_RELEASE(	m_pTxS	);
	SAFE_RELEASE(	m_pTxT	);
}



INT CMcChase::FrameMove()
{
	++m_fAngle;
	
	if(m_fAngle>360.f) m_fAngle=0.f;
	
	
	m_vcTs = m_vcPt-m_vcPs;
	
	m_dL = D3DXVec3Length(&m_vcTs);
	
	if(m_dL >(2.5f* m_lR) )
	{
		m_vcTs /= m_dL;			// ���� ���͸� �����.	
		m_vcVs += m_vcTs* (99.f +rand()%2) *0.01f;				// ���ο� �ӵ� ���͸� �����.
		
		m_dV = D3DXVec3Length(&m_vcVs);
		
		if(m_dV<m_fSpd && m_dL< 8* m_lR) --m_fSpd;		//�ӷ� ����
		
		m_vcVs *= m_fSpd/m_dV;	// �ӵ��� �������ͷ� ������ ũ�⸦ ���Ѵ�.
		
		
		m_vcPs +=m_vcVs;					//������ ��ġ�� �ӵ����͸� �����ش�.
	}
	else
	{
		//m_vcPs = m_vcPt;					//�浹�ϸ� ���ο� ��ǥ�� ��´�.
		
		m_vcPt.x = float(400- rand()%800);	// ���ο� ��ǥ�� ��´�.
		m_vcPt.y = float(300- rand()%600);	
		m_vcPt.z = float(500- rand()%1000);
		
		m_fSpd =15.f;
		
	}
	
	
	
	return 1;
}

void CMcChase::Render()
{
	MAT	mtW;

	D3DXMatrixIdentity(&mtW);


	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	GDEVICE->SetRenderState(D3DRS_CULLMODE, D3DCULL_NONE);

	D3DXMatrixRotationAxis(&mtW, &m_vcPs, DEGtoRAD(m_fAngle));
	mtW._41 = m_vcPs.x;
	mtW._42 = m_vcPs.y;
	mtW._43 = m_vcPs.z;

	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);
	GDEVICE->SetTexture(0, m_pTxS);
	m_qS->DrawSubset(0);

	
	D3DXMatrixRotationAxis(&mtW, &m_vcPt, DEGtoRAD(m_fAngle));
	mtW._41 = m_vcPt.x;
	mtW._42 = m_vcPt.y;
	mtW._43 = m_vcPt.z;

	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);
	GDEVICE->SetTexture(0, m_pTxT);
	m_qT->DrawSubset(0);

	D3DXMatrixIdentity(&mtW);
	GDEVICE->SetTransform(D3DTS_WORLD, &mtW);
	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_SOLID);
	
}