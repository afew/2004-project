///////////////////////////////////////////////////////////////////////////////
//
// CommonData.h
// Explain:
// Date : 2003-04-18, Author: SR OnLine
// Update: 2003-05-29
// History:

#ifndef _COMMONDATA_H_
#define _COMMONDATA_H_

enum EGamePhase
{
	GP_BEGIN,					// ���� ����
		GP_CHOOSE_CHARACTER,	// ĳ���ͼ���
		GP_GAME_PLAY,			// ���� ���� ����
		GP_END,				// ���� ��
};


typedef enum tagECharState
{
	C_IDLE,
		C_WALK,
		C_RUN,
		C_ATTACK,
		C_DEAD
}EPcState, EMonState;


// ������ �ְ� �޴� ������.
typedef struct tagSPcInfo
{
	// network
	TCHAR	UsrID[32];	// Name of player
	VEC		vecCur;		// ���� ��ġ
	VEC		vecOld;		// ���� ��ġ
	VEC		vecTar;		// Target position
	VEC		vecDir;		//	Direction
	FLOAT	fSpeed;		// fSpeed;

	EPcState eState;

	INT		iModel;		// Model id
		
	// Constructor
	tagSPcInfo ()
	{
		vecCur.x= vecCur.y = vecCur.z =
		vecOld.x= vecOld.y = vecOld.z =
		vecDir.x= vecDir.y = vecDir.z =
		vecTar.x= vecTar.y = vecTar.z = 0;

		fSpeed = 2.3f;
		
		eState	= C_IDLE;
		iModel	= 0;

		memset(UsrID, 0, sizeof(UsrID));
	}
	
	bool operator==(tagSPcInfo & rhs)
	{
		return ( !strcmp(UsrID, rhs.UsrID)
			&& (vecCur == rhs.vecCur)
			&& (vecOld == rhs.vecOld)
			);
	}
	
	VOID operator=(tagSPcInfo &rhs)
	{
		memcpy(this, &rhs, sizeof(tagSPcInfo));
	}
	
} SPcInfo, * PSPcInfo;


#endif