// Interface for the CMcTool class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCTOOL_H_
#define _MCTOOL_H_

class CMcTool  
{
public:
	CMcTool();
	~CMcTool();

};

#endif _MCTOOL_H_