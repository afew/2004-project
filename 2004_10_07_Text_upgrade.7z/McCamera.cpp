// Implementation of the CMcCamera class.
//
//////////////////////////////////////////////////////////////////////

//#include "MainCommon.h"
#include "McCamera.h"


// Construction/Destruction
/*
CMcCamera::CMcCamera()
{
	m_vcUp		= VEC(0,1,0);
	m_fFar		= 5000.f;
	m_fNear		= 1.f;
	m_fFov		= D3DX_PI /4.f;

	m_fYaw		= 0.f;
	m_fPitch	= 0.f;
	m_fZoom		= 0.f;
}

CMcCamera::~CMcCamera()
{

}

INT CMcCamera::Init()
{
	// Aspect
	RECT rc;
	::GetClientRect(GHWND, &rc);
	m_fAsp = (FLOAT)(rc.right-rc.left)/(FLOAT)(rc.bottom-rc.top);

	// Set Projection Matrix
	SetMatrixProjecton();

	// Set View Matrix Parameter
	m_vcEye =VEC( -100, 200, -100);
	m_vcLook =VEC( 100, 100,  100);
	
//	GDEVICE->Clear( 0L, NULL, D3DCLEAR_TARGET|D3DCLEAR_ZBUFFER, 0xFF0000FF, 1.0f, 0L );
//	GDEVICE->GetViewport(&m_vwPrt);
//
//	m_vwPrt.X		= 100;
//	m_vwPrt.Y		= 100;
//	m_vwPrt.Height	= 300;
//	m_vwPrt.Width	= 400;
//	m_vwPrt.MinZ	= 0.f;
//	m_vwPrt.MaxZ	= 1.f;
//
//	GDEVICE->SetViewport(&m_vwPrt);
	
	return 0;
}


void CMcCamera::SetMatrixProjecton()
{
	D3DXMatrixIdentity(&m_mtProj);

	FLOAT h = cosf(m_fFov/2) / sinf(m_fFov/2);
	FLOAT w = h / m_fAsp;

	m_mtProj._11 = w;
	m_mtProj._22 = h;
	m_mtProj._33 = m_fFar/(m_fFar-m_fNear);
	m_mtProj._43 = m_fNear*m_fFar/(m_fNear-m_fFar);
	m_mtProj._34 = 1.0f;

//	D3DXMatrixPerspectiveFovLH(&mtProj,m_fFov, m_fAsp, m_fNear, m_fFar);
	GDEVICE->SetTransform(D3DTS_PROJECTION, &m_mtProj);	
}


void CMcCamera::SetMatrixView()
{
	VEC zaxis;
	VEC xaxis;
	VEC yaxis;

	FLOAT Dot1;
	FLOAT Dot2;
	FLOAT Dot3;

	zaxis = m_vcLook - m_vcEye;						D3DXVec3Normalize(&zaxis, &zaxis);
	D3DXVec3Cross(&xaxis, &m_vcUp, &zaxis);			D3DXVec3Normalize(&xaxis, &xaxis);
	D3DXVec3Cross(&yaxis, &zaxis, &xaxis);			D3DXVec3Normalize(&yaxis, &yaxis);
	
	Dot1 = D3DXVec3Dot(&xaxis, &m_vcEye);
	Dot2 = D3DXVec3Dot(&yaxis, &m_vcEye);
	Dot3 = D3DXVec3Dot(&zaxis, &m_vcEye);

	 m_mtView._11 = xaxis.x;	m_mtView._12 = yaxis.x;		m_mtView._13 = zaxis.x;		m_mtView._14 = 0;
	 m_mtView._21 = xaxis.y;	m_mtView._22 = yaxis.y;		m_mtView._23 = zaxis.y;		m_mtView._24 = 0;
	 m_mtView._31 = xaxis.z;	m_mtView._32 = yaxis.z;		m_mtView._33 = zaxis.z;		m_mtView._34 = 0;
	 m_mtView._41 = -Dot1;		m_mtView._42 = -Dot2;		m_mtView._43 = -Dot3;		m_mtView._44 = 1;
	
//	D3DXMatrixLookAtLH(&m_mtView, &m_vcEye, &m_vcLook, &m_vcUp);
	GDEVICE->SetTransform(D3DTS_VIEW, &m_mtView);
}

void CMcCamera::MoveForward(FLOAT fSpeed, FLOAT fY)
{
	VEC tmp(m_mtView._13, m_mtView._23*fY, m_mtView._33);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}


void CMcCamera::MoveSideward(FLOAT fSpeed)
{
	VEC tmp(m_mtView._11, 0, m_mtView._31);
	D3DXVec3Normalize(&tmp,&tmp);

	m_vcEye  += tmp * fSpeed;
	m_vcLook += tmp * fSpeed;
}

INT CMcCamera::FrameMove()
{
	MAT rot;
	
//	if(GINPUT->KeyState(0x51) || GINPUT->KeyState(0x51 + 0x20))					// 'q' key	0x51
//	if(GINPUT->KeyState(VK_RIGHT))

	if(GINPUT->KeyState(VK_RBUTTON))
	{
		m_fYaw   = D3DXToRadian(GINPUT->vcDelta.x * 0.1f);
		MAT rot;
		VEC vcLook = m_vcLook-m_vcEye;
		D3DXMatrixRotationY(&rot, m_fYaw);
		D3DXVec3TransformCoord(&vcLook, &vcLook, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
		m_vcUp = VEC(0,m_vcUp.y, 0);

		m_vcLook = vcLook + m_vcEye;
	}

//	if(GINPUT->KeyState(0x45) || GINPUT->KeyState(0x45 + 0x20))					// 'e' key	0x45
	if(GINPUT->KeyState(VK_LEFT))
	{
		m_fYaw   = -D3DXToRadian(GINPUT->vcDelta.x * 0.1f);
		MAT rot;
		VEC vcLook = m_vcLook-m_vcEye;
		D3DXMatrixRotationY(&rot, m_fYaw);
		D3DXVec3TransformCoord(&vcLook, &vcLook, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
		m_vcUp = VEC(0,m_vcUp.y, 0);

		m_vcLook = vcLook + m_vcEye;
	}


	if(GINPUT->KeyState(VK_RBUTTON))
	{
		m_fPitch   = D3DXToRadian(GINPUT->vcDelta.y * 0.1f);
		MAT rot;
		VEC vcLook = m_vcLook-m_vcEye;

		VEC Axis =VEC(m_mtView._11, m_mtView._21, m_mtView._31);
		D3DXMatrixRotationAxis(&rot, & Axis, m_fPitch);

		D3DXVec3TransformCoord(&vcLook, &vcLook, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
//		m_vcUp = VEC(0,m_vcUp.y, 0);

		m_vcLook = vcLook + m_vcEye;
	}

	if(GINPUT->KeyState(VK_DOWN))
	{
		m_fPitch   = -D3DXToRadian(GINPUT->vcDelta.y * 0.1f);
		MAT rot;
		VEC vcLook = m_vcLook-m_vcEye;
		VEC Axis =VEC(m_mtView._11, m_mtView._21, m_mtView._31);
		D3DXMatrixRotationAxis(&rot, & Axis, m_fPitch);

		D3DXVec3TransformCoord(&vcLook, &vcLook, &rot);
		D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &rot);
//		m_vcUp = VEC(0,m_vcUp.y, 0);

		m_vcLook = vcLook + m_vcEye;
	}


	if(GINPUT->MouseSt(MC_MBUTTONDOWN))
	{
		if(GINPUT->vcDelta.z<0)
			MoveForward(60, 1);

		else if(GINPUT->vcDelta.z>0)
			MoveForward(-60, 1);
	}


	if(GINPUT->KeyState(0x57) || GINPUT->KeyState(0x57 + 0x20))					// 'w' key	0x57
	{
		MoveForward(3);
	}

	if(GINPUT->KeyState(0x53) || GINPUT->KeyState(0x53 + 0x20))					// 's' key	0x53
	{
		MoveForward(-3);
	}

	if(GINPUT->KeyState(0x41) || GINPUT->KeyState(0x41 + 0x20))					// 'a' key	0x41
	{
		MoveSideward(-3);
	}

	if(GINPUT->KeyState(0x44) || GINPUT->KeyState(0x44 + 0x20))					// 'd' key	0x42
	{
		MoveSideward(3);
	}


	

	SetMatrixView();
	D3DXMatrixInverse(&m_mtViewInv, NULL, &m_mtView);
	
	m_mtBill = m_mtViewInv;
		
	m_mtBill._41 = 0.0f;
	m_mtBill._42 = 0.0f;
	m_mtBill._43 = 0.0f;

	return 0;
}


//(E) 2004-04-12 Editor: AFEW
VEC	CMcCamera::GetPos()
{
	return VEC(m_mtViewInv._41, m_mtViewInv._42, m_mtViewInv._43);
}

VEC	CMcCamera::Get3DDir(POINT* pt)
{
	VEC2	p2;
	VEC		vcScnPos;
	VEC		vcPickRayDir;
	
	if(NULL ==pt)
	{
		p2.x = GINPUT->MousePos.x;
		p2.y = GINPUT->MousePos.y;
	}

	else
	{
		p2.x = FLOAT(pt->x);
		p2.y = FLOAT(pt->y);
	}



	// Get the pick ray from the mouse position

	FLOAT fW = FLOAT(GMAIN->m_dwScnW );
	FLOAT fH = FLOAT(GMAIN->m_dwScnH );

	FLOAT w = m_mtProj._11;
	FLOAT h = m_mtProj._22;
	
	vcScnPos.x =  ( 2.0f * p2.x / fW - 1 ) / w;
	vcScnPos.y = -( 2.0f * p2.y / fH - 1 ) / h;
	vcScnPos.z =  1.0f;

	// Transform the screen space pick ray into 3D space
	// Ray Direction
	vcPickRayDir.x  = D3DXVec3Dot(&vcScnPos, &VEC(m_mtViewInv._11, m_mtViewInv._21, m_mtViewInv._31));
	vcPickRayDir.y  = D3DXVec3Dot(&vcScnPos, &VEC(m_mtViewInv._12, m_mtViewInv._22, m_mtViewInv._32));
	vcPickRayDir.z  = D3DXVec3Dot(&vcScnPos, &VEC(m_mtViewInv._13, m_mtViewInv._23, m_mtViewInv._33));

	return vcPickRayDir;
}
 *	
 */