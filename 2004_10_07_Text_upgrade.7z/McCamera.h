// Interface for the CMcCamera class.
// Explain: Camera class�� ������ ó���Ѵ�.
// 1. Projection Matrix
// 2. View Matrix
// 3. View port
//////////////////////////////////////////////////////////////////////

#ifndef _MCCAMERA_H_
#define _MCCAMERA_H_

/*



class CMcCamera
{
public:
	TCHAR	m_sN[64];															// Camera Name
	MAT		m_mtProj;															// Projection Matrix
	MAT		m_mtView;															// View matrix
	MAT		m_mtViewInv;														// Inverse View matrix
	MAT		m_mtBill;															// Billboard Matrix
	
	VEC		m_vcEye;															// Camera position
	VEC		m_vcLook;															// Look vector
	VEC		m_vcUp;																// up vector
	
	VEC		m_vcMst;

	FLOAT	m_fYaw;
	FLOAT	m_fPitch;
	FLOAT	m_fZoom;

	VEC		m_vcXAxis;
	VEC		m_vcYAxis;
	VEC		m_vcZAxis;

	FLOAT	m_fFov;																// Filed of view
	FLOAT	m_fAsp;																// Aspect
	FLOAT	m_fNear;															// Near usually 1.f
	FLOAT	m_fFar;																// Far

	VPT		m_vwPrt;															// view port
public:
	TCHAR*	GetName()				{	return m_sN;				}
	MAT		GetMatrixProjection()	{	return m_mtProj;			}
	MAT		GetMatrixView()			{	return m_mtView;			}
	MAT		GetMatrixViewInverse()	{	return m_mtViewInv;			}
	MAT		GetMatrixBillBoard()	{	return m_mtBill;			}

	//(E) 2004-04-12 Editor: AFEW
	VEC		GetPos();
	VEC		Get3DDir(POINT* pt=NULL);

	void	SetMatrixProjecton();
	void	SetMatrixView();

	void	MoveSideward	(FLOAT	fSpeed);
	void	MoveForward		(FLOAT	fSpeed, FLOAT fY=0);

	void	SetEye	(VEC	vPos)	{	m_vcEye=vPos;				}			// Set EyePt vector
	void	SetLook	(VEC	vLook)	{	m_vcLook=vLook;				}			// Set LookAt vector

	INT		FrameMove();
	INT		Init();
	
	CMcCamera();
	~CMcCamera();

};
*/

#endif
