///////////////////////////////////////////////////////////////////////////////
// 
// Explain:  Nef base type
// Date : 2003-04-14, Author: SR OnLine
// History: 


#ifndef _NEFBASETYPE_H_
#define _NEFBASETYPE_H_

typedef D3DXVECTOR3				VEC;
typedef D3DXVECTOR2				VEC2;
typedef D3DXVECTOR4				VEC4;
typedef D3DXMATRIXA16			MAT;
typedef D3DXQUATERNION			QAT;

typedef	LPDIRECT3D9				PD3D;
typedef LPDIRECT3DDEVICE9		PDEV;
typedef	LPD3DXSPRITE			PDSP;

typedef LPDIRECT3DTEXTURE9		PDTX;
typedef LPDIRECT3DVERTEXBUFFER9	PDVB;
typedef LPDIRECT3DSTATEBLOCK9	PDBL;
typedef LPDIRECT3DINDEXBUFFER9	PDIB;

typedef LPDIRECT3DSURFACE9      PDSF;
typedef LPD3DXRENDERTOSURFACE   PDRS;

typedef LPDIRECT3DVERTEXSHADER9 PDVS; // Vertex shader for the bump waves
typedef LPDIRECT3DVERTEXDECLARATION9 PDVD; // Vertex declaration for the bump waves

#endif