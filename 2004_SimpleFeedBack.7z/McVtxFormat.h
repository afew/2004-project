// Interface for the Vertex format structure.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCVTXFORMAT_H_
#define _MCVTXFORMAT_H_


#define FVF_VTXD			(D3DFVF_XYZ|D3DFVF_DIFFUSE)
#define FVF_VTXDUV			(D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1		|D3DFVF_TEXCOORDSIZE2(0))
#define FVF_VTXRHW			(D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1)

typedef struct tagVtxD
{
	VEC3	p;
	DWORD	d;
	
	tagVtxD()								{	p.x=p.y=p.z = 0.f;		d = 0xFFFFFFFF;		}
	tagVtxD(VEC3 P, DWORD D)				{	p = P;					d= D;				}
	tagVtxD(FLOAT X,FLOAT Y,FLOAT Z,DWORD D){	p.x = X;	p.y = Y;	p.z = Z;	d = D;	}
}VtxD;


typedef struct tagVtxDUV
{
	VEC		p;
	DWORD	d;
	FLOAT	u, v;
	
	tagVtxDUV()								{	p.x=p.y=p.z=0.0f;	u=v=0.0f;		d=0xFFFFFFFF;			}
	tagVtxDUV(VEC P)						{	p=P;				u=v=0.0f;		d=0xFFFFFFFF;			}
	tagVtxDUV(VEC P, DWORD D)				{	p=P;								d= D;					}
	tagVtxDUV(VEC P, FLOAT U, FLOAT V)		{	p=P;				u=U;v=V;		d=0xFFFFFFFF;			}
	tagVtxDUV(VEC P,FLOAT U,FLOAT V,DWORD D){	p=P;				u=U;v=V;		d=D;					}
	tagVtxDUV(FLOAT X, FLOAT Y, FLOAT Z
			, FLOAT U, FLOAT V
			, DWORD D=0xFFFFFFFF)			{	p.x=X; p.y=Y;p.z=Z;u=U;v=V;	d=D;							}
	
}VtxDUV;


typedef struct tagVtxwDUV
{
	VEC4	p;
	DWORD	d;
	VEC2	uv;

	tagVtxwDUV()	{}

	tagVtxwDUV(VEC p3,VEC2 UV, DWORD D=0xFFFFFFFF)
											{	p = VEC4(p3.x, p3.y, p3.z, 1.f); uv =UV; d = D;				}

	tagVtxwDUV(VEC4 p4,VEC2 UV,DWORD D=0xFFFFFFFF)
											{	p = VEC4(p4.x, p4.y, p4.z, 1.f); uv =UV; d = D;				}

	tagVtxwDUV(VEC p3, FLOAT u,FLOAT v,DWORD D=0xFFFFFFFF)
											{	p = VEC4(p3.x, p3.y, p3.z, 1.f);	uv = VEC2(u, v); d = D;	}

	tagVtxwDUV(VEC4 p4,FLOAT u,FLOAT v,DWORD D=0xFFFFFFFF)
											{	p = p4;	uv = VEC2(u, v); d = D;								}

	tagVtxwDUV(FLOAT x,FLOAT y,FLOAT z,VEC2 UV,DWORD D=0xFFFFFFFF)
											{	p = VEC4(x, y, z, 1.f);	uv = UV; d = D;						}

	tagVtxwDUV(FLOAT x,FLOAT y,FLOAT z,FLOAT u,FLOAT v,DWORD D=0xFFFFFFFF)
											{	p = VEC4(x, y, z, 1.f);	uv = VEC2(u, v); d = D;				}

}VtxwDUV;



typedef struct tagVtxIdx
{
	union	{	struct	{	WORD a;	WORD b;	WORD c;	};	WORD m[3];	};

	tagVtxIdx()								{	a = 0;		 b = 1;		 c = 2;			}
	tagVtxIdx(WORD A, WORD B, WORD C)		{	a = A;		 b = B;		 c = C;			}
	tagVtxIdx(WORD* R)						{	a = R[0];	 b = R[1];	 c = R[2];		}

	operator WORD* ()						{		return (WORD *) &a;					}
	operator CONST WORD* () const			{		return (CONST WORD *) &a;			}
}VtxIdx;

#endif _MCVTXFORMAT_H_