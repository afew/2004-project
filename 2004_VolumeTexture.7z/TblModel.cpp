// TblModel.cpp: implementation of the CTblModel class.
//
//////////////////////////////////////////////////////////////////////

#include "Common.h"


// Construction/Destruction

CTblModel::CTblModel()
{
	m_iNumModelClass= -1;
	m_pTblMdlIdx	= NULL;
	m_pTblMdlMst	= NULL;
}


CTblModel::~CTblModel()
{
	Destroy();
}

VOID CTblModel::Destroy()
{
	SAFE_DELETE_ARRAY(m_pTblMdlIdx);
	SAFE_DELETE_ARRAY(m_pTblMdlMst);
}


INT CTblModel::Init()
{
	if(FAILED(Load(g_BaseInfo.FileModel)))
		return -1;
	
	return 1;
}


INT CTblModel::Load(TCHAR * pcFileName)
{
	FILE * fp = NULL;
	TCHAR sLine[512]="\0";
	
	TCHAR * sModelCmd[] =
	{
		"Nef_Model_Data_Version",	//0
			"TblModelMst",			//1
			"NumModelClass",		//2
			"TblMstIndex",			//3
			"TblModelClass",		//4
			"ModelIndex",			//5
			"NumModelSub",			//6
			"Rec*",					//7
	};
	
	fp = fopen(pcFileName, "rt");
	
	if(NULL == fp)
		return -1;
	
	while(!feof(fp))
	{
		SeUtil_ReadFileLine(fp, sLine, 512);
		
#define	READ_TEXT_LINE(index)	\
		if(!strncmp(sLine, sModelCmd[index], strlen(sModelCmd[index])))
		
		READ_TEXT_LINE(0)
			sscanf(sLine, "%*s %s", m_szVersion);
		
		READ_TEXT_LINE(1)
		{
			while(!feof(fp))
			{
				SeUtil_ReadFileLine(fp, sLine, 512);
				
				if('}' == sLine[0])
					break;
				
				READ_TEXT_LINE(2)
				{
					sscanf(sLine,"%*s %d"	, &m_iNumModelClass);
					
					if(m_iNumModelClass<1)
						break;
					
					m_pTblMdlIdx = new STblMstIdx[m_iNumModelClass];
					m_pTblMdlMst = new STblMdlMst[m_iNumModelClass];
				}
				
				READ_TEXT_LINE(3)
				{
					INT nIdxMst=0;
					
					while(!feof(fp))
					{
						SeUtil_ReadFileLine(fp, sLine, 512);
						
						if('}' == sLine[0])
							break;
						
						READ_TEXT_LINE(7)
						{
							sscanf(sLine, "%*s %d %s",
								&(m_pTblMdlIdx[nIdxMst].m_nIdxMst),
								m_pTblMdlIdx[nIdxMst].m_szMdlName);
							
							++nIdxMst;
						}
					}//while
				}//if
				
				
				READ_TEXT_LINE(4)
				{
					INT nIdxMst=-1;
					INT nIdxSub=0;
					
					while(!feof(fp))
					{
						SeUtil_ReadFileLine(fp, sLine, 512);
						
						if('}' == sLine[0])
							break;
						
						READ_TEXT_LINE(5)
						{
							sscanf(sLine, "%*s %d", &nIdxMst);
						}
						
						READ_TEXT_LINE(6)
						{
							INT iNumSub=0;
							
							sscanf(sLine, "%*s %d", &iNumSub);							
							
							if(iNumSub<1)
								break;
							
							m_pTblMdlMst[nIdxMst].m_nIdxMst = nIdxMst;
							m_pTblMdlMst[nIdxMst].m_iNumMdlSub =iNumSub;
							m_pTblMdlMst[nIdxMst].m_pTblMdlSub = new STblMdlSub[iNumSub];
						}
						
						READ_TEXT_LINE(7)
						{
							sscanf(sLine, "%*s %d %s",
								&(m_pTblMdlMst[nIdxMst].m_pTblMdlSub[nIdxSub].m_nIdxSub),
								m_pTblMdlMst[nIdxMst].m_pTblMdlSub[nIdxSub].m_szMdlFile);
							
							++nIdxSub;
						}// if
					}//while
				}// if
			}// while
		}// if
		
#undef	READ_TEXT_LINE
	}// while
	
	fclose(fp);
	
	//Confirm();
	
	return 1;
}




VOID CTblModel::Confirm()
{
	INT i, j, k;
	FILE * fp;
	
	fp = fopen("Log/TblModelConfirm.dat", "wt");
	
	fprintf(fp,"Version		%s\n", m_szVersion);
	fprintf(fp,"\nTblModelMst\n");
	fprintf(fp,"\n	Numberclass %d\n", m_iNumModelClass);
	fprintf(fp,"	TblMstIndex\n");
	
	for(i=0; i< m_iNumModelClass; ++i)
	{
		fprintf(fp, "		Rec*	%d	%s \n",
			m_pTblMdlIdx[i].m_nIdxMst,
			m_pTblMdlIdx[i].m_szMdlName);
	}
	
	
	for(i=0; i< m_iNumModelClass; ++i)
	{
		fprintf(fp,"\n\n	TblModelClass\n");
		
		k = m_pTblMdlMst[i].m_iNumMdlSub;
		
		fprintf(fp,"		ModelIndex	%d \n", m_pTblMdlMst[i].m_nIdxMst);
		fprintf(fp,"		NumModelSub	%d \n", k);
		
		for(j=0; j< k; ++j)
		{
			fprintf(fp, "		Rec*	%d	%s \n",
				m_pTblMdlMst[i].m_pTblMdlSub[j].m_nIdxSub,
				m_pTblMdlMst[i].m_pTblMdlSub[j].m_szMdlFile
				);
		}
	}
	
	fclose(fp);
}


INT CTblModel::ModelCreate (INT nMst, INT nSub)
{
	if(!GDEVICE)
	{
		MessageBox(GHWND, "Device Err", "Err", NULL);
		return -1;
	}

	if(0xffff == nSub)	// ���� �ε�
	{
		INT iNumSub = m_pTblMdlMst[nMst].m_iNumMdlSub;
		
		for(INT i=0; i< iNumSub; ++i)
		{
			m_pTblMdlMst[nMst].m_pTblMdlSub[i].m_pMdl = new CGameModel;
			m_pTblMdlMst[nMst].m_pTblMdlSub[i].m_pMdl->Init();
			
			m_pTblMdlMst[nMst].m_pTblMdlSub[i].m_pMdl->Load(
						m_pTblMdlMst[nMst].m_pTblMdlSub[i].m_szMdlFile);

		}
	}
	else	// �ϳ��� �ε�
	{
		if(m_pTblMdlMst[nMst].m_pTblMdlSub[nSub].m_pMdl)
		{
			MessageBox(GHWND, "Game object was created before", "Err", NULL);
			return -1;
		}
		
		
		m_pTblMdlMst[nMst].m_pTblMdlSub[nSub].m_pMdl = new CGameModel;
		m_pTblMdlMst[nMst].m_pTblMdlSub[nSub].m_pMdl->Init();
		m_pTblMdlMst[nMst].m_pTblMdlSub[nSub].m_pMdl->Load(
						m_pTblMdlMst[nMst].m_pTblMdlSub[nSub].m_szMdlFile);
	}
	
	return 1;
}



VOID CTblModel::ModelSelect (CGameModel ** ppGameModel, INT nMst, INT nSub)
{
	if(NULL != (* ppGameModel))
	{
		delete (* ppGameModel);
		(* ppGameModel) = NULL;
	}

	if(nMst < 0 || nMst >m_iNumModelClass || nSub < 0 || nSub> m_pTblMdlMst[nMst].m_iNumMdlSub)
	{
		(* ppGameModel) = NULL;
	}
	
	else
	{
		(* ppGameModel) = new CGameModel;
		(* ppGameModel)->Init();
		(* ppGameModel)->Load(m_pTblMdlMst[nMst].m_pTblMdlSub[nSub].m_szMdlFile);
	}
}



INT CTblModel::ModelIdxSelect(TCHAR *pClassName)
{
	for(INT i=0; i<m_iNumModelClass; ++i)
	{
		if( !strcmp(pClassName,m_pTblMdlIdx[i].m_szMdlName))
			return m_pTblMdlIdx[i].m_nIdxMst;
	}
	return -1;
}

INT CTblModel::SubModelNumber(INT nIdxMst)
{
	if(nIdxMst<0 || nIdxMst >= m_iNumModelClass)
		return -1;
	
	return m_pTblMdlMst[nIdxMst].m_iNumMdlSub;
}
