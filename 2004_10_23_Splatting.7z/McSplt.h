// McSplt.h: interface for the CMcSplt class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCSPLT_H_
#define _MCSPLT_H_

class CMcSplt
{
public:
	INT		m_iNX;																// Number of tile for X
	INT		m_iNZ;																// Number of tile for Z;
	INT		m_iWX;																// Width of tile for x;
	INT		m_iWZ;																// Width of tile for z;

	VtxIdx*	m_pIdx;
	VtxDUV*	m_pVx1;
	VtxDUV*	m_pVx2;
	VtxDUV*	m_pVx3;
	VtxDUV*	m_pVx4;

	PDTX	m_pTx1;
	PDTX	m_pTx2;
	PDTX	m_pTx3;
	PDTX	m_pTx4;
	
public:
	CMcSplt();
	~CMcSplt();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

};

#endif
