// McMap.h: interface for the CMcMap class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCMAP_H_
#define _MCMAP_H_

class CMcMap
{
public:
	PDVB	m_pVB;																// Vertex for Height 

	FLOAT	m_fW;

	VEC3	m_vcI;																// Start position
	
public:
	CMcMap();
	~CMcMap();

	INT		InitDeviceObjects();
	void	RestoreDeviceObjects();
	INT		InvalidateDeviceObjects();
	void	DeleteDeviceObjects();

	INT		FrameMove();
	void	Render();

};

#endif
