// Interface for the CEftPtcR class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _EFTPTCR_H_
#define _EFTPTCR_H_


typedef struct tagEftPt															// Particle structure
{
	INT		Id;
	VEC3	vcP;																// Position
	VEC3	vcV;																// Velocity
	VEC3	vcA;																// X acceleration

	VEC3	vcR ;																// rotation Euler Angle 
	VEC3	vcRv;																// rotation Euler Angle Velocity

	VEC3	vcS ;																// scale
	VEC3	vcSv;																// Scale Velocity
	XCLR	xcC;																// Color

	bool	bLive;																// Active (Yes/No)
	FLOAT	fLife;																// Particle fLife
	FLOAT	fFade;																// Fade Speed
	
	FLOAT	fW;																	// Width
	FLOAT	fH;																	// Height
	FLOAT	fFlp;																// Flapping Triangle
	FLOAT	fDir;																// Flap Direction (Increase Value)
	FLOAT	w	;
	
	
	tagEftPt()
	{
		Id= 0;
		vcP.x=0.f;	vcP.y=0.f;	vcP.z=0.f;
		vcV.x=0.f;	vcV.y=0.f;	vcV.z=0.f;
		vcA.x=0.f;	vcA.y=0.f;	vcA.z=0.f;
		xcC.r =1.f;	xcC.g =1.f;	xcC.b = 1.f;	xcC.a= 1.f;
		
		bLive= true;
		fLife=1.f;
		fFade=0.f;
		fW=0.5f;
		fH=0.1f;
		w = 0.f;
	}

}EftPt;


class CEftPtcR
{
public:
	INT			m_iN;
	INT			m_iNQ;

	PDTX		m_pTx;
	INT			nTm;															// Texture Master Index
	INT			nTs;															// Texture Slave Index
	EftPt*		pPrt;
	VtxDUV*		pVtx;
	
	bool		m_bRn;															// Rendering?
	VEC3		m_vcI;															// Initial position
	VEC3		m_vcP;															// Curent position
	VEC3		m_vcT;															// Tranverse Vector(Veclocity)
	
	FLOAT		m_fSpd;
	
public:
	CEftPtcR();
	~CEftPtcR();
	
	INT		Init();
	void	Destroy();

	void	Run()			{	m_bRn = true;	}
	void	Stop()			{	m_bRn = false;	}
	
	INT		FrameMove();
	void	Render();
	void	Reset();

protected:
	void	Set(INT i);
	INT		PtcUpdate();
	INT		VtxUpdate();
};

#endif