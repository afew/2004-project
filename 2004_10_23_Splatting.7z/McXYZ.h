// Interface for the CMcXYZ class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCXYZ_H_
#define _MCXYZ_H_

class CMcXYZ
{
private:
	VtxIdx*			m_pI;

	VtxD*			m_pX;
	VtxD*			m_pY;
	VtxD*			m_pZ;
	
	D3DXMATRIX		m_mtW;
	D3DXMATRIX		m_mtI;
	D3DXMATRIX		m_mtX;
	D3DXMATRIX		m_mtY;
	D3DXMATRIX		m_mtZ;

public:
	CMcXYZ();
	~CMcXYZ();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	SetMatW(D3DXMATRIX	mtW)	{	m_mtW = mtW;	}
};
#endif _MCXYZ_H_
