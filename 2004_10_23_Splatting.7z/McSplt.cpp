// McSplt.cpp: implementation of the CMcSplt class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CMcSplt::CMcSplt()
{
	m_pIdx	= 0;
	m_pVx1	= 0;
	m_pVx2	= 0;
	m_pVx3	= 0;
	m_pVx4	= 0;
}

CMcSplt::~CMcSplt()
{
	Destroy();	
}


INT CMcSplt::Init()
{
	INT i, j;
	m_iNX = 33;
	m_iNZ = 33;
	
	m_iWX = 32;
	m_iWZ = 32;
	
	INT end = m_iNX * m_iNZ;
	
	m_pVx1 = (VtxDUV*)	 calloc(end, sizeof(VtxDUV));
	m_pVx2 = (VtxDUV*)	 calloc(end, sizeof(VtxDUV));
	m_pVx3 = (VtxDUV*)	 calloc(end, sizeof(VtxDUV));
	m_pVx4 = (VtxDUV*)	 calloc(end, sizeof(VtxDUV));
	
	FLOAT	fH;
	D3DXVECTOR2	uv;
	D3DXVECTOR3	pos;
	D3DXCOLOR	d1;
	D3DXCOLOR	d2;
	D3DXCOLOR	d3;
	D3DXCOLOR	d4;

	for(j=0; j<m_iNZ; ++j)
	{
		for(i=0; i<m_iNX; ++i)
		{
			fH	= -1.f;
			pos	= D3DXVECTOR3(FLOAT(i * m_iWX), fH, FLOAT(j * m_iWZ)) - D3DXVECTOR3( (m_iNX-1) * m_iWX/2, 0, (m_iNZ-1) * m_iWZ/2);
			uv = D3DXVECTOR2(FLOAT(i*2)/(m_iNX-1), 1.f-FLOAT(j*2)/(m_iNZ-1) );

			d1 = D3DXCOLOR(1, 1, 1, (56+rand()%200)/255.f);
			d2 = D3DXCOLOR(1, 1, 1, (56+rand()%200)/255.f);
			d3 = D3DXCOLOR(1, 1, 1, (56+rand()%200)/255.f);
			d4 = D3DXCOLOR(1, 1, 1, 1.f-(d1.a + d2.a + d3.a)*0.3333f );


			m_pVx1[j * m_iNX +i ].d = d1;
			m_pVx1[j * m_iNX +i ].p = pos;
			m_pVx1[j * m_iNX +i ].u = uv[0];
			m_pVx1[j * m_iNX +i ].v = uv[1];


			m_pVx2[j * m_iNX +i ].d = d2;
			m_pVx2[j * m_iNX +i ].p = pos;
			m_pVx2[j * m_iNX +i ].u = uv[0];
			m_pVx2[j * m_iNX +i ].v = uv[1];


			m_pVx3[j * m_iNX +i ].d = d3;
			m_pVx3[j * m_iNX +i ].p = pos;
			m_pVx3[j * m_iNX +i ].u = uv[0];
			m_pVx3[j * m_iNX +i ].v = uv[1];

			m_pVx4[j * m_iNX +i ].d = d4;
			m_pVx4[j * m_iNX +i ].p = pos;
			m_pVx4[j * m_iNX +i ].u = uv[0];
			m_pVx4[j * m_iNX +i ].v = uv[1];
		}
	}
	
	
	
	
	
	INT m, n;
	INT iNX = m_iNX-1;
	INT iNZ = m_iNZ-1;
	
	m_pIdx = (VtxIdx*)calloc( 8 * iNX/2 * iNZ/2, sizeof(VtxIdx));
	
	i=0;
	
	for(m=0; m< iNZ/2;++m)
	{
		for(n=0;n<iNX/2;++n)
		{
			WORD s;
			WORD d;
			WORD a;
			
			WORD f[9];
			
			s = iNX + 2;
			
			d=  (iNZ+ 1)*2;
			
			a = m * d + n * 2 + s;
			
			f[1] = a +iNX+0;	f[2] = a + iNX+1;	f[3] = a +iNX+2;
			f[8] = a - 1;		f[0] = a;			f[4] = a + 1;
			f[7] = a -iNZ-2;	f[6] = a - iNZ-1;	f[5] = a -iNZ-0;
			
			m_pIdx[i+0] = VtxIdx( f[0], f[1], f[2]);
			m_pIdx[i+1] = VtxIdx( f[0], f[2], f[3]);
			m_pIdx[i+2] = VtxIdx( f[0], f[3], f[4]);
			m_pIdx[i+3] = VtxIdx( f[0], f[4], f[5]);
			m_pIdx[i+4] = VtxIdx( f[0], f[5], f[6]);
			m_pIdx[i+5] = VtxIdx( f[0], f[6], f[7]);
			m_pIdx[i+6] = VtxIdx( f[0], f[7], f[8]);
			m_pIdx[i+7] = VtxIdx( f[0], f[8], f[1]);
			
			i +=8;
		}
	}


	McUtil_TextureLoad("Texture/Base_01.png", m_pTx1, 0x00FFFFFF);
	McUtil_TextureLoad("Texture/Base_02.png", m_pTx2, 0x00FFFFFF);
	McUtil_TextureLoad("Texture/Base_03.png", m_pTx3, 0x00FFFFFF);
	McUtil_TextureLoad("Texture/Base_04.png", m_pTx4, 0x00FFFFFF);	
	
	return 1;
}


void CMcSplt::Destroy()
{
	SAFE_FREE(	m_pIdx	);
	SAFE_FREE(	m_pVx1	);
	SAFE_FREE(	m_pVx2	);
	SAFE_FREE(	m_pVx3	);
	SAFE_FREE(	m_pVx4	);

	SAFE_RELEASE(	m_pTx1	);
	SAFE_RELEASE(	m_pTx2	);
	SAFE_RELEASE(	m_pTx3	);
	SAFE_RELEASE(	m_pTx4	);	
}


INT CMcSplt::FrameMove()
{
	return 1;
}


void CMcSplt::Render()
{
	GDEVICE->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	GDEVICE->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	GDEVICE->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);
	
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_MODULATE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_COLORARG2, D3DTA_DIFFUSE );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1 );
	GDEVICE->SetTextureStageState( 0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE );	

	GDEVICE->SetFVF(FVF_VTXDUV);
	GDEVICE->SetTexture(0, m_pTx1);
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNX * m_iNZ, (m_iNX-1) * (m_iNZ-1)* 2, m_pIdx, D3DFMT_INDEX16, m_pVx1, sizeof(VtxDUV));
	GDEVICE->SetTexture(0, m_pTx2);
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNX * m_iNZ, (m_iNX-1) * (m_iNZ-1)* 2, m_pIdx, D3DFMT_INDEX16, m_pVx2, sizeof(VtxDUV));
	GDEVICE->SetTexture(0, m_pTx3);
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNX * m_iNZ, (m_iNX-1) * (m_iNZ-1)* 2, m_pIdx, D3DFMT_INDEX16, m_pVx3, sizeof(VtxDUV));
	GDEVICE->SetTexture(0, m_pTx4);
	GDEVICE->DrawIndexedPrimitiveUP(D3DPT_TRIANGLELIST, 0, m_iNX * m_iNZ, (m_iNX-1) * (m_iNZ-1)* 2, m_pIdx, D3DFMT_INDEX16, m_pVx4, sizeof(VtxDUV));	
}