// TblTexture.cpp: implementation of the CTblTexture class.
//
//////////////////////////////////////////////////////////////////////

#include "Common.h"

// Construction/Destruction

CTblTexture::CTblTexture()
{
	m_iNumTextureClass= -1;
	m_pTblTexIdx	= NULL;
	m_pTblTexMst	= NULL;
}


CTblTexture::~CTblTexture()
{
	Destroy();
}

VOID CTblTexture::Destroy()
{
	SAFE_DELETE_ARRAY(m_pTblTexIdx);
	SAFE_DELETE_ARRAY(m_pTblTexMst);
}


INT CTblTexture::Init()
{
	if(FAILED(Load(g_BaseInfo.FileTexture)))
		return -1;
	
	return 1;
}


INT CTblTexture::Load(TCHAR * pcFileName)
{
	FILE * fp = NULL;
	TCHAR sLine[512]="\0";
	
	TCHAR * sTextureCmd[] =
	{
		"Nef_Texture_Data_Version",	//0
			"TblTextureMst",			//1
			"NumTextureClass",		//2
			"TblMstIndex",			//3
			"TblTextureClass",		//4
			"TextureIndex",			//5
			"NumTextureSub",			//6
			"Rec*",					//7
	};
	
	fp = fopen(pcFileName, "rt");
	
	if(NULL == fp)
		return -1;

#define	READ_TEXT_LINE(index)	\
	if(!strncmp(sLine, sTextureCmd[index], strlen(sTextureCmd[index])))
	
	while(!feof(fp))
	{
		SeUtil_ReadFileLine(fp, sLine, 512);
		
		READ_TEXT_LINE(0)
			sscanf(sLine, "%*s %s", m_szVersion);
		
		READ_TEXT_LINE(1)
		{
			while(!feof(fp))
			{
				SeUtil_ReadFileLine(fp, sLine, 512);
				
				if('}' == sLine[0])
					break;
				
				READ_TEXT_LINE(2)
				{
					sscanf(sLine,"%*s %d"	, &m_iNumTextureClass);
					
					if(m_iNumTextureClass<1)
						break;
					
					m_pTblTexIdx = new STblMstIdx[m_iNumTextureClass];
					m_pTblTexMst = new STblTexMst[m_iNumTextureClass];
				}
				
				READ_TEXT_LINE(3)
				{
					INT nIdxMst=0;
					
					while(!feof(fp))
					{
						SeUtil_ReadFileLine(fp, sLine, 512);
						
						if('}' == sLine[0])
							break;
						
						READ_TEXT_LINE(7)
						{
							sscanf(sLine, "%*s %d %s",
								&(m_pTblTexIdx[nIdxMst].m_nIdxMst),
								m_pTblTexIdx[nIdxMst].m_szTexName);
							
							++nIdxMst;
						}
					}//while
				}//if
				
				
				READ_TEXT_LINE(4)
				{
					INT nIdxMst=-1;
					INT nIdxSub=0;
					
					while(!feof(fp))
					{
						SeUtil_ReadFileLine(fp, sLine, 512);
						
						if('}' == sLine[0])
							break;
						
						READ_TEXT_LINE(5)
						{
							sscanf(sLine, "%*s %d", &nIdxMst);
						}
						
						READ_TEXT_LINE(6)
						{
							INT iNumSub=0;
							
							sscanf(sLine, "%*s %d", &iNumSub);							
							
							if(iNumSub<1)
								break;
							
							m_pTblTexMst[nIdxMst].m_nIdxMst = nIdxMst;
							m_pTblTexMst[nIdxMst].m_iNumTexSub =iNumSub;
							m_pTblTexMst[nIdxMst].m_pTblTexSub = new STblTexSub[iNumSub];
						}
						
						READ_TEXT_LINE(7)
						{
							sscanf(sLine, "%*s %d %s",
								&(m_pTblTexMst[nIdxMst].m_pTblTexSub[nIdxSub].m_nIdxSub),
								m_pTblTexMst[nIdxMst].m_pTblTexSub[nIdxSub].m_szTexFile);
							
							++nIdxSub;
						}// if
					}//while
				}// if
			}// while
		}// if
		
#undef	READ_TEXT_LINE
	}// while
	
	fclose(fp);
	
//	Confirm();
	
	return 1;
}




VOID CTblTexture::Confirm()
{
	INT i, j, k;
	FILE * fp;
	
	fp = fopen("Log/TblTextureConfirm.dat", "wt");
	
	fprintf(fp,"Version		%s\n", m_szVersion);
	fprintf(fp,"\nTblTextureMst\n");
	fprintf(fp,"\n	Numberclass %d\n", m_iNumTextureClass);
	fprintf(fp,"	TblMstIndex\n");
	
	for(i=0; i< m_iNumTextureClass; ++i)
	{
		fprintf(fp, "		Rec*	%d	%s \n",
			m_pTblTexIdx[i].m_nIdxMst,
			m_pTblTexIdx[i].m_szTexName);
	}
	
	
	for(i=0; i< m_iNumTextureClass; ++i)
	{
		fprintf(fp,"\n\n	TblTextureClass\n");
		
		k = m_pTblTexMst[i].m_iNumTexSub;
		
		fprintf(fp,"		TextureIndex	%d \n", m_pTblTexMst[i].m_nIdxMst);
		fprintf(fp,"		NumTextureSub	%d \n", k);
		
		for(j=0; j< k; ++j)
		{
			fprintf(fp, "		Rec*	%d	%s \n",
				m_pTblTexMst[i].m_pTblTexSub[j].m_nIdxSub,
				m_pTblTexMst[i].m_pTblTexSub[j].m_szTexFile
				);
		}
	}
	
	fclose(fp);
}




INT CTblTexture::TextureCreate(INT nIdxMst, INT nIdxSub, DWORD dwColor)
{
	D3DFORMAT d3dFormat;
	memset(&d3dFormat, 0, sizeof(D3DFORMAT));
	
	if(!GDEVICE)
	{
		MessageBox(GHWND, "Device Err", "Err", NULL);
		return -1;
	}
	
	if ( 
		FAILED(
		D3DXCreateTextureFromFileEx(
		GDEVICE,
		m_pTblTexMst[nIdxMst].m_pTblTexSub[nIdxSub].m_szTexFile,
		D3DX_DEFAULT,	D3DX_DEFAULT,	D3DX_DEFAULT,
		0,
		D3DFMT_A1R5G5B5, D3DPOOL_MANAGED,
		D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR, 
		D3DX_FILTER_TRIANGLE|D3DX_FILTER_MIRROR,
		dwColor, NULL, NULL,
		&m_pTblTexMst[nIdxMst].m_pTblTexSub[nIdxSub].m_pTex
		)
		)
		)
	{
		MessageBox(GHWND, "Create texture failed", "Err", NULL);
		m_pTblTexMst[nIdxMst].m_pTblTexSub[nIdxSub].m_pTex = NULL;
		return -1;
	}
	
	return 1;
}

PDTX CTblTexture::TextureSelect(INT nMst, INT nSub)
{
	if(NULL == m_pTblTexMst[nMst].m_pTblTexSub[nSub].m_pTex)
		return NULL;
	
	return m_pTblTexMst[nMst].m_pTblTexSub[nSub].m_pTex;
}


INT CTblTexture::TextureRelease(INT nMst, INT nSub)
{
	HRESULT hr;
	
	if(! m_pTblTexMst[nMst].m_pTblTexSub[nSub].m_pTex)
	{
		MessageBox(GHWND, "Texture is not created","Err",NULL);
		return -1;
	}
	
	hr = m_pTblTexMst[nMst].m_pTblTexSub[nSub].m_pTex->Release();
	
	if(FAILED(hr))
	{
		MessageBox(GHWND, "Texture cannot released","Err",NULL);
		return -1;
	}
	
return 1;
}

