// Interface for the CEftScn class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _EFTRPL_H_
#define _EFTRPL_H_

typedef struct  tagEftRpl
{
	VEC2	d;
	INT		r;																	// WaterDistance from origin, in pixels 

	VEC2	p;																	// initial vertex location 
	VEC2	c;																	// texture coordinate 
	VEC2	t;																	// default texture coordinate 
}EftRpl;



class CEftScn
{
public:
	bool		m_bRn	;
	DWORD		m_dwI	;														// Initial time
	PDTX		m_pTxScn; 
	PDSF		m_pSF	;
	PDRS		m_pRS	;

	INT*		m_piX	;
	INT*		m_piY	;
	INT*		m_piT	;
	INT*		m_piM	;	
	FLOAT*		m_pfA	;														// Ampplitude
	VtxwDUV*	m_pVtx	;
	EftRpl**	m_pRpl	;														// Ripple
	
	INT			m_iM	;														// ripple_max;
	INT			m_iW	;														// Rendering Width
	INT			m_iH	;														// Rendering Height
	INT			m_iNX	;														// Grid Num X
	INT			m_iNY	;														// Grid Num Y
	INT			m_iL	;														// Ripple Length
	INT			m_iC	;														// Ripple Cycles
	FLOAT		m_fA	;														// Ripple Amplitude
	FLOAT		m_fS	;														// Ripple Step
	INT			m_iN	;														// Ripple Count
	
	
public:
	CEftScn();
	~CEftScn();
	INT		Init();
	void	Destroy();
	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

	void	Drop();
	void	Dynamics();
	FLOAT	Distance(INT gx, INT gy, INT cx, INT cy);
	INT		DistanceMax(INT gx, INT gy);
	void	VertexCal();
	void	VectorCal();
	void	AmpCal();

	void	Reset();
};

#endif
