///////////////////////////////////////////////////////////////////////////////
// File: Light.h
// Desc: interface for the CLight class.
// Date: 2003-04-12, Author: SR OnLine
// History: 


#ifndef _LIGHT_H_
#define _LIGHT_H_

class CLight  
{
public:
	TCHAR		m_szVersion[32];	// version
	INT			m_iNumLight;		// Lighting Number
	D3DLIGHT9*	m_pLight;

public:
	CLight();
	virtual ~CLight();

	INT		Init();
	VOID	Destroy();

	INT		Restore();
	VOID	Invalidate();
	
	INT		FrameMove();

private:
	INT		Load(TCHAR* pcFileName);
	VOID	Confirm();
};

#endif
