///////////////////////////////////////////////////////////////////////////////
// File: Main.h
// Date : 2003-04-12, Author: SR OnLine
// History: 
// Desc: Header file Main sample app

// Desc: Application class. The base class (CD3Window) provides the 
//	generic functionality needed in all Direct3D samples. CMain 
//	adds functionality specific to this sample program.
//	OneTimeSceneInit()    - To initialize app data (alloc mem, etc.)
//	Init()			- To initialize the 3D scene objects
//	FrameMove()		- To animate the scene
//	Render()		- To render the scene
//	Delete()		- To cleanup the 3D scene objects
//	FinalCleanup()	- To cleanup app data (for exitting the app)
//	MsgProc()		- To handle Windows messages


class CMain : public CD3Window
{
// global and main...
public:
	CInput		*	m_pInput;		// Input
	CNetwork	*	m_pNetwork;		// Network

	CScene		*	m_pScene;		// Scene
	CDebugString *	m_pDbgstr;

	CTblModel	*	m_pTblMdl;	// Model
	CTblTexture	*	m_pTblTx;	// Texture
	CTblHeightMap*	m_pTblMap;		// Height Map
	CTblLocal	*	m_pTblLcl;	// local
	CTblFont	*	m_pTblFnt;		// font list

	
	
public:
	CMain();
	virtual ~CMain();
	
	virtual LRESULT MsgProc( HWND, UINT, WPARAM, LPARAM);
	virtual HRESULT OneTimeSceneInit();
	virtual HRESULT Init();
	virtual HRESULT Restore();
	virtual HRESULT Invalidate();
	virtual HRESULT Destroy();
	virtual HRESULT Render();
	virtual HRESULT FrameMove();
	virtual HRESULT FinalCleanup();
};

