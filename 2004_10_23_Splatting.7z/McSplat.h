// Interface for the CMcSplat class.
// Original Source: Created by UnKnown Name(realkyoc@hanafos.com)
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCSPLAT_H_
#define _MCSPLAT_H_

struct VtxTerrain
{
    D3DXVECTOR3	p;
    D3DXVECTOR3	n;
	DWORD	d;
	FLOAT	u1, v1;
	FLOAT	u2, v2;
};

#define D3DFVF_VTXTERRAIN (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX2)

class CMcSplat
{
public:
	WORD*	m_pFaces;				// Index Buffer in system memory
	DWORD	m_dwNumVertices;		// Vertex Total
	DWORD	m_dwNumFaces;			// Index Total
	
	PDVB	m_pVB;
	PDIB	m_pIB;
	
	INT		m_nMapSizeX		;
	INT		m_nMapSizeY		;
	INT		m_nChunkTileSize;
	INT		m_nAlphaPixelSize;
	INT		m_nTileTextureNum;
	INT		m_nChunkNumX ;
	INT		m_nChunkNumY ;
	INT		m_nTotalChunk;
	BYTE**	m_ppMapTileTextureIndex;
	bool	m_isTextureFilter;

	PDTX*	m_pBaseTexture;
	PDTX**	m_ppPerChunkAlphaTexture;	//[Chunk_Index][Tile_Set_Index]
	
	
public:
	CMcSplat();
	~CMcSplat();

	INT		Init();
	void	Destroy();

	INT		Restore();
	void	Invalidate();

	INT		FrameMove();
	void	Render();

protected:
	void	CalculateMap();
	void	CalculateMapTile(int xnChunkTileNum, int xnTexNum, PDTX xpTexAlpha, bool bflag = FALSE);
	void	SetTileByPic(TCHAR *xszFileName);
	bool	GetTextureFilter()	{ return m_isTextureFilter; }
	void	SetTextureFilter(bool xisTextureFilter);
	void	SetTectureMapTileArray( /* void *xppValue */ );
};

#endif
