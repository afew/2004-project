//////////////////////////////////////////////////////////////////////
// GameModel.cpp: implementation of the GameModel class.
//


#include "Common.h"


// Construction/Destruction
CGameModel::CGameModel()
: m_pGeom(NULL)
, m_pBone(NULL)
, m_pAnims(NULL)
, m_iNumAnims(0)
, m_iNumBones(0)
, m_iNumGeoms(0)
{
}

CGameModel::~CGameModel()
{
	Destroy();
}

INT CGameModel::Init()
{
	m_iNumGeoms = 0;
	m_iNumBones = 0;
	m_iNumAnims = 0;

	D3DXMatrixIdentity(&m_Mat);

	return 1;
}

VOID CGameModel::Destroy()
{
	Invalidate();

	SAFE_DELETE_ARRAY(m_pGeom);	
	SAFE_DELETE_ARRAY(m_pBone);
	SAFE_DELETE_ARRAY(m_pAnims);
}

INT CGameModel::Load(TCHAR *pszFileName)
{
	FILE* fp = NULL;
	INT iBuildNum;
	TCHAR szVersion[9] = "\0";
	INT i, j;
	INT iTempLen;
	GEOM* pGeom = NULL;
	BONE* pBone = NULL;
	MAT matTemp;
	MAT matR;
	MAT matT;
	VEC vTemp1, vTemp2;

	fp = fopen(pszFileName, "rb");

	if ( NULL == fp )
	{
		return E_FAIL;	
	}

	// Read version
	fread(szVersion, sizeof(TCHAR), 8, fp);
	fread(&iBuildNum, sizeof(INT), 1, fp);
	
	// Compare version
	if ( strcmp(szVersion, SRMODEL_VERSION) != 0 || iBuildNum != SRMODEL_BUILD_NUM )
	{
		fclose(fp);
		return E_FAIL;
	}
	
	// Read Geometry data
	fread(&m_iNumGeoms, sizeof(INT), 1, fp);
	m_pGeom = new GEOM[m_iNumGeoms];
	for( i=0 ; i<m_iNumGeoms ; ++i )
	{
		pGeom = &m_pGeom[i];

		// Read Material
		fread(&pGeom->mtrl, sizeof(D3DMATERIAL9), 1, fp);

		// Read Texture file name
		fread(&iTempLen, sizeof(INT), 1, fp);
		pGeom->pTexturePath = new TCHAR[iTempLen+1];
		ZeroMemory(pGeom->pTexturePath, sizeof(TCHAR)*(iTempLen+1));
		fread(pGeom->pTexturePath, sizeof(TCHAR), iTempLen, fp);

		// Read vertex data
		fread(&pGeom->iNumVertices, sizeof(INT), 1, fp);
		pGeom->pVertices = new VtxNUV[pGeom->iNumVertices];
		fread(pGeom->pVertices, sizeof(VtxNUV), pGeom->iNumVertices, fp);

		// Read index data
		fread(&pGeom->iNumFaces, sizeof(INT), 1, fp);
		pGeom->pIndices = new WORD[pGeom->iNumFaces*3];
		fread(pGeom->pIndices, sizeof(WORD), pGeom->iNumFaces*3, fp);

		// Read physique data
		fread(&pGeom->iNumPhysique, sizeof(INT), 1, fp);
		pGeom->pPhysique = new PHYSIQUE[pGeom->iNumPhysique];
		for( j=0 ; j<pGeom->iNumPhysique ; ++j )
		{
			fread(&pGeom->pPhysique[j].iNumBlendedNodes, sizeof(INT), 1, fp);
			pGeom->pPhysique[j].piBlendedBoneID = new INT[pGeom->pPhysique[j].iNumBlendedNodes];
			pGeom->pPhysique[j].pfWeights = new FLOAT[pGeom->pPhysique[j].iNumBlendedNodes];
			fread(pGeom->pPhysique[j].piBlendedBoneID, sizeof(INT), pGeom->pPhysique[j].iNumBlendedNodes, fp);
			fread(pGeom->pPhysique[j].pfWeights, sizeof(FLOAT), pGeom->pPhysique[j].iNumBlendedNodes, fp);
		}
	}
	
	// Read Bone data
	fread(&m_iNumBones, sizeof(INT), 1, fp);
	m_pBone = new BONE[m_iNumBones];
	for( i=0 ; i<m_iNumBones ; ++i )
	{
		pBone = &m_pBone[i];

		// Read bone name
		fread(pBone->Name, sizeof(TCHAR), 32, fp);

		// Read parent bone id
		fread(&pBone->iParentID, sizeof(INT), 1, fp); 

		// Read child info
		fread(&pBone->iNumChildren, sizeof(INT), 1, fp);
		pBone->pChildIDs = new INT[pBone->iNumChildren];
		fread(pBone->pChildIDs, sizeof(INT), pBone->iNumChildren, fp);

//		// Read scale matrix
//		fread(&pBone->matLocalScale, sizeof(MAT), 1, fp);

		// Read Translation keys
		fread(&pBone->iNumTransKeys, sizeof(INT), 1, fp);
		pBone->pTransKeys = new TRANSLATIONKEY[pBone->iNumTransKeys];
		fread(pBone->pTransKeys, sizeof(TRANSLATIONKEY), pBone->iNumTransKeys, fp);

		// Read Rotation keys
		fread(&pBone->iNumRotKeys, sizeof(INT), 1, fp);
		pBone->pRotKeys = new ROTATIONKEY[pBone->iNumRotKeys];
		fread(pBone->pRotKeys, sizeof(ROTATIONKEY), pBone->iNumRotKeys, fp);

		// Make local matrix
		D3DXMatrixTranslation(&matT, pBone->pTransKeys[0].v.x, pBone->pTransKeys[0].v.y, pBone->pTransKeys[0].v.z);
		D3DXMatrixRotationQuaternion(&matR, &pBone->pRotKeys[0].qt);
		pBone->matAni = matR * matT;
	}

	// Read Anim info
	fread(&m_iNumAnims, sizeof(INT), 1, fp);
	if ( m_iNumAnims > 0 )
	{
		m_pAnims = new ANIMINFO[m_iNumAnims];
		fread(m_pAnims, sizeof(ANIMINFO), m_iNumAnims, fp);
	}

	fclose(fp);

	// Build bone tree
	if ( m_iNumBones > 0 )
	{
		D3DXMatrixIdentity(&matTemp);
		BuildAnimTree(&m_pBone[0], matTemp);
	}


	// Create animation verices
	if ( m_iNumBones > 0 )
	{
		for( i=0 ; i<m_iNumGeoms ; ++i )
		{
			pGeom = &m_pGeom[i];
			pGeom->pAnimVertices = new VtxNUV[pGeom->iNumVertices];
			memcpy(pGeom->pAnimVertices, pGeom->pVertices, sizeof(VtxNUV)*pGeom->iNumVertices);
		}
	}


	Restore();
	
	return 1;
}

INT CGameModel::Restore()
{
	Invalidate();
	
	TCHAR sFile[512] ="\0";

	for( INT i=0 ; i<m_iNumGeoms ; ++i )
	{
		if ( strlen(m_pGeom[i].pTexturePath) > 0 )
		{
			//sprintf(sFile, "%s%s", "model/character/", m_pGeom[i].pTexturePath);
			sprintf(sFile, "%s", "model/character/model.bmp");
			if ( FAILED(D3DUtil_CreateTexture(GDEVICE, sFile, &m_pGeom[i].pTexture)) )
				m_pGeom[i].pTexture = NULL;
		}
	}

	CreateVertexBuffer();

	return 1;
}


VOID CGameModel::Invalidate()
{
	for( INT i=0 ; i<m_iNumGeoms ; ++i )
	{
		SAFE_RELEASE(m_pGeom[i].pTexture);
		SAFE_RELEASE(m_pGeom[i].pIndexBuffer);
		SAFE_RELEASE(m_pGeom[i].pVertexBuffer);
	}
}



VOID CGameModel::Render()
{
	if ( !m_pGeom )
		return;

	if(!m_bRender)
		return;

	INT i;
	GEOM* pGeom = NULL;

	MAT matWorld;
	D3DXMatrixIdentity(&matWorld);

	matWorld._41 = m_vecP.x;
	matWorld._42 = m_vecP.y;
	matWorld._43 = m_vecP.z;

	GDEVICE->SetTransform(D3DTS_WORLD, &matWorld);

	GDEVICE->SetFVF(FVF_VTXNUV);

	for( i=0 ; i<m_iNumGeoms ; ++i )
	{
		pGeom = &m_pGeom[i];

		if ( 0 == pGeom->iNumPhysique )
			GDEVICE->SetTransform(D3DTS_WORLD, &m_Mat);
		
		GDEVICE->SetMaterial(&pGeom->mtrl);
		GDEVICE->SetTexture(0, pGeom->pTexture);
		GDEVICE->SetStreamSource(0, pGeom->pVertexBuffer, 0, sizeof(VtxNUV));
		GDEVICE->SetIndices(pGeom->pIndexBuffer);
		GDEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST, 0, 0, pGeom->iNumVertices, 0, pGeom->iNumFaces);
	}
}




VOID CGameModel::BuildAnimTree(BONE *pBone, MAT &matOld)
{
	pBone->matResult = pBone->matAni * matOld;
	D3DXMatrixInverse(&pBone->matInverse, NULL, &pBone->matResult);
	for( INT i=0 ; i<pBone->iNumChildren ; ++i )
		BuildAnimTree(&m_pBone[pBone->pChildIDs[i]], pBone->matResult);	
}



INT CGameModel::UpdateAnimation(SObjAni * pAni)
{
	INT i;
	GEOM* pGeom = NULL;
	BONE* pBone = NULL;
	MAT matTemp;
	MAT matR, matT;
	VEC vTemp;
	QAT qtTemp;

	// Animation matrix update
	for( i=0 ; i<m_iNumBones ; ++i )
	{
		pBone = &m_pBone[i];
		vTemp = pBone->pTransKeys[pAni->m_iCurrentFrame].v
				+ (pBone->pTransKeys[pAni->m_iCurrentFrame+1].v
				-  pBone->pTransKeys[pAni->m_iCurrentFrame].v) * pAni->m_fInterpolation;

		D3DXMatrixTranslation(&matT, vTemp.x, vTemp.y, vTemp.z);

		D3DXQuaternionSlerp(&qtTemp
							, &pBone->pRotKeys[pAni->m_iCurrentFrame].qt
							, &pBone->pRotKeys[pAni->m_iCurrentFrame+1].qt
							, pAni->m_fInterpolation);

		D3DXMatrixRotationQuaternion(&matR, &qtTemp);
		if ( pBone->iParentID != -1 )
		{
			D3DXMatrixMultiply(&pBone->matResult, &matR, &matT);
			D3DXMatrixMultiply(&pBone->matResult, &pBone->matResult, &m_pBone[pBone->iParentID].matResult);
			D3DXMatrixMultiply(&pBone->matAni, &pBone->matInverse, &pBone->matResult);
		}
		else
		{
			D3DXMatrixMultiply(&pBone->matResult, &matR, &matT);
			D3DXMatrixMultiply(&pBone->matResult, &pBone->matResult, &m_Mat);
			pBone->matAni = pBone->matResult;
		}
	}

	return 1;
}


INT CGameModel::UpdateVertex()
{
	INT i, j, k;
	VEC vTemp;
	MAT matTemp;
	GEOM* pGeom = NULL;

	// main model update 
	for( i=0 ; i<m_iNumGeoms ; ++i )
	{
		pGeom = &m_pGeom[i];

		if ( pGeom->iNumPhysique > 0 )
		{
			for( j=0 ; j<pGeom->iNumPhysique ; ++j )
			{
				ZeroMemory(&pGeom->pAnimVertices[j].p, sizeof(VEC)*2);
				for( k=0 ; k<pGeom->pPhysique[j].iNumBlendedNodes ; ++k )
				{
					MatrixMulByFloat(matTemp, m_pBone[pGeom->pPhysique[j].piBlendedBoneID[k]].matAni, pGeom->pPhysique[j].pfWeights[k]);
					D3DXVec3TransformCoord(&vTemp, &pGeom->pVertices[j].p, &matTemp);
					pGeom->pAnimVertices[j].p += vTemp;
					D3DXVec3TransformNormal(&vTemp, &pGeom->pVertices[j].n, &matTemp);
					pGeom->pAnimVertices[j].n += vTemp;
				}
				D3DXVec3Normalize(&pGeom->pAnimVertices[j].n, &pGeom->pAnimVertices[j].n);
			}

			VtxNUV* pVertices;
			pGeom->pVertexBuffer->Lock(0, 0, (void**)&pVertices, D3DLOCK_DISCARD);
			memcpy(pVertices, pGeom->pAnimVertices, sizeof(VtxNUV)*pGeom->iNumVertices);
			pGeom->pVertexBuffer->Unlock();
		}
	}

	return 1;
}



VOID CGameModel::MatrixMulByFloat(MAT& matTarget, MAT& mat, FLOAT f)
{
	matTarget._11 = mat._11 * f;
	matTarget._12 = mat._12 * f;
	matTarget._13 = mat._13 * f;

	matTarget._21 = mat._21 * f;
	matTarget._22 = mat._22 * f;
	matTarget._23 = mat._23 * f;

	matTarget._31 = mat._31 * f;
	matTarget._32 = mat._32 * f;
	matTarget._33 = mat._33 * f;

	matTarget._41 = mat._41 * f;
	matTarget._42 = mat._42 * f;
	matTarget._43 = mat._43 * f;

	matTarget._14 = matTarget._24 = matTarget._34 = 0.0f;
	matTarget._44 = 1.0f;
}

VOID CGameModel::CreateVertexBuffer()
{
	if ( NULL == GDEVICE )
		return;

	GEOM* pGeom = NULL;
	for( INT i=0 ; i<m_iNumGeoms ; ++i )
	{
		pGeom = &m_pGeom[i];

		SAFE_RELEASE(pGeom->pVertexBuffer);
		SAFE_RELEASE(pGeom->pIndexBuffer);

		// Create vertex buffer
		if ( FAILED(GDEVICE->CreateVertexBuffer(pGeom->iNumVertices*sizeof(VtxNUV),
			D3DUSAGE_DYNAMIC,
			FVF_VTXNUV,
			D3DPOOL_DEFAULT,
			&pGeom->pVertexBuffer,
			NULL)) )
			pGeom->pVertexBuffer = NULL;

		// Create index buffer
		if ( FAILED(GDEVICE->CreateIndexBuffer(pGeom->iNumFaces*3*sizeof(WORD),
			D3DUSAGE_DYNAMIC ,
			D3DFMT_INDEX16,
			D3DPOOL_DEFAULT,
			&pGeom->pIndexBuffer,
			NULL)) )
			pGeom->pIndexBuffer = NULL;

		// Copy indices
		WORD* pIndices = NULL;
		if ( pGeom->pIndexBuffer != NULL )
		{
			if ( SUCCEEDED(pGeom->pIndexBuffer->Lock(0, 0, (void**)&pIndices, 0)) )
			{
				memcpy(pIndices, pGeom->pIndices, sizeof(WORD)*pGeom->iNumFaces*3);
				pGeom->pIndexBuffer->Unlock();
			}
		}

		// Copy vertices
		if ( m_pGeom->iNumPhysique == 0 )
		{
			if ( pGeom->pVertexBuffer != NULL )
			{
				VtxNUV* pVertices;
				pGeom->pVertexBuffer->Lock(0, 0, (void**)&pVertices, D3DLOCK_DISCARD);
				memcpy(pVertices, pGeom->pVertices, sizeof(VtxNUV)*pGeom->iNumVertices);
				pGeom->pVertexBuffer->Unlock();
			}
		}
	}
}

void CGameModel::SetAnimation(INT & iAnimNum)
{
	if ( iAnimNum > m_iNumAnims-1 )
	{
		iAnimNum = m_iNumAnims-1;
		return;
	}

	if ( iAnimNum < 0 )
	{
		iAnimNum = 0;
		return;
	}
}