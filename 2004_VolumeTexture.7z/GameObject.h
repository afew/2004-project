///////////////////////////////////////////////////////////////////////////////
// GameObject.h: interface for the GameObject class.
// Explain:
// Date : 2003-04-18, Author: SR OnLine
// History:


#ifndef _GAMEOBJECT_H_
#define _GAMEOBJECT_H_


// Rendering Base class

class CGameObject
{
public:
	VEC		m_vecP;				// ��ġ
	VEC		m_vecV;				// �ӵ�
	VEC		m_vecD;				// ����
	FLOAT	m_fDist;			// ī�޶�����ǰŸ�
	bool	m_bRender;			// ������ �� ���ΰ�?
	
	
public:
	CGameObject();
	virtual ~CGameObject();
	
	virtual INT				Init();
	virtual VOID			Destroy();
	
	virtual INT				Restore();
	virtual VOID			Invalidate();
	
	virtual INT				FrameMove();
	virtual VOID			Render();
	
	virtual CGameObject	*	FindRoot();
	
	
	CGameObject *	operator=(CGameObject &rhs)
	{
		return & rhs;
	}
};

typedef CGameObject *	PCGameObject;

///////////////////////////////////////////////////////////////////////////////
// For sort... descendent Sort

class CSortingGreater : public greater<PCGameObject>
{
public:
	bool operator()(const PCGameObject &pfi1, const PCGameObject &pfi2) const
	{ 
		return pfi1->m_fDist > pfi2->m_fDist; 
	}
};


///////////////////////////////////////////////////////////////////////////////
// For sort... ascendent Sort

class CSortingLess : public less<PCGameObject>
{
public:
	bool operator()(const PCGameObject &pfi1, const PCGameObject &pfi2) const
	{ 
		return pfi1->m_fDist < pfi2->m_fDist; 
	}
};

#endif
