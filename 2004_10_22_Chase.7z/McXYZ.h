// Interface for the CMcXYZ class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCXYZ_H_
#define _MCXYZ_H_

class CMcXYZ
{
private:
	VtxIdx*	m_pI;

	VtxD*	m_pX;
	VtxD*	m_pY;
	VtxD*	m_pZ;
	
	MAT		m_mtW;
	MAT		m_mtI;
	MAT		m_mtX;
	MAT		m_mtY;
	MAT		m_mtZ;

public:
	CMcXYZ();
	~CMcXYZ();

	INT		Init();
	void	Destroy();

	INT		FrameMove();
	void	Render();

	void	SetMatW(MAT	mtW)	{	m_mtW = mtW;	}
};
#endif _MCXYZ_H_
