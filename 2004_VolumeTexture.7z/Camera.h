///////////////////////////////////////////////////////////////////////////////
// File: Camera.h
// Desc: interface for the CCamera class.
// Date: 2003-04-12, Author: SR OnLine
// History: 


#ifndef _CAMERA_H_
#define _CAMERA_H_


class CCamera
{
public:
	MAT		m_matView;			// view matrix
	MAT		m_matProj;			// projection matrix

	VEC		m_vecXAxis;
	VEC		m_vecYAxis;
	VEC		m_vecZAxis;

	VEC		m_vecEyePt;			// Camera position
	VEC		m_vecLookAt;		// Camera look at vector
	VEC		m_vecUp;			// Camera up vector
	VEC		m_vecMaster;		// ���ΰ� ĳ��������ġ

	FLOAT	m_fFov;
	FLOAT	m_fAspect;
	FLOAT	m_fNear;
	FLOAT	m_fFar;

	FLOAT	m_fYaw;
	FLOAT	m_fPitch;

	FLOAT	m_fZoom;
	TCHAR	m_szName[64];

public:
	CCamera();
	~CCamera();

	INT		Init();
	VOID	Destroy();

	INT		Restore();
	VOID	Invalidate();

	INT		FrameMove();
	VOID	Render();
	VOID	Update();

public:
	VOID	SetMasterCamera(const FLOAT	_fYvalue);
	TCHAR *	GetName() { return m_szName; }
	MAT		GetViewMatrix() { return m_matView; }
	MAT		GetProjMatrix() { return m_matProj; }
	MAT		GetBillboard();

	VOID	RotationXAxis(FLOAT	fAngle);
	VOID	RotationYAxis(FLOAT	fAngle);
	VOID	RotationZAxis(FLOAT	fAngle);
	VOID	MoveSideward(FLOAT	fSpeed);
	VOID	MoveUpward(FLOAT	fSpeed);
	VOID	MoveForward(FLOAT	fSpeed);
	VOID	SetPosition(VEC		vPos);
	VOID	SetProjParam();
	VOID	SetName(TCHAR* szName);


};

#endif