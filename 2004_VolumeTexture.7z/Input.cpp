#include "Common.h"


CInput::CInput()
{
	m_pDInput	= NULL;
	m_pDiKey	= NULL;
	m_pDiMouse	= NULL;
}


CInput::~CInput()
{
	Destroy();
}


void CInput::Destroy()
{
	if(m_pDiKey)
		m_pDiKey->Unacquire();
	
	if(m_pDiMouse)
		m_pDiMouse->Unacquire();
	
	SAFE_RELEASE(m_pDiKey);
	SAFE_RELEASE(m_pDiMouse);
	SAFE_RELEASE(m_pDInput);
}


INT CInput::Init()
{
	memset(Key, 0, sizeof(BYTE)* 256);
	memset(KeyOld, 0, sizeof(BYTE)* 256);
	
	bLButton	= false;
	bLButtonOld	= false;
	bRButton	= false;
	bRButtonOld	= false;
	bLButtonDB	= false;
	
	memset(&MousePos, 0  , sizeof(POINT));
	memset(&MousePosOld,0, sizeof(POINT));
	
	memset(&MouseState, 0, sizeof(DIMOUSESTATE));
	memset(&MouseStateOld, 0, sizeof(DIMOUSESTATE));
	
	zDelta		= 0;
	
	if(FAILED(InitDInput())){	MessageBox(GHWND, "Init direct input", "Err", NULL);	return -1;	}
	
	return 1;
}


// Name: UpdateInput()
INT CInput::FrameMove()
{
	if(!GMAIN->m_bActive)
		return -1;
	
	xDelta = MousePos.x - MousePosOld.x;
	yDelta = MousePos.y - MousePosOld.y;

	memcpy(KeyOld,                 Key, sizeof(BYTE)*256);
	memcpy(&MousePosOld,     &MousePos, sizeof(POINT));
	memcpy(&MouseStateOld, &MouseState, sizeof(DIMOUSESTATE));

//	UpdateGeneral();
	UpdateDInput();

//	TCHAR sTmp[256] = "\0";
//	sprintf(sTmp,"%ld %ld", MousePos.x, MousePos.y);
//	sprintf(sTmp,"%ld %ld", MouseState.lX, MouseState.lY);
//	SetWindowText(GHWND, sTmp);

	return 1;
}


INT CInput::UpdateGeneral()
{
	memcpy(KeyOld, Key, sizeof(BYTE)*256);
	::GetKeyboardState(Key);

	::GetCursorPos(&MousePos);
	::ScreenToClient(GHWND, &MousePos );

	return 1;
}

INT CInput::UpdateDInput()
{
	if (FAILED(m_pDiKey->GetDeviceState(sizeof(Key), (LPVOID)Key)))
	{
		memset(Key, 0, 256 * sizeof(BYTE));
		
		if (FAILED(m_pDiKey->Acquire()))
		{
			return -1;
		}
		
		if (FAILED(m_pDiKey->GetDeviceState(sizeof(Key), (LPVOID)Key)))
		{
			return -1;
		}
	}
	
	
	
	if (FAILED(m_pDiMouse->GetDeviceState(sizeof(DIMOUSESTATE), &MouseState)))
	{
		if (FAILED(m_pDiMouse->Acquire()))
		{
			return -1;
		}
		
		if (FAILED(m_pDiMouse->GetDeviceState(sizeof(DIMOUSESTATE), &MouseState)))
		{
			return -1;
		}
	}

	GetCursorPos(&MousePos);
	::ScreenToClient(GHWND, &MousePos);
	GDEVICE->SetCursorPosition( MousePos.x, MousePos.y, 0 );

	return 1;
}


INT CInput::InitDInput()
{
	if (FAILED(DirectInput8Create(	GMAIN->m_hInst,
		DIRECTINPUT_VERSION,
		IID_IDirectInput8,
		(void **)&m_pDInput,
		NULL)))
		return -1;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysKeyboard, &m_pDiKey, NULL)))
		MessageBox(GHWND, "Create keboard device failed", "Err", NULL);
	
	if (FAILED(m_pDiKey->SetDataFormat(&c_dfDIKeyboard)))
		MessageBox(GHWND, "Set Data format failed", "Err", NULL);
	
	if (FAILED(m_pDiKey->SetCooperativeLevel(GHWND, DISCL_FOREGROUND | DISCL_NONEXCLUSIVE)))
		MessageBox(GHWND, "Set cooperativelevel failed", "Err", NULL);
	
	
	DWORD flags = DISCL_FOREGROUND | DISCL_NONEXCLUSIVE | DISCL_NOWINKEY;
	
	if (FAILED(m_pDInput->CreateDevice(GUID_SysMouse, &m_pDiMouse, NULL)))
		MessageBox(GHWND, "Create mouse device failed", "Err", NULL);
	
	if (FAILED(m_pDiMouse->SetDataFormat(&c_dfDIMouse)))
		MessageBox(GHWND, "Set mouse data format failed", "Err", NULL);
	
	if (FAILED(m_pDiMouse->SetCooperativeLevel(GHWND, flags)))
		MessageBox(GHWND, "Set mouse cooperativelevel failed", "Err", NULL);
	
	return 1;
}
