// Local.cpp: implementation of the CLocalMap class.
//
//////////////////////////////////////////////////////////////////////

#include "Common.h"

CLocalMap::CLocalMap()
{
	// for line....
	m_pTxDetail	= NULL;
	
	for(int i=0; i<4; ++i)
		m_pTxBase[i]= NULL;
	
	m_pBlock	= NULL;
}

CLocalMap::~CLocalMap()
{
}


void CLocalMap::Destroy()
{
	DestroyWorld();

	SAFE_RELEASE(m_pTxDetail);
	
	for(INT i=0; i<4; ++i)
		SAFE_RELEASE(m_pTxBase[i]);
}



void CLocalMap::DestroyWorld()
{
	INT i;
	
	if(m_pBlock)
	{
		for(i=0; i<m_iNumBlockZ; ++i)
		{
			SAFE_DELETE_ARRAY(m_pBlock[i]);
		}
		
		SAFE_DELETE_ARRAY(m_pBlock);
	}
}


INT CLocalMap::Init()
{
	m_iNumBlockX = 20;
	m_iNumBlockZ = 20;
	
	m_iNumTileX = 32;
	m_iNumTileZ = 32;

	m_iWTileX = 32;
	m_iWTileZ = 32;
	
	m_fHScale	= 1.f;
	m_fDelta	= -30.f;
	m_eOp		= 5;
	
	InitWorld("model/map/world.raw");

	// create texture
	if ( FAILED(SeUtil_TextureLoad("model/map/detail.bmp", m_pTxDetail)) )
	{
		m_pTxDetail = NULL;
		return -1;
	}

	TCHAR sFile[512]="\0";

	for(INT i=0; i<4; ++i)
	{
		sprintf(sFile, "model/map/base%d%s",i, ".bmp");

		if ( FAILED(SeUtil_TextureLoad(sFile, m_pTxBase[i])) )
			return -1;
	}


	return 1;
}



INT CLocalMap::Restore()
{	
	RestoreLocalVB();

	return 1;
}




INT CLocalMap::RestoreLocalVB()
{
	m_iX	= INT( GCAMERA->m_vecMaster.x/(m_iWTileX * m_iNumTileX) );
	m_iZ	= INT( GCAMERA->m_vecMaster.z/(m_iWTileX * m_iNumTileX) );
	
	// create vertex buffer and index buffer...
	if(m_iX<1 || m_iX>=(m_iNumBlockX-1) ||m_iZ<1 || m_iZ>=(m_iNumBlockZ-1))
		return -1;

	INT i, j;
	for( j=-1 ; j<2; ++j )
	{
		for( i=-1 ; i<2 ; ++i )
		{
			SeUtil_VBCreate( m_pBlock[m_iZ+j][m_iX+i].m_pVB
				, (m_iNumTileZ+1) * (m_iNumTileX +1) * sizeof(VtxUV)
				, FVF_VTXUV
				, m_pBlock[m_iZ+j][m_iX+i].pVtx
				);

			SeUtil_IBCreate(m_pBlock[m_iZ+j][m_iX+i].m_pIB,sizeof(VtxIdx) * 8 * m_iNumTileX/2 * m_iNumTileZ/2);
		}
	}


// for case Width and Height is 16...
//	272	273	274	275	276	277	278	279	280	281	282	283	284	285	286	287	288
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	255	256	257	258	259	260	261	262	263	264	265	266	267	268	269	270	271
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	238	239	240	241	242	243	244	245	246	247	248	249	250	251	252	253	254
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	221	222	223	224	225	226	227	228	229	230	231	232	233	234	235	236	237
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	204	205	206	207	208	209	210	211	212	213	214	215	216	217	218	219	220
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	187	188	189	190	191	192	193	194	195	196	197	198	199	200	201	202	203
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	170	171	172	173	174	175	176	177	178	179	180	181	182	183	184	185	186
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	153	154	155	156	157	158	159	160	161	162	163	164	165	166	167	168	169
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	136	137	138	139	140	141	142	143	144	145	146	147	148	149	150	151	152
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	119	120	121	122	123	124	125	126	127	128	129	130	131	132	133	134	135
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	102	103	104	105	106	107	108	109	110	111	112	113	114	115	116	117	118
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	85	86	87	88	89	90	91	92	93	94	95	96	97	98	99	100	101
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	68	69	70	71	72	73	74	75	76	77	78	79	80	81	82	83	84
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	51	52	53	54	55	56	57	58	59	60	61	62	63	64	65	66	67
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	34	35	36	37	38	39	40	41	42	43	44	45	46	47	48	49	50
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  �� 
//	17	18	19	20	21	22	23	24	25	26	27	28	29	30	31	32	33
//	  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��  ��
//	0	1	2	3	4	5	6	7	8	9	10	11	12	13	14	15	16

	INT m, n;

	VtxIdx *pIb = new VtxIdx[8 * m_iNumTileX/2 * m_iNumTileZ/2];

	i=0;

	for(m=0; m<m_iNumTileZ/2;++m)
	{
		for(n=0;n<m_iNumTileX/2;++n)
		{
			WORD s;
			WORD d;
			WORD a;

			WORD f[9];

			s = m_iNumTileX+ 2;

			d= (m_iNumTileZ+1)*2;

			a = m * d + n * 2 + s;

			f[1] = a +m_iNumTileX+0;	f[2] = a + m_iNumTileX+1;	f[3] = a +m_iNumTileX+2;
			f[8] = a - 1;				f[0] = a;					f[4] = a + 1;
			f[7] = a -m_iNumTileZ-2;	f[6] = a - m_iNumTileZ-1;	f[5] = a -m_iNumTileZ-0;

			pIb[i+0] = VtxIdx( f[0], f[1], f[2]);
			pIb[i+1] = VtxIdx( f[0], f[2], f[3]);
			pIb[i+2] = VtxIdx( f[0], f[3], f[4]);
			pIb[i+3] = VtxIdx( f[0], f[4], f[5]);
			pIb[i+4] = VtxIdx( f[0], f[5], f[6]);
			pIb[i+5] = VtxIdx( f[0], f[6], f[7]);
			pIb[i+6] = VtxIdx( f[0], f[7], f[8]);
			pIb[i+7] = VtxIdx( f[0], f[8], f[1]);

			i +=8;
		}
	}
	
	for( j=-1 ; j<2; ++j )
	{

		for( i=-1 ; i<2 ; ++i )
		{
			int K=0;

			SeUtil_IBCopy(m_pBlock[m_iZ+j][m_iX+i].m_pIB, sizeof(VtxIdx) * 8 * m_iNumTileX/2 * m_iNumTileZ/2,pIb);
		}

	}


	delete [] pIb;
	

	return 1;
}

void CLocalMap::InvalidateWorld()
{
	INT i,j;	

	// create vertex buffer
	// if(m_pBlock && m_pBlock[0][0].m_pVB)

	if(m_pBlock)
	{
		for( j=0 ; j<m_iNumBlockZ ; ++j )
		{
			for( i=0 ; i<m_iNumBlockX ; ++i )
			{
				SAFE_RELEASE(m_pBlock[j][i].m_pVB);
				SAFE_RELEASE(m_pBlock[j][i].m_pIB);
			}
		}
	}
}


void CLocalMap::Invalidate()
{
	InvalidateWorld();
}



INT CLocalMap::FrameMove()
{
	m_iX	= INT( GCAMERA->m_vecMaster.x/(m_iWTileX * m_iNumTileX) );
	m_iZ	= INT( GCAMERA->m_vecMaster.z/(m_iWTileX * m_iNumTileX) );
	
	GET_KEY(DIK_ADD)
	{
		m_eOp +=1;
		
		if(m_eOp>D3DTOP_ADDSMOOTH)
			m_eOp = 4;
		
//		FormatLog("%d",m_eOp);
	}
	
	
	return 1;
}


INT CLocalMap::SetLocalMap()
{
	//First, relese all vertex buffers
	InvalidateWorld();

	// next, create Local vertex buffer
	RestoreLocalVB();

	return 1;
}





void CLocalMap::Render()
{
	MAT matWorld;
	INT i, j;
	
	if(!m_pBlock || !m_pTxBase[0] || !m_pTxDetail)
		return;

	D3DXMatrixIdentity(&matWorld);
	GDEVICE->SetTransform(D3DTS_WORLD, &matWorld);
	GDEVICE->SetRenderState(D3DRS_FOGENABLE, FALSE);

	GDEVICE->SetFVF(FVF_VTXUV);

//	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	GDEVICE->SetTextureStageState(0, D3DTSS_TEXCOORDINDEX, 0);
	GDEVICE->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	GDEVICE->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_SELECTARG1);

	
	GDEVICE->SetTextureStageState(1, D3DTSS_TEXCOORDINDEX, 1);
	GDEVICE->SetTextureStageState(1, D3DTSS_COLORARG1, D3DTA_TEXTURE);
	GDEVICE->SetTextureStageState(1, D3DTSS_COLORARG2, D3DTA_CURRENT);
	
	GDEVICE->SetTextureStageState(1, D3DTSS_COLOROP, (_D3DTEXTUREOP)m_eOp);	

	
	GDEVICE->SetTexture(1, m_pTxDetail);
	
	
	if(m_iX<1 || m_iX>=(m_iNumBlockX-1) ||m_iZ<1 || m_iZ>=(m_iNumBlockZ-1))
		return ;
	
	INT nIdZ, nIdx;


	for( j=-1 ; j<2; ++j )
	{
		for( i=-1 ; i<2 ; ++i )
		{
			nIdZ = (m_iZ+j)%2;
			nIdx = (m_iX+i)%2;
			
			if(!nIdZ && !nIdx)			// (0,0)
				GDEVICE->SetTexture(0, m_pTxBase[0]);

			if(!nIdZ && nIdx)			// (0,1)
				GDEVICE->SetTexture(0, m_pTxBase[1]);

			if(nIdZ && nIdx)			// (1,1)
				GDEVICE->SetTexture(0, m_pTxBase[2]);

			if(nIdZ && !nIdx)			// (1,0)
				GDEVICE->SetTexture(0, m_pTxBase[3]);
		

			if(m_pBlock[m_iZ+j][m_iX+i].m_pVB)
			{
				GDEVICE->SetStreamSource( 0, m_pBlock[m_iZ+j][m_iX+i].m_pVB, 0, sizeof(VtxUV));
				GDEVICE->SetIndices(m_pBlock[m_iZ+j][m_iX+i].m_pIB);
				GDEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0, 0, (m_iNumTileX+1)*(m_iNumTileZ+1), 0, m_iNumTileX * m_iNumTileZ * 2);
			}
		}
	}

//	nIdZ = (m_iZ)%2;
//	nIdx = (m_iX)%2;
//	
//	if(!nIdZ && !nIdx)			// (0,0)
//		GDEVICE->SetTexture(0, m_pTxBase[0]);
//
//	if(!nIdZ && nIdx)			// (0,1)
//		GDEVICE->SetTexture(0, m_pTxBase[1]);
//
//	if(nIdZ && nIdx)			// (1,1)
//		GDEVICE->SetTexture(0, m_pTxBase[2]);
//
//	if(nIdZ && !nIdx)			// (1,0)
//		GDEVICE->SetTexture(0, m_pTxBase[3]);
//
//
//	if(m_pBlock[m_iZ][m_iX].m_pVB)
//	{
//		GDEVICE->SetStreamSource( 0, m_pBlock[m_iZ][m_iX].m_pVB, 0, sizeof(VtxUV));
//		GDEVICE->SetIndices(m_pBlock[m_iZ][m_iX].m_pIB);
//		GDEVICE->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0, 0, (m_iNumTileX+1)*(m_iNumTileZ+1), 0, m_iNumTileX * m_iNumTileZ * 2);
//	}


	GDEVICE->SetTextureStageState(1, D3DTSS_COLOROP, D3DTOP_DISABLE);
	GDEVICE->SetTexture(0, NULL);
	GDEVICE->SetTexture(1, NULL);
}


INT CLocalMap::InitWorld(TCHAR *sFile)
{
	FILE * fp;
	
	fp = fopen(sFile, "rb");
	
	if(NULL == fp)
	{
		MessageBox(NULL, "Height file load failed", "Err", NULL);
		return -1;
	}
	
	long end;
	
	fseek(fp, 0L, SEEK_SET);	fseek (fp, 0L, SEEK_END);	end	   = ftell(fp);
	fseek(fp, 0L, SEEK_SET);

	BYTE * pHi = NULL;
	
	if(end != m_iNumBlockZ * m_iNumBlockX * m_iNumTileX * m_iNumTileZ)
	{
		MessageBox(GHWND, "File is not matched...", "Err", NULL);
		fclose(fp);
		return -1;
	}
		
	pHi = new BYTE[end];
	fread(pHi, sizeof(BYTE), end, fp);
	fclose(fp);


	DestroyWorld();

	INT i=0, j=0, m=0, n=0;

	SBlockH ** pSBlockH = NULL;

	m_pBlock = new VtxLocal* [m_iNumBlockZ];
	pSBlockH = new SBlockH* [m_iNumBlockZ];
	
	for( j=0 ; j<m_iNumBlockZ ; ++j )
	{
		m_pBlock[j] = new VtxLocal [m_iNumBlockX];
		pSBlockH[j] = new SBlockH [m_iNumBlockX];
		
		for( i=0 ; i<m_iNumBlockX ; ++i )
		{
			pSBlockH[j][i].pH = new BYTE* [m_iNumTileZ+1];
			m_pBlock[j][i].pVtx = new VtxUV[(m_iNumTileZ+1) * (m_iNumTileX+1)];
			
			for(m=0; m<m_iNumTileZ+1; ++m)
			{
				pSBlockH[j][i].pH[m] = new BYTE[m_iNumTileX+1];
			}
		}
	}

	// 1. ���� ���� �д´�.
	
	INT nIdx = 0;
	
	for( j=0 ; j<m_iNumBlockZ ; ++j )
	{
		for( i=0 ; i<m_iNumBlockX ; ++i )
		{
			for(m=0; m<m_iNumTileZ+1; ++m)
			{
				for(n=0; n<m_iNumTileX+1; ++n)
				{
					nIdx = j * m_iNumTileX * m_iNumBlockX * m_iNumTileZ;
					nIdx += m * m_iNumTileX * m_iNumBlockX;
					nIdx += i * m_iNumTileX;
					nIdx += n;
					
					pSBlockH[m_iNumBlockZ-j-1][i].pH[m_iNumTileZ-m][n]
						= pHi[nIdx];
				}
			}
		}
	}
	
	SAFE_DELETE_ARRAY(pHi);
	
	//2. ���� ��ġ�� ��´�.

	FLOAT fDeltaX = 1.f/(2.f*m_iWTileX*m_iNumTileX);		// ó���ȼ��� ������ �ȼ��� u,v�� �����Ѵ�.
	FLOAT fDeltaZ = 1.f/(2.f*m_iWTileZ*m_iNumTileZ);

	INT k=0;
	INT xW = m_iNumTileX * m_iWTileX;
	INT zW = m_iNumTileZ * m_iWTileZ;

	FLOAT u, v;

	VEC p;
		
	for( j=0 ; j<m_iNumBlockZ ; ++j )
	{
		for( i=0 ; i<m_iNumBlockX ; ++i )
		{
			k=0;
			for(m=0; m<m_iNumTileZ+1; ++m)
			{
				for(n=0; n<m_iNumTileX+1; ++n)
				{
					u = FLOAT(n)/m_iNumTileX;
					v = FLOAT(m_iNumTileZ-m)/m_iNumTileZ;

					p.x = i * xW + n * m_iWTileX;
					p.y = pSBlockH[j][i].pH[m][n]*m_fHScale + m_fDelta;
					p.z = j * zW + m * m_iWTileZ;
					
					m_pBlock[j][i].pVtx[k].p = p;

					m_pBlock[j][i].pVtx[k].u = u;
					m_pBlock[j][i].pVtx[k].v = v;

					if(0==n)
					{
						m_pBlock[j][i].pVtx[k].u = fDeltaX;
					}

					if(0==m)
					{
						m_pBlock[j][i].pVtx[k].v = 1 - fDeltaZ;
					}

					if(m_iNumTileX==n)
					{
						m_pBlock[j][i].pVtx[k].u = 1 - fDeltaX;
					}

					if(m_iNumTileZ==m)
					{
						m_pBlock[j][i].pVtx[k].v = fDeltaZ;
					}

					++k;
				}
			}
		}
	}

	//3. ���� ������ �����.
	for(j=0; j<m_iNumBlockZ; ++j)
	{
		for(i=0; i<m_iNumBlockX; ++i)
		{
			for(m=0; m<m_iNumTileZ+1; ++m)
			{
				SAFE_DELETE_ARRAY(pSBlockH[j][i].pH[m]);
			}
			
			SAFE_DELETE_ARRAY(pSBlockH[j][i].pH);
		}

		SAFE_DELETE_ARRAY(pSBlockH[j]);
	}

	SAFE_DELETE_ARRAY(pSBlockH);

	return 1;
}



FLOAT CLocalMap::GetHeight(VEC vecPos)
{
	// Get current Block Index
	INT	iX	= INT( vecPos.x/(m_iWTileX * m_iNumTileX) );
	INT	iZ	= INT( vecPos.z/(m_iWTileZ * m_iNumTileZ) );

	// Get current Vertex Index;

	if( iZ < 0 || iZ>=m_iNumBlockX || iX<0 || iX>=m_iNumBlockX)
		return 0.f;


	INT nX	= INT(vecPos.x/(m_iWTileX+0.001f)) % m_iNumTileX;
	INT nZ	= INT(vecPos.z/(m_iWTileZ+0.001f)) % m_iNumTileZ;

	// start vertex index
	INT	n = ( m_iNumTileX * nZ + nX ) * 6;

	VEC p0 = m_pBlock[iZ][iX].pVtx[n+0].p;
	VEC p1 = m_pBlock[iZ][iX].pVtx[n+1].p;
	VEC p3 = m_pBlock[iZ][iX].pVtx[n+2].p;
	VEC p2 = m_pBlock[iZ][iX].pVtx[n+3].p;

	VEC  vecDelta(0,0,0), temp_pos = vecPos;
	VEC  direction(0.0f, -1.0f, 0.0f);

	float u, v, dist;

	temp_pos.y += 2000.f;


	if		(D3DXIntersectTri( &p0, &p1, &p2, &temp_pos, &direction, &u, &v, &dist))
		vecDelta.y = 2000.f - dist;

	else if (D3DXIntersectTri( &p3, &p2, &p1, &temp_pos, &direction, &u, &v, &dist))
		vecDelta.y = 2000.f - dist;

//	TCHAR sTmp[1024]="\0";
//	sprintf(sTmp, "Block(%d , %d) Vtx(%d, %d) Vtx(%d) Height:%f ", iZ, iX, nZ, nX, n, vecDelta.y);

//	SetWindowText(GHWND, sTmp);
	return vecDelta.y;
}
