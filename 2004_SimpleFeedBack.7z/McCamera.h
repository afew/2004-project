// Interface for the CMcCamera class.
//
////////////////////////////////////////////////////////////////////////////////


#ifndef _MCCAMERA_H_
#define _MCCAMERA_H_


class CMcCamera
{
public:
	MAT		m_mtView;															// view matrix
	MAT		m_mtViewI;															// inverse view matrix
	MAT		m_mtProj;															// projection matrix

	MAT		m_mtBill;															// Billboard for All
	MAT		m_mtBillY;															// Billboard for Y

	VEC3	m_vcXAxis;
	VEC3	m_vcYAxis;
	VEC3	m_vcZAxis;

	VEC3	m_vcEyePt;															// Camera position
	VEC3	m_vcLookAt;															// Camera look at vector
	VEC3	m_vcUp;																// Camera up vector

	VEC3	m_vcRayOrg;															// Ray Position
	VEC3	m_vcMaster;															// ���ΰ� ĳ��������ġ

	FLOAT	m_fFov;
	FLOAT	m_fAspect;
	FLOAT	m_fNear;
	FLOAT	m_fFar;

	FLOAT	m_fYaw;
	FLOAT	m_fPitch;
	FLOAT	m_fZoom;
	TCHAR	m_szName[64];
	FLOAT	m_fAngleView;														// View Angle (Radian)

public:
	FLOAT	m_fR;																// ī�޶� �浹 �ݰ�. 
	DWORD	m_dwStart;
	FLOAT	m_fD;

	VEC3	m_vcAxisX;
	VEC3	m_vcAxisY;
	VEC3	m_vcAxisZ;

public:
	CMcCamera();
	~CMcCamera();

	INT		Init();
	INT		Restore();
	INT		FrameMove();

	void	Update();
	INT		FrameMoveInPortal();


public:
	void	SetMasterCamera(const FLOAT	_fY);
	TCHAR *	GetName()							{	return m_szName;		}
	MAT		GetViewMatrix()						{	return m_mtView;		}
	MAT		GetViewMatrixI()					{	return m_mtViewI;		}
	MAT		GetProjMatrix()						{	return m_mtProj;		}

	MAT		GetBillMat()						{	return m_mtBill;		}
	MAT		GetBillMatY()						{	return m_mtBillY;		}

	VEC3	GetAxisX()							{	return m_vcAxisX;		}
	VEC3	GetAxisY()							{	return m_vcAxisY;		}
	VEC3	GetAxisZ()							{	return m_vcAxisZ;		}
	VEC3	GetRayOrg()							{	return m_vcRayOrg;		}
	VEC3	GetRayDir();

	void	RotationXAxis(FLOAT	fAngle);
	void	RotationYAxis(FLOAT	fAngle);
	void	RotationZAxis(FLOAT	fAngle);
	void	MoveSideward(FLOAT	fSpeed);
	void	MoveUpward(FLOAT	fSpeed);
	void	MoveForward(FLOAT	fSpeed);
	void	SetPosition(VEC3	vPos);
	void	SetProjParam();
	void	SetName(TCHAR* szName);
	void	SetDelta(FLOAT len=0);
};

#endif