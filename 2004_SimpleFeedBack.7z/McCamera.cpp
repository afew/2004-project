// Implementation of the CMcCamera class.
//
////////////////////////////////////////////////////////////////////////////////

#include "_StdAfx.h"



CMcCamera::CMcCamera()
{
	m_szName[0]	= '\0';
	m_fYaw		= 0.0f;
	m_fPitch	= 0.5f;
	m_fZoom		= 300.f;
	m_fNear		= 1.f;
	m_fFar		= 5000.f;
	m_fFov		= D3DX_PI /4.f;
	
	m_vcEyePt	= VEC3(0,-100, 0);
	m_vcLookAt	= VEC3(0, 0, 50);
	m_vcUp		= VEC3(0,1,0);
	m_vcMaster	= VEC3(0,0, 0);
}

CMcCamera::~CMcCamera()
{
}

void CMcCamera::SetDelta(FLOAT len)
{
	m_dwStart	= timeGetTime();
	m_fD		= len;
}

void CMcCamera::SetProjParam()
{
	memset(&m_mtProj, 0, sizeof(m_mtProj));
	FLOAT h = cosf(m_fFov/2) / sinf(m_fFov/2);
	FLOAT w = h / m_fAspect;
	m_mtProj._11 = w;
	m_mtProj._22 = h;
	m_mtProj._33 = m_fFar/(m_fFar-m_fNear);
	m_mtProj._43 = m_fNear*m_fFar/(m_fNear-m_fFar);
	m_mtProj._34 = 1.0f;

//	MAT	matProj;
//	D3DXMatrixIdentity(&matProj);
//	D3DXMatrixPerspectiveFovLH(&matProj,m_fFov, m_fAspect, m_fNear, m_fFar);
	GDEVICE->SetTransform(D3DTS_PROJECTION, &m_mtProj);
}

void CMcCamera::Update()
{
	DWORD dwEnd = timeGetTime();
	
	if(dwEnd-m_dwStart>100)
	{
		m_dwStart = dwEnd;
		SetDelta();
	}

	GDEVICE->SetTransform(D3DTS_VIEW, &m_mtView);	
}

INT CMcCamera::Restore()
{
	if(Init()<0)
		return -1;

	Update();

	return 1;
}


void CMcCamera::SetPosition(VEC3 vPos)
{
	m_vcLookAt += (vPos-m_vcEyePt);
	m_vcEyePt = vPos;
	D3DXMatrixLookAtLH(&m_mtView, &m_vcEyePt, &m_vcLookAt, &m_vcUp);
}

void CMcCamera::MoveForward(FLOAT fSpeed)
{
	VEC2 tmp(m_mtView._13, m_mtView._33);
	
	D3DXVec2Normalize(&tmp,&tmp);
	
	m_vcMaster.x += fSpeed * tmp.x;
	m_vcMaster.z += fSpeed * tmp.y;
}


void CMcCamera::MoveUpward(FLOAT fSpeed)
{
	m_vcEyePt += m_vcYAxis*fSpeed;
	m_vcLookAt += m_vcYAxis*fSpeed;
	D3DXMatrixLookAtLH(&m_mtView, &m_vcEyePt, &m_vcLookAt, &m_vcUp);
}


void CMcCamera::MoveSideward(FLOAT fSpeed)
{
	VEC2 tmp(m_mtView._11, m_mtView._13);
	
	D3DXVec2Normalize(&tmp,&tmp);
	
	m_vcMaster.x += fSpeed * tmp.x;
	m_vcMaster.z += fSpeed * tmp.y;
}


void CMcCamera::RotationXAxis(FLOAT fAngle)
{
	MAT matTemp;
	D3DXMatrixIdentity(&matTemp);
	D3DXMatrixRotationAxis(&matTemp, &m_vcXAxis, D3DXToRadian(-fAngle));
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &matTemp);
	
	m_vcLookAt -= m_vcEyePt;
	D3DXVec3TransformCoord(&m_vcLookAt, &m_vcLookAt, &matTemp);
	m_vcLookAt += m_vcEyePt;
	
	D3DXMatrixLookAtLH(&m_mtView, &m_vcEyePt, &m_vcLookAt, &m_vcUp);
}

void CMcCamera::RotationYAxis(FLOAT fAngle)
{
	MAT matTemp;
	D3DXMatrixIdentity(&matTemp);
	VEC3 vTemp(0.0f, 1.0f, 0.0f);
	D3DXMatrixRotationAxis(&matTemp, &vTemp, D3DXToRadian(-fAngle));
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &matTemp);
	
	m_vcLookAt -= m_vcEyePt;
	D3DXVec3TransformCoord(&m_vcLookAt, &m_vcLookAt, &matTemp);
	m_vcLookAt += m_vcEyePt;
	
	D3DXMatrixLookAtLH(&m_mtView, &m_vcEyePt, &m_vcLookAt, &m_vcUp);
}

void CMcCamera::RotationZAxis(FLOAT fAngle)
{
	MAT matTemp;
	D3DXMatrixIdentity(&matTemp);
	D3DXMatrixRotationAxis(&matTemp, &m_vcZAxis, D3DXToRadian(-fAngle));
	D3DXVec3TransformCoord(&m_vcUp, &m_vcUp, &matTemp);
	
	m_vcLookAt -= m_vcEyePt;
	D3DXVec3TransformCoord(&m_vcLookAt, &m_vcLookAt, &matTemp);
	m_vcLookAt += m_vcEyePt;
	
	D3DXMatrixLookAtLH(&m_mtView, &m_vcEyePt, &m_vcLookAt, &m_vcUp);
}

void CMcCamera::SetName(char *szName)
{
	if ( strlen(szName) > 64 )
	{
		m_szName[0] = '\0';
		return;
	}
	strcpy(m_szName, szName);
}



INT CMcCamera::Init()
{
	m_dwStart = timeGetTime();

	RECT rc;
	::GetClientRect(GHWND, &rc);
	m_fAspect = (FLOAT)(rc.right-rc.left)/(FLOAT)(rc.bottom-rc.top);
	
	D3DXMatrixLookAtLH(&m_mtView, &m_vcEyePt, &m_vcLookAt, &m_vcUp);
	SetProjParam();

	SetMasterCamera(10);
	Update();

	return 1;
}



void CMcCamera::SetMasterCamera(const FLOAT _fYvalue)
{
	VEC3 vEye = VEC3(0.f, 0 , -(m_fZoom));
	VEC3 vUp = VEC3(0.f, 1.f, 0.f);
	MAT matR2;

	D3DXMatrixIdentity(&matR2);
	
	D3DXMatrixRotationYawPitchRoll(&matR2, m_fYaw, m_fPitch, 0.0f);
	D3DXVec3TransformCoord(&vEye, &vEye, &matR2);
	D3DXVec3TransformCoord(&vUp, &vUp, &matR2);
	

	VEC3 vLook = m_vcMaster;
	vEye		+= vLook;
	m_vcEyePt	= vEye;
	m_vcLookAt	= vLook;

	m_vcLookAt.y = m_vcMaster.y + 40.f;
//	m_vcLookAt.y = m_vcMaster.y;
	
	m_vcUp		= vUp;

	D3DXMatrixLookAtLH(&m_mtView, &m_vcEyePt, &m_vcLookAt, &m_vcUp);
}



INT CMcCamera::FrameMove()
{
	BUTTON_STATE(1)
	{
		m_fYaw   += D3DXToRadian(GINPUT->xDelta * 0.45f);
		m_fPitch += D3DXToRadian(GINPUT->yDelta * 0.25f);

//		if(g_BaseInfo.LimitCamera)
//		{
//			if(m_fPitch<0.15f)
//				m_fPitch = 0.15f;
//
//			if(m_fPitch>1.f)
//				m_fPitch = 1.0f;
//		}
	}

	m_fZoom += MOUSE_WHEEL * 0.3f;

	SetMasterCamera(10);
	Update();

	// Get the inverse view matrix
	D3DXMatrixInverse( &m_mtViewI, NULL, &m_mtView );


	// Set Cameta Data
	m_vcAxisX.x	= m_mtViewI._11;
	m_vcAxisX.y	= m_mtViewI._12;
	m_vcAxisX.z	= m_mtViewI._13;

	m_vcAxisY.x	= m_mtViewI._21;
	m_vcAxisY.y	= m_mtViewI._22;
	m_vcAxisY.z	= m_mtViewI._23;

	m_vcAxisZ.x	= m_mtViewI._31;
	m_vcAxisZ.y	= m_mtViewI._32;
	m_vcAxisZ.z	= m_mtViewI._33;

	// Set Billboard Matrix
	m_mtBill	= m_mtViewI;
	m_mtBill._41 = 0.0f;
	m_mtBill._42 = 0.0f;
	m_mtBill._43 = 0.0f;

	
	// Ray Position
	m_vcRayOrg.x = m_mtViewI._41;
	m_vcRayOrg.y = m_mtViewI._42;
	m_vcRayOrg.z = m_mtViewI._43;

	////////////////////////////////////////////////////////////////////////////
	// View Angle���ϱ�
	D3DXVECTOR3 vcDir = m_vcLookAt - m_vcEyePt;
	vcDir.y = 0.f;
	FLOAT L = D3DXVec3Length(&vcDir);

	FLOAT fCos =  vcDir.z / L;
	FLOAT fSin =  vcDir.x / L;
	
	
	if (fCos >= 1.0f)		m_fAngleView = 0.f;
	else if (fCos <= -1.0f)	m_fAngleView = D3DX_PI;
	else					m_fAngleView = acosf(fCos);

	if(fSin < 0.f)
		m_fAngleView = 2 * D3DX_PI - m_fAngleView;

	//Degree
//	m_fAngleView *= ONE_RADtoDEG;		//�ϴ� ��׸��� �ٲ۴�.
//	if(fSin < 0.f)
//		m_fAngleView = 360.f - INT(m_fAngleView);



	/*/
		Z+ �������� ���� ������	  0  (Player�� �������� Camera�� ���ʿ� ��ġ)  
		X+ �������� ���� ������	 90  (Player�� �������� Camera�� ���ʿ� ��ġ)
		Z- �������� ���� ������	180
		X- �������� ���� ������ 270
	/*/

	return 1;
}


INT CMcCamera::FrameMoveInPortal()
{
	BUTTON_STATE(1)
	{
		m_fYaw   += D3DXToRadian(GINPUT->xDelta * 0.15f);
		m_fPitch += D3DXToRadian(GINPUT->yDelta * 0.15f);

//		if(g_BaseInfo.LimitCamera)
		{
			if(m_fPitch < 0.5f)	m_fPitch = 0.5f;
			if(m_fPitch > 1.4f)	m_fPitch = 1.4f;

			if (m_fYaw < -1.2f)	m_fYaw = -1.2f;
			if (m_fYaw >  1.2f)	m_fYaw =  1.2f;
		}
	}

//	m_fZoom += MOUSE_WHEEL * 0.3f;

	SetMasterCamera(10);
	Update();

	// Get the inverse view matrix
	D3DXMatrixInverse( &m_mtViewI, NULL, &m_mtView );
	
	// Ray Position
	m_vcRayOrg.x = m_mtViewI._41;
	m_vcRayOrg.y = m_mtViewI._42;
	m_vcRayOrg.z = m_mtViewI._43;
	
	return 1;
}


VEC3 CMcCamera::GetRayDir()
{
	INT		iScnW, iScnH;
	POINT	pt = GINPUT->MousePos;
	RECT	rt;

	VEC3	vecScnPos;
	VEC3	vecPickRayDir;

	::GetClientRect(GHWND, &rt);

	iScnW = rt.right - rt.left;
	iScnH = rt.bottom- rt.top;
	
	// Get the pick ray from the mouse position
	vecScnPos.x =  ( ( ( 2.0f * pt.x ) / iScnW ) - 1 ) / m_mtProj._11;
	vecScnPos.y = -( ( ( 2.0f * pt.y ) / iScnH ) - 1 ) / m_mtProj._22;
	vecScnPos.z =  1.0f;
	
	// Transform the screen space pick ray into 3D space
	// Ray Direction
	vecPickRayDir.x  = vecScnPos.x * m_mtViewI._11 + vecScnPos.y * m_mtViewI._21 + vecScnPos.z * m_mtViewI._31;
	vecPickRayDir.y  = vecScnPos.x * m_mtViewI._12 + vecScnPos.y * m_mtViewI._22 + vecScnPos.z * m_mtViewI._32;
	vecPickRayDir.z  = vecScnPos.x * m_mtViewI._13 + vecScnPos.y * m_mtViewI._23 + vecScnPos.z * m_mtViewI._33;

	return vecPickRayDir;
}



