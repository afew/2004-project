///////////////////////////////////////////////////////////////////////////////
// File: Network.h
// Date : 2003-04-11, Author: SR OnLine

#ifndef _NETWORK_H_
#define _NETWORK_H_


typedef vector<PSPcInfo>	PcList;
typedef PcList::iterator	PcItor;


class CNetwork
{
public:
	TCHAR	m_szUsrId	[32];	// User id
	TCHAR	m_szUsrPwd	[32];	// user Pwd
	TCHAR	m_szServerIP[16];	// server ip
	TCHAR	m_szPort	[16];	// port

public:
	bool	m_bIsConnect;		// server connection?
	bool	m_bIsReceive;		// data receive?

public:
	INT		m_iTick;			// Tick...
	INT		m_iNumPc;			// number of monster
	INT		m_iNumMon;			// number of player
	INT		m_iNumNpc;			// number of Npc

	PcList	m_vPc;				// Rendering object list

public:
	CNetwork();
	virtual ~CNetwork();

public:
	INT Init();
	INT Destroy();
	INT Restore();
	INT IsConnect();
	INT ConnectServer();
	INT FrameMove();
	
private:
	void NetworkConnection();
	void SendInit();
	void SendLogin();
	void SendMove();
};


#endif