//////////////////////////////////////////////////////////////////////
// Camera.cpp: implementation of the CCamera class.
//

#include "Common.h"

// Construction/Destruction

CCamera::CCamera()
{
	m_szName[0]	= '\0';
	m_fYaw		= 0.0f;
	m_fPitch	= 0.5f;
	m_fZoom		= 200.f;
	m_fNear		= 1.f;
	m_fFar		= 50000.f;
	m_fFov		= D3DX_PI /4.f;
	
	m_vecEyePt	= VEC(0,100, -100);
	m_vecLookAt	= VEC(0, 0, 0);
	m_vecUp		= VEC(0,1,0);
	m_vecMaster	= VEC(0,0, 0);
}

CCamera::~CCamera()
{
	Destroy();
	Invalidate();
}

VOID CCamera::SetProjParam()
{
	memset(&m_matProj, 0, sizeof(m_matProj));
	FLOAT h = cosf(m_fFov/2) / sinf(m_fFov/2);
	FLOAT w = h / m_fAspect;
	m_matProj._11 = w;
	m_matProj._22 = h;
	m_matProj._33 = m_fFar/(m_fFar-m_fNear);
	m_matProj._43 = m_fNear*m_fFar/(m_fNear-m_fFar);
	m_matProj._34 = 1.0f;

//	MAT	matProj;
//	D3DXMatrixIdentity(&matProj);
//	D3DXMatrixPerspectiveFovLH(&matProj,m_fFov, m_fAspect, m_fNear, m_fFar);
	GDEVICE->SetTransform(D3DTS_PROJECTION, &m_matProj);
}

VOID CCamera::Update()
{
	GDEVICE->SetTransform(D3DTS_VIEW, &m_matView);	
}

INT CCamera::Restore()
{
	if(Init()<0)
		return -1;

	Update();

	return 1;
}

VOID CCamera::Invalidate()
{
}


MAT CCamera::GetBillboard()
{
	MAT matBill;
	D3DXMatrixInverse(&matBill, NULL, &m_matView);
	matBill._41 = 0.0f;
	matBill._42 = 0.0f;
	matBill._43 = 0.0f;
	return matBill;
}

VOID CCamera::SetPosition(VEC vPos)
{
	m_vecLookAt += (vPos-m_vecEyePt);
	m_vecEyePt = vPos;
	D3DXMatrixLookAtLH(&m_matView, &m_vecEyePt, &m_vecLookAt, &m_vecUp);
}

VOID CCamera::MoveForward(FLOAT fSpeed)
{
	VEC2 tmp(m_matView._13, m_matView._33);
	
	D3DXVec2Normalize(&tmp,&tmp);
	
	m_vecMaster.x += fSpeed * tmp.x;
	m_vecMaster.z += fSpeed * tmp.y;
}


VOID CCamera::MoveUpward(FLOAT fSpeed)
{
	m_vecEyePt += m_vecYAxis*fSpeed;
	m_vecLookAt += m_vecYAxis*fSpeed;
	D3DXMatrixLookAtLH(&m_matView, &m_vecEyePt, &m_vecLookAt, &m_vecUp);
}


VOID CCamera::MoveSideward(FLOAT fSpeed)
{
	VEC2 tmp(m_matView._11, m_matView._13);
	
	D3DXVec2Normalize(&tmp,&tmp);
	
	m_vecMaster.x += fSpeed * tmp.x;
	m_vecMaster.z += fSpeed * tmp.y;
}


VOID CCamera::RotationXAxis(FLOAT fAngle)
{
	MAT matTemp;
	D3DXMatrixIdentity(&matTemp);
	D3DXMatrixRotationAxis(&matTemp, &m_vecXAxis, D3DXToRadian(-fAngle));
	D3DXVec3TransformCoord(&m_vecUp, &m_vecUp, &matTemp);
	
	m_vecLookAt -= m_vecEyePt;
	D3DXVec3TransformCoord(&m_vecLookAt, &m_vecLookAt, &matTemp);
	m_vecLookAt += m_vecEyePt;
	
	D3DXMatrixLookAtLH(&m_matView, &m_vecEyePt, &m_vecLookAt, &m_vecUp);
}

VOID CCamera::RotationYAxis(FLOAT fAngle)
{
	MAT matTemp;
	D3DXMatrixIdentity(&matTemp);
	VEC vTemp(0.0f, 1.0f, 0.0f);
	D3DXMatrixRotationAxis(&matTemp, &vTemp, D3DXToRadian(-fAngle));
	D3DXVec3TransformCoord(&m_vecUp, &m_vecUp, &matTemp);
	
	m_vecLookAt -= m_vecEyePt;
	D3DXVec3TransformCoord(&m_vecLookAt, &m_vecLookAt, &matTemp);
	m_vecLookAt += m_vecEyePt;
	
	D3DXMatrixLookAtLH(&m_matView, &m_vecEyePt, &m_vecLookAt, &m_vecUp);
}

VOID CCamera::RotationZAxis(FLOAT fAngle)
{
	MAT matTemp;
	D3DXMatrixIdentity(&matTemp);
	D3DXMatrixRotationAxis(&matTemp, &m_vecZAxis, D3DXToRadian(-fAngle));
	D3DXVec3TransformCoord(&m_vecUp, &m_vecUp, &matTemp);
	
	m_vecLookAt -= m_vecEyePt;
	D3DXVec3TransformCoord(&m_vecLookAt, &m_vecLookAt, &matTemp);
	m_vecLookAt += m_vecEyePt;
	
	D3DXMatrixLookAtLH(&m_matView, &m_vecEyePt, &m_vecLookAt, &m_vecUp);
}

VOID CCamera::SetName(char *szName)
{
	if ( strlen(szName) > 64 )
	{
		m_szName[0] = '\0';
		return;
	}
	strcpy(m_szName, szName);
}



INT CCamera::Init()
{
	RECT rc;
	::GetClientRect(GHWND, &rc);
	m_fAspect = (FLOAT)(rc.right-rc.left)/(FLOAT)(rc.bottom-rc.top);
	
	D3DXMatrixLookAtLH(&m_matView, &m_vecEyePt, &m_vecLookAt, &m_vecUp);
	SetProjParam();
	Update();

	return 1;
}



VOID CCamera::SetMasterCamera(const FLOAT _fYvalue)
{
	if (m_fZoom < 45.f )
		m_fZoom = 45.f;
	
	if (m_fZoom > 5000.f )
		m_fZoom = 5000.f;
	
	VEC vEye = VEC(0.0f, m_vecMaster.y , -(m_fZoom));
	VEC vUp = VEC(0.0f, 1.0f, 0.0f);
	MAT matR2;

	D3DXMatrixIdentity(&matR2);
	
	D3DXMatrixRotationYawPitchRoll(&matR2, m_fYaw, m_fPitch, 0.0f);
	D3DXVec3TransformCoord(&vEye, &vEye, &matR2);
	D3DXVec3TransformCoord(&vUp, &vUp, &matR2);
	
	VEC vLook = m_vecMaster;
	
	vLook.y		+= _fYvalue + -1.f;
	vEye		+= vLook;//+VEC(0, _fYvalue, 0);
	m_vecEyePt	= vEye;
	m_vecLookAt	= vLook;
	m_vecUp		= vUp;

	D3DXMatrixLookAtLH(&m_matView, &m_vecEyePt, &m_vecLookAt, &m_vecUp);
}



VOID CCamera::Destroy()
{
}

INT CCamera::FrameMove()
{
	BUTTON_DOWN(1)
	{
		m_fYaw   += D3DXToRadian(GINPUT->xDelta * 0.15f);
		m_fPitch += D3DXToRadian(GINPUT->yDelta * 0.15f);

//		if(m_fPitch<0.15f)
//		{
//			m_fPitch = 0.15f;
//		}
//
//		if(m_fPitch>1.f)
//		{
//			m_fPitch = 1.0f;
//		}
	}



	KEY_STATE(DIK_W)						// 'w' key	0x57
	{
		MoveForward(3);
	}
	
	KEY_STATE(DIK_S)						// 's' key	0x53
	{
		MoveForward(-3);
	}
	
	m_fZoom += MOUSE_WHEEL * 0.3f;
	SetMasterCamera(10);
	Update();
	
	return 1;
}

VOID CCamera::Render()
{
}
