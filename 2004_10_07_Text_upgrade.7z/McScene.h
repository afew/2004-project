// Interface for the CMcScene class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _MCSCENE_H_
#define _MCSCENE_H_

class CMcScene
{
public:

	PDVB		m_pVbLine;
	CMcMap*		m_pMap;

	LPSE2DFONT	m_pFnt;

public:
	CMcScene();
	~CMcScene();
	
	INT		InitDeviceObjects();
	void	RestoreDeviceObjects();
	INT		InvalidateDeviceObjects();
	void	DeleteDeviceObjects();

	INT		FrameMove();
	void	Render();

	void	RenderXYZ();
};

#endif
