///////////////////////////////////////////////////////////////////////////////
// File: Local.h
// Date : 2003-04-18, Author: SR OnLine
// History: 
// Desc: interface for the CLocal class.


#ifndef _LOCAL_H_
#define _LOCAL_H_

class CLocal
{
public:
	typedef struct tagLineBlock
	{
		PDVB 	m_pVBLine;			// Block vertex buffer.
		VtxD	m_Line[5];			// Block region
		
		tagLineBlock()
			: m_pVBLine(NULL)
		{
		}
		
		~tagLineBlock()
		{
			SAFE_RELEASE(m_pVBLine);
		}

	}SLineBlock, * PSLineBlock;

public:
	CLocalMap*	m_pLocalMap;		// Local field map...
	INT			m_nIdxBlockCurrent;
	SLineBlock*	m_LineBlock[9];
	
	
public:
	CLocal();
	virtual ~CLocal();
	
	INT		Init();
	VOID	Destroy();

	INT		Restore();
	VOID	Invalidate();

	INT		FrameMove();
	VOID	Render();
	
private:
	void	InvalidateBlockLine();
	INT		SetBlockData();
};

#endif
