// Implementation of the CEftScn class.
//
//////////////////////////////////////////////////////////////////////


#include "_StdAfx.h"


CEftScn::CEftScn()
{
	m_bRn	= false;
	m_piX	= NULL;
	m_piY	= NULL;
	m_piT	= NULL;
	m_piM	= NULL;
	m_pfA	= NULL;
	m_pVtx	= NULL;

	m_pRpl	= NULL;

	m_pTxScn= NULL;
	m_pSF	= NULL;
	m_pRS	= NULL;

}


CEftScn::~CEftScn()
{
	Invalidate();
	Destroy();
}


void CEftScn::Destroy()
{
	int i;
	
	SAFE_FREE(	m_piX	);
	SAFE_FREE(	m_piY	);
	SAFE_FREE(	m_piT	);
	SAFE_FREE(	m_piM	);
	SAFE_FREE(	m_pfA	);
	SAFE_FREE(	m_pVtx	);
	
	if(m_pRpl)
	{
		for(i=0; i< m_iNX; ++i)
		{
			SAFE_FREE(m_pRpl[i]);
		}
	}

	SAFE_FREE(m_pRpl);
}

INT CEftScn::Init()
{
	m_iW	= 400;
	m_iH	= 300;
	m_iNX	= 64;
	m_iNY	= 64;
	m_iL	= 1024;
	m_iC	= 10;
	m_fA	= 0.125f;
	m_fS	=  20.f;
	m_iN	=  20;

	int i;
	
	char sFile[256] = "\0";
	
	
	m_piX	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_piY	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_piT	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_piM	=(INT*  ) calloc( m_iN , sizeof(INT));
	m_pfA	=(FLOAT*) calloc( m_iL , sizeof(FLOAT));
	
	m_pRpl = (EftRpl**) calloc (m_iNX , sizeof(EftRpl*));
	
	for(i=0; i< m_iNX; ++i)
		m_pRpl[i] = (EftRpl*) calloc (m_iNY , sizeof(EftRpl));
	
	VectorCal();
	AmpCal();
	VertexCal();
	
	m_pVtx =(VtxwDUV*) malloc( 6* m_iNX* m_iNY*sizeof(VtxwDUV));

	return 1;
}


INT CEftScn::Restore()
{
	D3DSURFACE_DESC desc;
	D3DXCreateTexture(GDEVICE, 1024, 1024, 1, D3DUSAGE_RENDERTARGET, D3DFMT_A8R8G8B8,  D3DPOOL_DEFAULT, &m_pTxScn);
	m_pTxScn->GetSurfaceLevel(0, &m_pSF);
	m_pSF->GetDesc(&desc);
	D3DXCreateRenderToSurface(GDEVICE, desc.Width , desc.Height, desc.Format, TRUE, GMAIN->m_d3dSettings.DepthStencilBufferFormat() ,&m_pRS);


	return 1;
}

void CEftScn::Invalidate()
{
	SAFE_RELEASE(	m_pRS	);
	SAFE_RELEASE(	m_pSF	);
	SAFE_RELEASE(	m_pTxScn	);
}


INT CEftScn::FrameMove()
{
	if(!m_bRn)
		return 1;

	DWORD dwF = timeGetTime();

	if(dwF < (m_dwI+3000))
	{
//		Drop();
	}

	else if(dwF > (m_dwI+6000))
	{
		m_bRn = false;
	}
	

	Dynamics();

	FLOAT fRX = FLOAT(GMAIN->m_dwCreationWidth)/m_iW;
	FLOAT fRY = FLOAT(GMAIN->m_dwCreationHeight)/m_iH;

	INT k=0;
	for(INT i=0; i< m_iNX-1; ++i)
	{
		for(INT j=0; j < m_iNY-1; ++j)
		{
			EftRpl * p00 = &m_pRpl[i+0][j+0];
			EftRpl * p10 = &m_pRpl[i+1][j+0];
			EftRpl * p01 = &m_pRpl[i+0][j+1];
			EftRpl * p11 = &m_pRpl[i+1][j+1];


			
			m_pVtx[k*6+0] =	VtxwDUV(p00->p.x * fRX, p00->p.y * fRY, 0.f, p00->c.x, p00->c.y);
			m_pVtx[k*6+1] =	VtxwDUV(p10->p.x * fRX, p10->p.y * fRY, 0.f, p10->c.x, p10->c.y);
			m_pVtx[k*6+2] =	VtxwDUV(p01->p.x * fRX, p01->p.y * fRY, 0.f, p01->c.x, p01->c.y);
			m_pVtx[k*6+3] =	VtxwDUV(p11->p.x * fRX, p11->p.y * fRY, 0.f, p11->c.x, p11->c.y);


			m_pVtx[k*6+4] =	m_pVtx[k*6+2];
			m_pVtx[k*6+5] =	m_pVtx[k*6+1];

			++k;
		}
	}

	return 1;
}


void CEftScn::Render()
{
	if(!m_bRn)
		return;


//	GDEVICE->SetRenderState(D3DRS_FILLMODE, D3DFILL_WIREFRAME);
	GDEVICE->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);
	GDEVICE->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_MIRROR);

	
	GDEVICE->SetTextureStageState(0, D3DTSS_COLORARG1, D3DTA_DIFFUSE);
	GDEVICE->SetTextureStageState(0, D3DTSS_COLORARG2, D3DTA_TEXTURE);
	GDEVICE->SetTextureStageState(0, D3DTSS_COLOROP, D3DTOP_MODULATE);

	GDEVICE->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_DIFFUSE);
	GDEVICE->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_TEXTURE);
	GDEVICE->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	
	GDEVICE->SetRenderState( D3DRS_FOGENABLE, 	FALSE);
	GDEVICE->SetRenderState( D3DRS_LIGHTING, FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHABLENDENABLE, FALSE);
	GDEVICE->SetRenderState( D3DRS_ALPHATESTENABLE, FALSE);

	GDEVICE->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );
	GDEVICE->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE );
	
	GDEVICE->SetTexture(0, m_pTxScn);
	GDEVICE->SetFVF(FVF_VTXRHW);
	GDEVICE->DrawPrimitiveUP(D3DPT_TRIANGLELIST, 2*m_iNX*m_iNY, m_pVtx, sizeof(VtxwDUV));

}


void CEftScn::Drop()
{
	INT index=0;
	
//	INT nPosX = 1 + rand()%(m_iW-2);
//	INT nPosY = 1 + rand()%(m_iH-2);

	INT nPosX = m_iW/2;
	INT nPosY = m_iH/2;
	
	while (m_piT[index] < m_piM[index] && index < m_iN)
		index++;
	
	if (index < m_iN)
	{
		m_piX[index] = INT(1.f*m_iNX*nPosX/m_iW);
		m_piY[index] = INT(1.f*m_iNY*nPosY/m_iH);
		m_piT[index] = INT(4.f*m_fS);
		m_piM[index] = DistanceMax(m_piX[index], m_piY[index]);
	}
}



void CEftScn::Dynamics()
{
	INT i, j, k;
	INT x, y;
	INT mi, mj;
	INT r;
	
	VEC2 s;
	FLOAT amp;
	
	for(i=0; i < m_iN; i++)
		m_piT[i] += INT(m_fS);
	
	for(i=0; i < m_iNX; i++)
	{
		for(j=0; j < m_iNY; j++)
		{
			m_pRpl[i][j].c = m_pRpl[i][j].t;
			
			for(k=0; k < m_iN; k++)
			{
				x = i - m_piX[k];
				y = j - m_piY[k];
				
				if (x < 0)
				{
					x *= -1;
					s.x = -1.f;
				}
				else
					s.x = 1.f;
				
				if (y < 0)
				{
					y *= -1;
					s.y = -1.f;
				}
				else
					s.y = 1.f;
				
				mi = x;
				mj = y;
				
				r = m_piT[k] - m_pRpl[mi][mj].r;
				
				if (r < 0)
					r = 0;
				
				
				if (r > m_iL - 1)
					r = m_iL - 1;
				
				amp = 1.f - 1.f*m_piT[k]/m_iL;
				amp *= amp;
				
				if (amp < 0.f)
					amp = 0.f;
				
				m_pRpl[i][j].c.x += m_pRpl[mi][mj].d.x * s.x * m_pfA[r] * amp;
				m_pRpl[i][j].c.y += m_pRpl[mi][mj].d.y * s.y * m_pfA[r] * amp;
			}
		}
	}
}



FLOAT CEftScn::Distance(INT gx, INT gy, INT m_piX, INT m_piY)
{
	return sqrtf(FLOAT((gx - m_piX)*(gx - m_piX) + (gy - m_piY)*(gy - m_piY)));
}


INT CEftScn::DistanceMax(INT gx, INT gy)
{
	FLOAT d;
	FLOAT temp_d;
	
	d = Distance(gx, gy, 0, 0);
	temp_d = Distance(gx, gy, m_iNX, 0);
	
	if (temp_d > d)
		d = temp_d;
	
	temp_d = Distance(gx, gy, m_iNX, m_iNY);
	
	if (temp_d > d)
		d = temp_d;
	
	temp_d = Distance(gx, gy, 0, m_iNY);
	
	if (temp_d > d)
		d = temp_d;
	
	return INT((d/m_iNX)*m_iW + m_iL/6);
}



void CEftScn::VertexCal()
{
	INT i, j;
	
	m_iM = (INT)sqrt(m_iH*m_iH + m_iW*m_iW);
	
	for(i=0; i < m_iN; i++)
	{
		m_piT[i] = m_iM + m_iL;
		m_piX[i] = 0;
		m_piY[i] = 0;
		m_piM[i] = 0;
	}
	
	for(i=0; i < m_iNX; i++)
	{
		for(j=0; j < m_iNY; j++)
		{
			m_pRpl[i][j].p = VEC2( i/(m_iNX - 1.f)*m_iW, j/(m_iNY - 1.f)*m_iH);
			m_pRpl[i][j].t = VEC2( i/(m_iNX - 1.f),    j/(m_iNY - 1.f));
		}
	}
}



void CEftScn::VectorCal()
{
	INT i, j;
	VEC2	p;
	FLOAT	l;
	
	for(i=0; i < m_iNX; i++)
	{
		for(j=0; j < m_iNY; j++)
		{
			p = VEC2( i/(m_iNX-1.f), j/(m_iNY-1.f) );
			l = D3DXVec2Length(&p);
			
			if (l == 0.f)
				p = VEC2(0.f, 0.f);
			
			else
				p /= l;
			
			
			m_pRpl[i][j].d = p;
			m_pRpl[i][j].r = (INT) (l*m_iW*2);
		}
	}
}


void CEftScn::AmpCal()
{
	INT i;
	FLOAT m_piT;
	FLOAT a;
	
	for(i=0; i < m_iL; i++)
	{
		m_piT = 1.f - i/FLOAT(m_iL);
		
		a = (1- cosf( m_piT * 6.283185307f*m_iC))* m_fA * powf(m_piT, 10);
		
		if (i == 0)
			a = 0.f;
		
		m_pfA[i] = a;
	}
}


void CEftScn::Reset()
{
	m_bRn = true;

	m_dwI = timeGetTime();

	Drop();
}