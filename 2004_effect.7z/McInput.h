// Interface for the CMcInput class.
//
////////////////////////////////////////////////////////////////////////////////

#ifndef _MCINPUT_H_
#define _MCINPUT_H_

class CMcInput
{
// for direct input.. keyboard and mouse
public:
	LPDIRECTINPUT8			m_pDInput;
	LPDIRECTINPUTDEVICE8	m_pDiKey;
	LPDIRECTINPUTDEVICE8	m_pDiMouse;
	DIMOUSESTATE			MouseState;
	DIMOUSESTATE			MouseStateOld;

// for inter face
public:
	BYTE	Key[256], KeyOld[256];

	bool	bLButton, bLButtonOld;
	bool	bRButton, bRButtonOld;
	bool	bLButtonDB;

	POINT	MousePos, MousePosOld;

	INT		xDelta;
	INT		yDelta;
	int		zDelta;


public:
	CMcInput();
	virtual ~CMcInput();

	INT		Init();
	void	Destroy();

	INT		FrameMove();

	bool	GetKey(BYTE cKey)
	{
		return (Key[cKey] & 0x80 && KeyOld[cKey] != Key[cKey]);
	}

	bool	KeyState(BYTE cKey)
	{
		return (Key[cKey] & 0x80 && true);
	}


	bool	ButtonDown(INT button)
	{
		switch(button)
		{
			case 0:	return (MouseState.rgbButtons[0] && !MouseStateOld.rgbButtons[0]);
			case 1:	return (MouseState.rgbButtons[1] && !MouseStateOld.rgbButtons[1]);
			case 2:	return (MouseState.rgbButtons[2] && !MouseStateOld.rgbButtons[2]);
		}
		return false;
	}


	bool	ButtonUp(INT button)
	{
		switch(button)
		{
			case 0:	return (!MouseState.rgbButtons[0] && MouseStateOld.rgbButtons[0]);
			case 1:	return (!MouseState.rgbButtons[1] && MouseStateOld.rgbButtons[1]);
			case 2:	return (!MouseState.rgbButtons[2] && MouseStateOld.rgbButtons[2]);
		}
		return false;
	}


	bool	ButtonState(INT button)
	{
		switch(button)
		{
			case 0:	return (MouseState.rgbButtons[0] !=0);
			case 1:	return (MouseState.rgbButtons[1] !=0);
			case 2:	return (MouseState.rgbButtons[2] !=0);
		}
		return false;
	}


	LONG GetMouseState(INT button)
	{
		switch(button)
		{
		case 0:
			return MouseState.lX;
		case 1:
			return MouseState.lY;

		case 2:
			return MouseState.lZ;
		}

		return 0;
	}



private:
	INT InitDInput();
	INT UpdateGeneral();
	INT UpdateDInput();
};
#endif