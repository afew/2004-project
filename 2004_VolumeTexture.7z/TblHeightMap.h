// TblHeightMap.h: interface for the CTblHeightMap class.
//
//////////////////////////////////////////////////////////////////////

#ifndef _TBLHEIGHTMAP_H_
#define _TBLHEIGHTMAP_H_

class CTblHeightMap  
{
public:
	typedef union tagUMapAttrib
	{
		typedef struct tagSMapAttrib
		{
			DWORD	m_iAttrib00: 1;
			DWORD	m_iAttrib01: 1;
			DWORD	m_iAttrib02: 1;
			DWORD	m_iAttrib03: 1;
			DWORD	m_iAttrib04: 1;
			DWORD	m_iAttrib05: 1;
			DWORD	m_iAttrib06: 1;
			DWORD	m_iAttrib07: 1;
			DWORD	m_iAttrib08: 1;
			DWORD	m_iAttrib09: 1;
			DWORD	m_iAttrib10: 1;
			DWORD	m_iAttrib11: 1;
			DWORD	m_iAttrib12: 1;
			DWORD	m_iAttrib13: 1;
			DWORD	m_iAttrib14: 1;
			DWORD	m_iAttrib15: 1;
		}SMapAttrib;
		
		SMapAttrib m_SAttrib;
		DWORD	m_dwAttrib;

		tagUMapAttrib()
		{
			m_dwAttrib = 0;
		}
		
	}UMapAttrib, * PUMapAttrib, ** PPUMapAttrib;
	
public:
	// Base data
	TCHAR			m_szVersion[32];	// version
	INT				m_nIdxLocal;		// local index
	INT				m_iNumGridX;		// Number of Grid for x
	INT				m_iNumGridZ;		// Number of Grid for z
	
	INT				m_iWidthGridX;		// One tile width for x
	INT				m_iWidthGridZ;		// One tile width for z
	PPUMapAttrib	m_ppSMapAttrib;		// attribute
	
public:
	
	CTblHeightMap();
	virtual ~CTblHeightMap();
	
	INT	Init();
	VOID Destroy();
	
	INT	Load(TCHAR *pcFileName);
	
	INT	Save();

	
	UMapAttrib	GetMapAttrib(const VEC vecPos)
	{
		INT iX = INT(vecPos.x / m_iWidthGridX);
		INT iZ = INT(vecPos.z / m_iWidthGridZ);
		
		if(iX<0 || iX >=m_iNumGridX || iZ<0 || iZ>=m_iNumGridZ)
		{
			UMapAttrib mapAttrib;
			mapAttrib.m_dwAttrib = 0;

			return mapAttrib;
		}
	
		return(m_ppSMapAttrib[iZ][iX]);
	}


	


	UMapAttrib	GetMapAttrib(INT iX, INT iZ)
	{
		if(iX<0 || iX >=m_iNumGridX || iZ<0 || iZ>=m_iNumGridZ)
		{
			UMapAttrib mapAttrib;
			mapAttrib.m_dwAttrib = 0;

			return mapAttrib;
		}
		
		return(m_ppSMapAttrib[iZ][iX]);
	}
};

#endif
