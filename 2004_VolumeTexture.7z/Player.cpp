// Player.cpp: implementation of the CPlayer class.
//
//////////////////////////////////////////////////////////////////////

#include "Common.h"


// Construction/Destruction

CPlayer::CPlayer()
{
	m_pAni		= NULL;
	m_pObj		= NULL;
}

CPlayer::~CPlayer()
{
	Destroy();
}


INT	CPlayer::Init()
{
	SAFE_NEW(m_pAni);
	
	TBLMODEL->ModelSelect(&m_pObj, 0, m_PcInfo.iModel);
	
	m_vecScale.x = 0.3f;
	m_vecScale.y = 0.3f;
	m_vecScale.z = 0.3f;
	
	D3DXMatrixScaling(&m_matScale, m_vecScale.x, m_vecScale.y, m_vecScale.z);
	m_pObj->m_Mat *=m_matScale; 
	
	return 1;
}


void CPlayer::Destroy()
{
	SAFE_DELETE(m_pAni);
	SAFE_DELETE(m_pObj);
}


INT	CPlayer::Restore()
{
	SAFE_RESTORE(m_pObj);
	
	return 1;
}

void CPlayer::Invalidate()
{
	SAFE_INVALIDATE(m_pObj);
}




INT	CPlayer::FrameMove()
{
	if(C_WALK == m_PcInfo.eState)
	{
		MoveTo();
	}



	GET_KEY(DIK_INSERT)
	{
		if ( m_pObj != NULL )
		{
			++m_pAni->m_iCurrentAnim;

			m_pObj->SetAnimation(m_pAni->m_iCurrentAnim);
		}
	}
	
	GET_KEY(DIK_DELETE)
	{
		if ( m_pObj != NULL )
		{
			--m_pAni->m_iCurrentAnim;
			m_pObj->SetAnimation(m_pAni->m_iCurrentAnim);
		}
	}
	
	
	// FOR TEST
	GET_KEY(DIK_PRIOR)
		m_pAni->m_fAnimSpeed += 0.1f;
	
	GET_KEY(DIK_NEXT)
	{
		m_pAni->m_fAnimSpeed -= 0.1f;
		
		if ( m_pAni->m_fAnimSpeed < 0.0f )
			m_pAni->m_fAnimSpeed = 0.0f;
	}
	
	GET_KEY(DIK_HOME)
		m_pAni->m_bRender = !m_pAni->m_bRender;






	m_pObj->m_fDist= (m_pObj->m_vecP.x - GCAMERA->m_vecMaster.x) * (m_pObj->m_vecP.x - GCAMERA->m_vecMaster.x)
				+ (m_pObj->m_vecP.z - GCAMERA->m_vecMaster.z) * (m_pObj->m_vecP.z - GCAMERA->m_vecMaster.z);
		
	INT iCurrentAni = m_pAni->m_iCurrentAnim;

	// Animation frame update
	m_pAni->m_dwCurTime = timeGetTime();
	FLOAT fTime = 1000.0f/(m_pObj->m_pAnims[iCurrentAni].iFrameRate * m_pAni->m_fAnimSpeed);
	
	m_pAni->m_fInterpolation = (m_pAni->m_dwCurTime - m_pAni->m_dwLastTime)/fTime;
	
	if ( m_pAni->m_fInterpolation >=  1.0f )
	{
		m_pAni->m_iCurrentFrame += (INT)m_pAni->m_fInterpolation;
		m_pAni->m_fInterpolation -= (INT)m_pAni->m_fInterpolation;
		
		if ( m_pAni->m_iCurrentFrame >= m_pObj->m_pAnims[iCurrentAni].iEndFrame )
			m_pAni->m_iCurrentFrame = m_pObj->m_pAnims[iCurrentAni].iStartFrame ;
	}
	if ( m_pAni->m_dwCurTime - m_pAni->m_dwLastTime > (DWORD)fTime )
		m_pAni->m_dwLastTime = m_pAni->m_dwCurTime;
	
	


	m_pAni->m_bRender = (m_pObj->m_fDist > GSCENE->m_fRenderDist ? false: true);

	// Do animation play?
	if(m_pAni->m_bRender)
	{
		m_pObj->UpdateAnimation(m_pAni);
		m_pObj->UpdateVertex();
	}
	

	// ������...
	m_pObj->m_vecP = m_PcInfo.vecCur;
	// �÷��̾� y ��ġ...
	if(GSCENE->m_pLocal)
		m_pObj->m_vecP.y +=	GSCENE->m_pLocal->m_pLocalMap->GetHeight(m_pObj->m_vecP);

	
	return 1;
}

void CPlayer::Render()
{
	if(m_pAni->m_bRender)
		m_pObj->Render();
}



void CPlayer::MoveTo()
{
	m_PcInfo.vecDir.x = m_PcInfo.vecTar.x - m_PcInfo.vecCur.x;
	m_PcInfo.vecDir.z = m_PcInfo.vecTar.z - m_PcInfo.vecCur.z;

	if( D3DXVec3Length(&(m_PcInfo.vecDir) )<2.f)
	{
		m_PcInfo.eState = C_IDLE;

		m_pAni->m_iCurrentAnim =0;
		return;
	}

	D3DXVec3Normalize(&(m_PcInfo.vecDir), &(m_PcInfo.vecDir) );

	VEC pos = VEC (m_pObj->m_Mat._41, m_pObj->m_Mat._42, m_pObj->m_Mat._43);

	MAT matRot;
	D3DXMatrixRotationY(&matRot, D3DXToRadian(180.f));
	
	MAT	matDir;
	D3DXMatrixIdentity(&matDir);
	
	//	sin = m_PcInfo.vecDir.z,		cos = m_PcInfo.vecDir.x
	//	sin		0		-cos	0
	//	0		1		0		0
	//	cos		0		sin		0
	//	0		0		0		1

	matDir._11 = m_PcInfo.vecDir.z;
	matDir._33 = m_PcInfo.vecDir.z;
	matDir._31 = m_PcInfo.vecDir.x;
	matDir._13 =-m_PcInfo.vecDir.x;

	D3DXMatrixIdentity(&m_pObj->m_Mat);
	m_pObj->m_Mat = matRot * m_matScale * matDir;

	m_pObj->m_Mat._41 = pos.x;
	m_pObj->m_Mat._42 = pos.y;
	m_pObj->m_Mat._43 = pos.z;

	m_PcInfo.vecCur.x += m_PcInfo.vecDir.x * m_PcInfo.fSpeed;
	m_PcInfo.vecCur.z += m_PcInfo.vecDir.z * m_PcInfo.fSpeed;
}