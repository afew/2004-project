#ifndef _MCUTIL_H_
#define _MCUTIL_H_


#define SAFE_DESTROY(p)		{	if(p)	(p)->DeleteDeviceObjects();		}
#define SAFE_INVALIDATE(p)	{	if(p)	(p)->InvalidateDeviceObjects();	}
#define SAFE_RESTORE(p)		{	if(p)	(p)->RestoreDeviceObjects();	}

#define SAFE_FRAMEMOVE(p)	{	if(p)	(p)->FrameMove();				}
#define SAFE_RENDER(p)		{	if(p)	(p)->Render();					}


void McUtil_TextOut(HDC hDC, float x, float y, const char *format, ...);
int SeUtil_GetTextXW(HDC hDC, HFONT hFont, char *str);

void McUtil_SetWindowTitle(const char *format, ...);

#endif