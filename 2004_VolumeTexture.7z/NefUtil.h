///////////////////////////////////////////////////////////////////////////////
//
// NefUtin.h
// Explain:
// Date : 2003-04-18, Author: SR OnLine
// History:

#ifndef _NEFUTIL_H_
#define _NEFUTIL_H_


#define ONE_RADtoDEG	57.2957795130823208767981548f
#define ONE_DEGtoRAD	0.01745329251994329576923690f
#define PI				3.14159265358979323846264338f
#define DEG90toRAD		1.57079632679489661923132163f


//////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// 

template<class T> D3DXINLINE
bool SeUtil_IsBadReadPtr(T* &t)
{
	return (IsBadReadPtr(t, sizeof(T)));
}


template<class T> D3DXINLINE
bool SeUtil_IsNotAllocated(T* &t)
{
	return (!&t || !t || IsBadReadPtr(t, sizeof(T)) );	
}

template<class T> D3DXINLINE
bool SeUtil_IsAllocated(T* &t)
{
	return !SeUtil_IsNotAllocated(t);
}

template<class T> D3DXINLINE
void SAFE_NEW(T* &p)
{
	//	if(!p)
	if(SeUtil_IsNotAllocated(p))
		p = new T;
}

template<class T> D3DXINLINE
void SAFE_NEW_ARRAY(T* &p, int N)
{
	if(SeUtil_IsNotAllocated(p))
		p = new T[N];
}

template<class T> D3DXINLINE
int  _SAFE_NEWINIT(T* &p)
{
	if(SeUtil_IsNotAllocated(p))
	{
		p = new T;
		if( p->Init()<0 )
			return -1;
	}
	
	return 1;
}


#define		SAFE_NEWINIT(p)		if(FAILED(_SAFE_NEWINIT(p)))	return -1;


template<class T> D3DXINLINE
void SAFE_NEWINIT_ARRAY(T* &p, int N)
{
	if(SeUtil_IsNotAllocated(p))
	{
		p = new T[N];
		for(int i = 0; i<N ; ++i)
			p[i].Init();
	}
}

#define		SAFE_DESTROY(p)		if(p)	(p)->Destroy();

template<class T> D3DXINLINE
void SAFE_DESTROY_ARRAY	(T* &p, int N)
{
	if(SeUtil_IsAllocated(p))
		for(int i=0; i<N ; ++i)
			p[i].Destroy();
}

#define		_SAFE_RESTORE(p)	if(p)	(p)->Restore();
#define		SAFE_RESTORE(p)		if((p) && FAILED( (p)->Restore())) return -1;

template<class T> D3DXINLINE
void SAFE_RESTORE_ARRAY	(T* &p, int N)
{
	if(SeUtil_IsAllocated(p))
		for(int i=0; i<N ; ++i)
			p[i].Restore();
}


#define		SAFE_INVALIDATE(p)	if(p)	(p)->Invalidate();


template<class T> D3DXINLINE
void SAFE_INVALIDATE_ARRAY	(T* &p,int N)
{
	if(SeUtil_IsAllocated(p))
		for(int i=0; i<N; ++i)
			p[i].Invalidate();
}

#define		SAFE_FRAMEMOVE(p)	if( (p) && FAILED( (p)->FrameMove())) return -1;


template<class T> D3DXINLINE
void SAFE_FRAMEMOVE_ARRAY	(T* &p, int N)
{
	if(SeUtil_IsAllocated(p))
		for(int i=0; i<N; ++i)
			p[i].FrameMove();
}


#define		SAFE_RENDER(p)	if(p)	(p)->Render();
#define		SAFE_RNDBCK(p)	if(p)	(p)->RndBck();


template<class T> D3DXINLINE
void SAFE_RENDER_ARRAY	(T* &p, int N)
{
	if(SeUtil_IsAllocated(p))
		for(int i=0; i<N; ++i)
			p[i].Render();
}


template<class T> D3DXINLINE
void SeUtil_Swap (T* &a, T* &b)
{
	T c; c = *a; *a = *b;*b = c;
}

template<class T> D3DXINLINE void SAFE_INIT_LIST(T &p)
{
	if(p.empty())	return;
	
	INT iSize = p.size();
	
	for(int i=0; i<p.size; ++i)
		if(p[i])
			p[i]->Init();
}



template<class T> D3DXINLINE
void SAFE_DELETE_LIST(T &p)
{
	if(p.empty())	return;
	
	INT iSize = p.size();
	
	for(int i=0; i<iSize; ++i)
		SAFE_DELETE(p[i]);
	
	p.clear();
}


template<class T> D3DXINLINE
void SAFE_DESTROY_LIST(T &p)
{
	if(p.empty())	return;
	
	INT iSize = p.size();
	
	for(int i=0; i<iSize; ++i)
		SAFE_DESTROY(p[i]);
}


template<class T> D3DXINLINE
int SAFE_RESTORE_LIST(T &p)
{
	if(p.empty())	return -1;
	
	INT iSize = p.size();
	
	for(int i=0; i<iSize; ++i)
		if((p[i]) && FAILED( (p[i])->Restore()))
			return -1;
		
		return 1;
}


template<class T> D3DXINLINE
void SAFE_INVALIDATE_LIST(T &p)
{
	if(p.empty())	return;
	
	INT iSize = p.size();
	
	for(int i=0; i<iSize; ++i)
		SAFE_INVALIDATE(p[i]);
}




template<class T> D3DXINLINE
int SAFE_FRAMEMOVE_LIST(T &p)
{
	if(p.empty())	return -1;
	
	INT iSize = p.size();
	
	for(int i=0; i<iSize; ++i)
	{
		if(! p[i])
			return -1;
		
		if( FAILED( (p[i])->FrameMove()))
			return -1;
	}
	
	return 1;
}



template<class T> D3DXINLINE
void SAFE_RENDER_LIST(T &p)
{
	if(p.empty())	return;
	
	INT iSize = p.size();
	
	for(int i=0; i<iSize; ++i)
		SAFE_RENDER(p[i]);
}


void	SeUtil_ErrMsgBox(TCHAR *format,...);
void	SeUtil_FormatLog(TCHAR *format,...);
void	SeUtil_FormatLog2(TCHAR *format,...);
int		SeUtil_TextureLoad(TCHAR * sFileName, PDTX & texture, DWORD _color=0xffffffff, D3DXIMAGE_INFO *pSrcInfo=NULL, D3DFORMAT d3dFormat = D3DFMT_A8R8G8B8);
void	SeUtil_ReadFileLine(FILE *fp, TCHAR *str, int nStr);

void	SeUtil_VBCreate(PDVB& pVB, int nSize, DWORD FVF, void* pVtx = NULL, D3DPOOL pool= D3DPOOL_MANAGED);
void	SeUtil_IBCreate(PDIB& pIB, int nSize, void* pIdx = NULL, D3DFORMAT FMT=D3DFMT_INDEX16, D3DPOOL pool=D3DPOOL_MANAGED);

void	SeUtil_VBCopy(PDVB& pVB, int nSize, void* pVtx);
void	SeUtil_IBCopy(PDIB& pIB, int nSize, void* pIdx);


template<class T> D3DXINLINE
void	SeUtil_BufferCopy(T &pBuf, int nSize, void* pS)
{
	void* p;
	
	if( FAILED( pBuf->Lock( 0, 0, &p, 0)))
		return;
	
	memcpy(p, pS, nSize);
	pBuf->Unlock();
}


bool	SeUtil_LineCross2D(VEC2 * p);
int		SeUtil_Position2D(VEC & Out, const VEC & In);
bool	SeUtil_PositionMouse3D(VEC & vec3dOut);
int		SeUtil_DrawHDCText(int X, int Y, LPCTSTR Text, DWORD _color= RGB(255,255,0));
void	SeUtil_SetWindowTitle(const char *format, ...);
void	SeUtil_TextOut(float x, float y, const char *format, ...);
void	SeUtil_TextOut(VEC2 p, const char *format, ...);
void	SeUtil_OutputDebug(const char *Format, ...);
char*	SeUtil_Forming(const char *fmt, ...);
char*	getSmallTime(void);
int		SeUtil_PluckFirstField(char *str, char *dest, int maxlen, const char *delim);


//for game programming...
typedef struct tagSBaseGameInfo
{
	TCHAR	Version[32];
	
	INT		UsingBaseUser;
	TCHAR	UsrID			[32];
	TCHAR	UsrPwd			[32];
	
	
	INT		UsingBaseServer;
	TCHAR	ServerIP		[16];
	TCHAR	ServerPort		[16];
	
	INT		FPS;
	INT		CameraInfo;
	INT		Box;
	INT		StartFullMode;
	INT		WindowTitle;
	
	TCHAR	FileClimate		[512];
	TCHAR	FileExpLevel	[512];
	TCHAR	FileFontList	[512];
	TCHAR	FileHeightMap	[512];
	TCHAR	FileLighting	[512];
	TCHAR	FileLocalData	[512];
	TCHAR	FileModel		[512];
	TCHAR	FileSound		[512];
	TCHAR	FileTexture		[512];
	TCHAR	FileMenuData	[512];
	TCHAR	FileUIData		[512];
	TCHAR	FileUISetupData	[512];
	
	tagSBaseGameInfo()
		: UsingBaseUser(-1)
		, UsingBaseServer(-1)
		, FPS(-1)
		, CameraInfo(-1)
		, Box(-1)
		, StartFullMode(-1)
		, WindowTitle(-1)
	{
		memset(UsrID,			0, sizeof(UsrID));
		memset(UsrPwd,			0, sizeof(UsrPwd));
		memset(ServerIP,		0, sizeof(ServerIP));
		memset(ServerPort,		0, sizeof(ServerPort));
		memset(Version,			0, sizeof(Version));
		memset(FileClimate,		0, sizeof(FileClimate));
		memset(FileExpLevel,	0, sizeof(FileExpLevel));
		memset(FileFontList,	0, sizeof(FileFontList));
		memset(FileHeightMap,	0, sizeof(FileHeightMap));
		memset(FileLighting,	0, sizeof(FileLighting));
		memset(FileLocalData,	0, sizeof(FileLocalData));
		memset(FileModel,		0, sizeof(FileModel));
		memset(FileSound,		0, sizeof(FileSound));
		memset(FileTexture,		0, sizeof(FileTexture));
		memset(FileMenuData,	0, sizeof(FileMenuData));
		memset(FileUIData,		0, sizeof(FileUIData));
		memset(FileUISetupData, 0, sizeof(FileUISetupData));
	}
	
}SBaseGameInfo;


//
class CSimpleNode
{
public:
	CSimpleNode	* pNext;
	CSimpleNode();
};



class CDebugStringBase : public CSimpleNode
{
public:
	int m_iX;
	int m_iY;
	int m_iData;
	char m_szString[256];
	static CSimpleNode * pStart;
	
public:
	CDebugStringBase();
	virtual void AddTail(CSimpleNode * pQueue);
	virtual void OnPrintString(int iY);
	virtual void PrintString(int iY);
	virtual void PrintStringAll(int iY);
};


class CDebugString
{
public:
	unsigned int m_iNum;
	unsigned int m_iIdx;
	CDebugStringBase ** ppQue;
	
public:
	void Destroy();
	CDebugString();
	virtual int Init();
	virtual void PrintString(int iY);
	virtual void SetString(char * szString);
	virtual ~CDebugString();
};


#endif